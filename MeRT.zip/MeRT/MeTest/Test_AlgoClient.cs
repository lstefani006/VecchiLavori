using System;
using System.IO;
using System.Text;
using System.Threading;
using System.Xml;
using System.Xml.Serialization;
using MeRT_Algo;

public class Test_AlgoClient
{

	public static void Test_1(string testDir)
	{
		Console.WriteLine();
		Console.WriteLine();
		Console.Write("Test_AlgoClient.Test_1: ");
		Console.ReadLine();

		DatiElaborazione de = new DatiElaborazione();

		de.Version = "1.0";
		de.idElaborazione = Guid.NewGuid().ToString();
		de.mercato = TipoMercato.MGP;
		de.dataFlusso = DateTime.Now.Date;
		de.oraFlusso = 1;

		de.Zona = new Zona[2];
		de.Zona[0] = new Zona();
		de.Zona[0].codiceZona = "NORD";
		de.Zona[0].tipoZona = TipoZona.PHYS;
		de.Zona[1] = new Zona();
		de.Zona[1].codiceZona = "SUD";
		de.Zona[1].tipoZona = TipoZona.PHYS;

		de.VincoloInterzonale = new VincoloInterzonale[2];
		de.VincoloInterzonale[0] = new VincoloInterzonale();
		de.VincoloInterzonale[0].aZona = "NORD";
		de.VincoloInterzonale[0].daZona = "SUD";
		de.VincoloInterzonale[0].flussoMassimoADa = 3.14;
		de.VincoloInterzonale[0].flussoMassimoDaA = 6.28;

		de.VincoloInterzonale[1] = new VincoloInterzonale();
		de.VincoloInterzonale[1].aZona = "CNOR";
		de.VincoloInterzonale[1].daZona = "SUD";
		de.VincoloInterzonale[1].flussoMassimoADa = 23.14;
		de.VincoloInterzonale[1].flussoMassimoDaA = 26.28;


		de.VincoloGeneralizzato = new VincoloGeneralizzato[1];
		de.VincoloGeneralizzato[0] = new VincoloGeneralizzato();
		de.VincoloGeneralizzato[0].nomeVincolo = "PIPPO";
		de.VincoloGeneralizzato[0].flussoMassimo = 32.33;
		de.VincoloGeneralizzato[0].VincoloGeneralizzatoCoefficiente = new VincoloGeneralizzatoCoefficiente[1];
		de.VincoloGeneralizzato[0].VincoloGeneralizzatoCoefficiente[0] = new VincoloGeneralizzatoCoefficiente();
		de.VincoloGeneralizzato[0].VincoloGeneralizzatoCoefficiente[0].zona = "NORD";
		de.VincoloGeneralizzato[0].VincoloGeneralizzatoCoefficiente[0].coefficienteTrasporto = 221.202;


		de.OffertaAcquisto = new OffertaAcquisto[2];
		de.OffertaAcquisto[0] = new OffertaAcquisto();
		de.OffertaAcquisto[0].idOfferta = "122122";
		de.OffertaAcquisto[0].prezzo = 51.33;
		de.OffertaAcquisto[0].zona = "NORD";
		de.OffertaAcquisto[0].quantitaMWh = 211;
		de.OffertaAcquisto[0].prezzoUnico = PrezzoUnico.Y;

		de.OffertaAcquisto[1] = new OffertaAcquisto();
		de.OffertaAcquisto[1].idOfferta = "122122";
		de.OffertaAcquisto[1].prezzo = 51.33;
		de.OffertaAcquisto[1].zona = "NORD";
		de.OffertaAcquisto[1].quantitaMWh = 211;
		de.OffertaAcquisto[1].prezzoUnico = PrezzoUnico.Y;


		de.OffertaVendita = new OffertaVendita[2];
		de.OffertaVendita[0] = new OffertaVendita();
		de.OffertaVendita[0].idOfferta = "122122";
		de.OffertaVendita[0].prezzo = 51.33;
		de.OffertaVendita[0].zona = "NORD";
		de.OffertaVendita[0].quantitaMWh = 211;

		de.OffertaVendita[1] = new OffertaVendita();
		de.OffertaVendita[1].idOfferta = "122122";
		de.OffertaVendita[1].prezzo = 51.33;
		de.OffertaVendita[1].zona = "NORD";
		de.OffertaVendita[1].quantitaMWh = 211;

		/*
		de.ParametroAlgoritmo = new ParametroAlgoritmo[2];
		de.ParametroAlgoritmo[0] = new ParametroAlgoritmo();
		de.ParametroAlgoritmo[0].nomeParametro = "PI";
		de.ParametroAlgoritmo[0].valoreParametro = Math.PI;
		de.ParametroAlgoritmo[1] = new ParametroAlgoritmo();
		de.ParametroAlgoritmo[1].nomeParametro = "E";
		de.ParametroAlgoritmo[1].valoreParametro = Math.E;
		*/

		if (true)
		{
			XmlSerializer x = new XmlSerializer(typeof(DatiElaborazione));
			XmlTextWriter xw = new XmlTextWriter(Path.Combine(testDir, "de.xml"), Encoding.UTF8);
			xw.Formatting = Formatting.Indented;
			xw.IndentChar = '\t';
			xw.Indentation = 1;
			x.Serialize(xw, de);
			xw.Close();
		}

	
		Algo algo = new Algo();
		algo.Url = "http://localhost/MeRT_Algo/Algo.asmx";

		algo.Elabora(de);


		while (algo.ElaborazioneCompletata(de.idElaborazione) == false)
			Thread.Sleep(1000);

		DatiElaborazione ri = algo.RisultatiElaborazione(de.idElaborazione);

		if (true)
		{
			XmlSerializer x = new XmlSerializer(typeof(DatiElaborazione));
			XmlTextWriter xw = new XmlTextWriter(Path.Combine(testDir, "ri.xml"), Encoding.UTF8);
			xw.Formatting = Formatting.Indented;
			xw.IndentChar = '\t';
			xw.Indentation = 1;
			x.Serialize(xw, ri);
			xw.Close();
		}

		if (true)
		{
			XmlSerializer xr = new XmlSerializer(typeof(DatiElaborazione));
					
			StreamReader sr = File.OpenText(Path.Combine(testDir, "ri.xml"));
			ri = (DatiElaborazione) xr.Deserialize(sr);
			sr.Close();
		}

		if (ri != null)
		{
			Console.WriteLine(ri.idElaborazione);
		}
	}
}