using System;
using GME.Remoting;
using MeRT_IBL;

public class Test_AlgoRunner
{

	public static void Test_1()
	{
		Console.WriteLine();
		Console.WriteLine();
		Console.Write("Test_AlgoRunner.Test_1: ");
		Console.ReadLine();


		IAlgoRunner ar = (IAlgoRunner) RemotingHelper.GetObject(typeof(IAlgoRunner));

//TODO LEO		ar.ProduciDatiIngresso("MGP", new DateTime(2005,5,30), 1, "PrezzoUnico", 501);
		ar.LanciaAlgoritmo("MGP", new DateTime(2005, 7, 28), 1, "PrezzoUnico", 501);


	}
}
