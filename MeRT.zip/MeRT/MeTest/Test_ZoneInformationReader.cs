using System;
using System.IO;
using System.Text;

using GME.Remoting;

using MeRT_IBL;


internal class Test_ZoneInformationReader
{
	public static void Test_1(string testDir)
	{
		Console.WriteLine();
		Console.WriteLine();
		Console.Write("Test_ZoneInformationReader.Test_1: ");
		Console.ReadLine();

		string codiceOperatore = "IDGME";
		string codiceUtente = "1";
		string encoding = "ISO-8859-1";

		DirectoryInfo di = new DirectoryInfo(testDir);
		FileInfo [] files = di.GetFiles("*_test.xml");
		foreach (FileInfo file in files)
		{
			Console.WriteLine("Start read " + file.Name);
			byte[] fileXml = new UTF8Encoding().GetBytes(file.OpenText().ReadToEnd());

			ITransactionReader reader = (ITransactionReader) RemotingHelper.GetObject(typeof(ITransactionReader));

			reader.ReadMessage(codiceOperatore, codiceUtente, file.Name, encoding, fileXml);
			Console.WriteLine("End read " + file.Name);
		}
	}
}
