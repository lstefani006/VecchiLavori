using System.ComponentModel;
using System.Web.Services;
using System.Web.Services.Protocols;

#if !NO_GMELIB
using GME;
#endif

namespace RemOpWS
{
	/// <summary>
	/// Summary description for RemOpSink.
	/// </summary>
	[WebService(Namespace="http://mercatoelettrico.org/RemOpWS/RemOpSink")]
	public class RemOpSink : 
#if !NO_GMELIB
		WSBase
#else
		WebService
#endif
	{
		public RemOpSink()
		{
			InitializeComponent();
		}

		#region Component Designer generated code
		
		//Required by the Web Services Designer 
		private IContainer components = null;
				
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if(disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);		
		}
		
		#endregion

		[WebMethod]
		[SoapHeader("authHeader")]
		public byte [] ProcessMessage(string destinationServer, byte [] ain)
		{
#if !NO_GMELIB
			CheckAuth();
			return RemOpBasedChannel.RemOpChannel.ServiceSequest(destinationServer, false, ain);
#else
			return null;
#endif

		}

		[WebMethod]
		[SoapDocumentMethod(OneWay=true)]
		[SoapHeader("authHeader")]
		public void ProcessMessageOneWay(string destinationServer, byte [] ain)
		{
#if !NO_GMELIB
			CheckAuth();
			RemOpBasedChannel.RemOpChannel.ServiceSequest(destinationServer, true, ain);
#endif
		}



		[WebMethod]
		[SoapHeader("authHeader")]
		public byte [] ProcessMessage2(byte [] header, byte [] msg)
		{
#if !NO_GMELIB
			CheckAuth();
			return RemOpBasedChannel.RemOpChannel.ServiceSequest(false, header, msg);
#else
			return null;
#endif

		}

		[WebMethod]
		[SoapDocumentMethod(OneWay=true)]
		[SoapHeader("authHeader")]
		public void ProcessMessageOneWay2(byte [] header, byte [] msg)
		{
#if !NO_GMELIB
			CheckAuth();
			RemOpBasedChannel.RemOpChannel.ServiceSequest(true, header, msg);
#endif
		}

#if NO_GMELIB
		public WSAuthHeader authHeader = null;
#endif

	}

#if NO_GMELIB
	public class WSAuthHeader : SoapHeader
	{
		public string Username;
		public string Password;
	}
#endif

}
