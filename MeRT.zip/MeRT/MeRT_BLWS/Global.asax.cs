using System;
using System.IO;
using System.Reflection;
using System.Runtime.Remoting;
using GME.Utility;

namespace MeRT_BLWS 
{
	/// <summary>
	/// Summary description for Global.
	/// </summary>
	public class Global : System.Web.HttpApplication
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		public Global()
		{
			InitializeComponent();
		}	
		
		protected void Application_Start(Object sender, EventArgs e)
		{
			// log su file
			if (AppSettings.ToBoolean("LogFile_Enabled", true))
			{
				try
				{
					string logFileDir = AppSettings.ToString("LogFile_Dir", "logfiles");
					logFileDir = Path.Combine(AppDomain.CurrentDomain.SetupInformation.ApplicationBase, logFileDir);
					string logFileName = string.Concat(logFileDir
						, Path.DirectorySeparatorChar
						, string.Format("mert_blws_{0:yyyyMMdd}.log", DateTime.Today));

					System.Diagnostics.Trace.Listeners.Add(
						new System.Diagnostics.TextWriterTraceListener(logFileName));
					System.Diagnostics.Trace.AutoFlush = true;
				}
				catch {}
			}

			string blConfig = AppDomain.CurrentDomain.SetupInformation.ApplicationBase + "BL.config";
			RemotingConfiguration.Configure(blConfig);

			Assembly ass = typeof(MeRT_BL.Echo).Assembly;
			MeRT_IBL.RemConfig.ServerConfig(ass, AppSettings.ToString("RemOpChannel_RegisterServer"));

			GME.Log.smTrace("Application_Start");
		}
 
		protected void Session_Start(Object sender, EventArgs e)
		{

		}

		protected void Application_BeginRequest(Object sender, EventArgs e)
		{

		}

		protected void Application_EndRequest(Object sender, EventArgs e)
		{

		}

		protected void Application_AuthenticateRequest(Object sender, EventArgs e)
		{

		}

		protected void Application_Error(Object sender, EventArgs e)
		{
			// TODO LEO agganciare la gestione degli errori.
			try
			{
				GME.Log.smError(Server.GetLastError(), "Application_Error");
			}
			catch {}
		}

		protected void Session_End(Object sender, EventArgs e)
		{

		}

		protected void Application_End(Object sender, EventArgs e)
		{
			GME.Log.smTrace("Application_End");
		}
			
		#region Web Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.components = new System.ComponentModel.Container();
		}
		#endregion
	}
}

