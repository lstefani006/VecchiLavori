using System;
using System.Data;

namespace MeRT_IBL
{
	/// <summary>
	/// Summary description for Login.
	/// </summary>
	[RemotableClient]
	public interface IZoneInformationReader
	{
		void ReadMessage(string codiceOperatore, string codiceUtente, string nomeFile, string encoding, byte[] fileXml);
	}
}
