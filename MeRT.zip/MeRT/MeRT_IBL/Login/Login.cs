using System;
using System.Data;

namespace MeRT_IBL
{
	/// <summary>
	/// Summary description for Login.
	/// </summary>
	[RemotableClient]
	public interface ILogin
	{
		LoginData CheckAccessUsernamePassword(string userName, string password);
		LoginData CheckAccessCertificate(string issuer, string serialNumber);
	}

	[Serializable]
	public class LoginData
	{

		[Serializable]
		public class Funzione
		{
			public string codiceFunzione;
			public string descrizioneFunzione;
		}


		[Serializable]
		public class Operator
		{
			public string codiceOperatore;
			public string ragioneSociale;
			public string ruolo;

			public Funzione [] funzione;
		}

		public bool loggedIn;
		public string codiceUtente;
		public string nome;
		public string cognome;
		public string lingua;
		public Operator [] WorkingOperator;
	}



}
