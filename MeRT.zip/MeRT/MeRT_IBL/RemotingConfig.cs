using System;
using System.Reflection;
using System.Runtime.Remoting;

namespace MeRT_IBL
{

	[AttributeUsage(AttributeTargets.Class | AttributeTargets.Interface)]
	public class RemotableClientAttribute : Attribute
	{
	}
	[AttributeUsage(AttributeTargets.Class)]
	public class RemotableServerAttribute : Attribute
	{
		public WellKnownObjectMode Activation = WellKnownObjectMode.SingleCall;
	}

	public class RemConfig
	{
		public static void ClientConfig(string defaultClientConfig)
		{
			if (defaultClientConfig == null)
				return;

			Assembly ass = typeof(IEcho).Assembly;
			Type [] ty = ass.GetExportedTypes();
			foreach (Type t in ty)
			{
				object [] ta = t.GetCustomAttributes(typeof(RemotableClientAttribute), true);
				if (ta.Length > 0)
				{
					if (RemotingConfiguration.IsWellKnownClientType(t) == null)
					{
						string uri = string.Format(defaultClientConfig, t.Name);
						RemotingConfiguration.RegisterWellKnownClientType(t, uri);
					}
				}
			}
		}


		public static void ServerConfig(Assembly ass, string defaultServer)
		{
			Type [] ty = ass.GetExportedTypes();
			foreach (Type t in ty)
			{
				object [] ta = t.GetCustomAttributes(typeof(RemotableServerAttribute), true);
				if (ta.Length > 0)
				{
					RemotableServerAttribute remAttr = (RemotableServerAttribute) ta[0];
					if (RemotingConfiguration.IsRemotelyActivatedClientType(t) == null)
					{
						string uri = string.Format(defaultServer, t.Name);
						RemotingConfiguration.RegisterWellKnownServiceType(t, uri, remAttr.Activation);
					}
				}
			}
		}
	}
}

