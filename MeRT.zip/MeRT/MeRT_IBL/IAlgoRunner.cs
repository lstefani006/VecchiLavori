using System;
using System.Data;

namespace MeRT_IBL
{
	/// <summary>
	/// Summary description for Login.
	/// </summary>
	[RemotableClient]
	public interface IAlgoRunner
	{
		void LanciaAlgoritmo(string mercato, DateTime flowDate, byte flowHour, string algoritmo, double prezzoMassimoAcquisto);

	}

	[RemotableClient]
	public interface IAlgoRis
	{
		/// <summary>
		/// Lancia il thread che va il polling sul WS dei risultati per vedere
		/// se ci sono risultati disponibili.
		/// La funzione "disturba" il WS solo se risulta nel DB una o piu` esecuzioni in RUN.
		/// Quando il WS ritona il risultato, lo si stora nel DB;
		/// lo stato StatoEsecuzioneOra viene messo a HBMR o a ERR
		/// a seconda che il risultato indichi fallimento o successo
		/// </summary>
		void PollAndConsumeAlgoRis();

		/// <summary>
		/// Abortisce a forza una elaborazione.
		/// L'abort, per ora, avviene solo a livello di DB, non viene notificato al WS niente dato che non sono previste
		/// primitive allo scopo.
		/// Richiesto lo stato in RUN; lo porta in ERR
		/// </summary>
		/// <param name="flowDate"></param>
		/// <param name="flowHour"></param>
		/// <param name="codiceMercato"></param>
		/// <param name="progressivoEsecuzione"></param>
		/// <returns></returns>
		void AbortEsecuzione(DateTime flowDate, byte flowHour, string codiceMercato, int progressivoEsecuzione);

		/// <summary>
		/// ritorna il blob zippato di un byte[] in UTF8 che e` l'xml ritornato dall'algoritmo
		/// </summary>
		/// <param name="flowDate"></param>
		/// <param name="flowHour"></param>
		/// <param name="codiceMercato"></param>
		/// <param name="progressivoEsecuzione"></param>
		/// <returns></returns>
		byte [] ReadBlobRisultatoAlgoritmo(DateTime flowDate, byte flowHour, string codiceMercato, int progressivoEsecuzione);

		/// <summary>
		/// Fa diventare una esecuzione da HBMR a PROV.
		/// I risultati dell'algoritmo sono copiati nelle tabelle del DB dal blob.
		/// I risultati sono dunque visibili agli operatori del sistema.
		/// </summary>
		/// <param name="flowDate"></param>
		/// <param name="flowHour"></param>
		/// <param name="codiceMercato"></param>
		/// <param name="progressivoEsecuzione"></param>
		void RendiProvRisultato(DateTime flowDate, byte flowHour, string codiceMercato, int progressivoEsecuzione);

		/// <summary>
		/// Fa diventare una esecuzione da HBMR a ERR.
		/// </summary>
		/// <param name="flowDate"></param>
		/// <param name="flowHour"></param>
		/// <param name="codiceMercato"></param>
		/// <param name="progressivoEsecuzione"></param>
		void RendiErrRisultato(DateTime flowDate, byte flowHour, string codiceMercato, int progressivoEsecuzione);



		/// <summary>
		/// Fa diventare una esecuzione da PROV a COMP.
		/// </summary>
		/// <param name="flowDate"></param>
		/// <param name="flowHour"></param>
		/// <param name="codiceMercato"></param>
		/// <param name="progressivoEsecuzione"></param>
		void RendiCompRisultato(DateTime flowDate, byte flowHour, string codiceMercato, int progressivoEsecuzione);


		/// <summary>
		/// Ritorna la lista delle esecuzioni che soddisfano i parametri di ricerca.
		/// La funzione ritorna volutamente un DataSet non tipato perche` questa funzione
		/// e` pensata piu` per la visualizzazione che per elaborare il risultato.
		/// </summary>
		/// <param name="flowDate">data di flusso o <c>DateTime.MinValue</c> per tutte le date</param>
		/// <param name="flowHour">ora di flusso o -1 per tutte le ore</param>
		/// <param name="codiceMercato">il mercato o <c>null</c> per tutti i mercati</param>
		/// <param name="statoEsecuzioneOra">lo stato o <c>null</c> per tutti gli stati</param>
		/// <param name="progressivoEsecuzione">il progressivo o -1 per tutte le esecuzioni</param>
		/// <returns>la lista</returns>
		DataSet ReadListaEsecuzioni(DateTime flowDate, int flowHour, string codiceMercato, string statoEsecuzioneOra, int progressivoEsecuzione);
	}

	public enum StatoEsecuzioneOra
	{
		RUN,
		ERR,
		HBMR,
		PROV,
		COMP
	}

	public enum StatoSessione
	{
		PRRQ,
		PRIP,
		PROV,
		PEND,
		ERR,
		FRRQ,
		FRIP,
		COMP,
		CLSD,
		OPEN
	}
}
