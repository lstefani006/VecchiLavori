using System;

namespace MeRT_IBL
{
	/// <summary>
	/// Summary description for IEcho.
	/// </summary>
	[RemotableClient]
	public interface IEcho
	{
		/// <summary>
		/// Se forward e` false ritorna una stringa che indentifica il modulo che viene invocato.
		/// Se forward e` true inoltra l'echo al prossimo server di rete
		/// </summary>
		/// <param name="forward"></param>
		/// <returns></returns>
		string DoEcho(bool forward);
	}

}
