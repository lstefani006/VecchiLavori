using System;
using GME.BL;
using MeRT_IBL;

namespace MeRT_BL
{

	/// <summary>
	/// Summary description for Echo.
	/// </summary>
	[RemotableServer]
	public class Echo : BLBase, IEcho
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Echo(System.ComponentModel.IContainer container)
		{
			container.Add(this);
			InitializeComponent();
		}

		public Echo()
		{
			InitializeComponent();
		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}


		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			components = new System.ComponentModel.Container();
		}
		#endregion


		public string DoEcho(bool forward)
		{
			// throw new ApplicationException("Leo");

			string hn = System.Configuration.ConfigurationSettings.AppSettings["HostName"];
			if (forward == false)
			{
				return hn + ": " + AppDomain.CurrentDomain.FriendlyName; 	
			}
			else
			{
				// TODO andare sul DB 
				return null;
			}
		}
	}
}
