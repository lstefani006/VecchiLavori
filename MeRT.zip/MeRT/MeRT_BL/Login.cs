using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using GME.BL;
using GME.Utility;
using MeRT_IBL;

namespace MeRT_BL
{
	/// <summary>
	/// Summary description for Login.
	/// </summary>
	[RemotableServer]
	public class Login : BLBase, ILogin
	{
		private SqlConnection cn;

		private Container components = null;

		public Login(IContainer container)
		{
			container.Add(this);
			InitializeComponent();
			cn.ConnectionString = BLBase.SqlConnectionstring;
		}

		public Login()
		{
			InitializeComponent();
			cn.ConnectionString = BLBase.SqlConnectionstring;
		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose(bool disposing)
		{
			if (disposing)
			{
				if (components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}

		#region Component Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.cn = new System.Data.SqlClient.SqlConnection();
			// 
			// cn
			// 
			this.cn.ConnectionString = "workstation id=STEFANI;packet size=4096;user id=MeRT_User;data source=BILSVR1;per" +
				"sist security info=True;initial catalog=MeRT;password=mert_user";

		}

		#endregion

		public LoginData CheckAccessUsernamePassword(string userName, string password)
		{
			LoginData r = new LoginData();
			r.loggedIn = false;

			try
			{
				SqlCommand cmd = cn.CreateCommand();
				cmd.CommandText = "Login_CheckAccessUsernamePassword";
				cmd.CommandType = CommandType.StoredProcedure;
				cmd.CommandTimeout = AppSettings.ToInt32("Login_CheckAccessUsernamePassword_Timeout", 30);

				cmd.Parameters.Add("@userName", userName);
				cmd.Parameters.Add("@password", password);

				cn.Open();


				using (SqlDataReader rd = cmd.ExecuteReader())
				{
					// se non leggo almeno una riga significa login fail
					if (rd.Read())
					{
						r.loggedIn = true;
						r.codiceUtente = rd.GetSqlString(0).Value;
						r.nome = rd.GetSqlString(1).Value;
						r.cognome = rd.GetSqlString(2).Value;
						r.lingua = rd.GetSqlString(3).Value;
						r.WorkingOperator = null;
					}

					if (r.loggedIn == false)
						return r;

					if (rd.NextResult())
					{
						ArrayList ar = new ArrayList();

						while (rd.Read())
						{
							LoginData.Operator op = new LoginData.Operator();
							op.codiceOperatore = rd.GetSqlString(0).Value;
							op.ragioneSociale = rd.GetSqlString(1).Value;
							op.ruolo = rd.GetSqlString(2).Value;

							ar.Add(op);
						}

						r.WorkingOperator = (LoginData.Operator[]) ar.ToArray(typeof (LoginData.Operator));
					}

					if (rd.NextResult())
					{
						Hashtable sd = new Hashtable();

						while (rd.Read())
						{
							LoginData.Funzione fn = new LoginData.Funzione();
							string op = rd.GetSqlString(0).Value;
							fn.codiceFunzione = rd.GetSqlString(1).Value;
							fn.descrizioneFunzione = rd.GetSqlString(2).Value;

							if (!sd.ContainsKey(op)) sd.Add(op, new ArrayList());

							((ArrayList) sd[op]).Add(fn);
						}

						foreach (DictionaryEntry de in sd)
						{
							string op = (string) de.Key;
							ArrayList fn = (ArrayList) de.Value;

							for (int i = 0; i < r.WorkingOperator.Length; ++i)
								if (r.WorkingOperator[i].codiceOperatore == op)
								{
									r.WorkingOperator[i].funzione = (LoginData.Funzione[]) fn.ToArray(typeof (LoginData.Funzione));
									break;
								}
						}
					}
				}
			}
			catch (Exception e)
			{
				smError(e);
				throw;
			}
			finally
			{
				cn.Dispose();
			}

			return r;
		}

		public LoginData CheckAccessCertificate(string issuer, string serialNumber)
		{
			// LEO TODO
			throw new NotImplementedException();
		}

	}
}