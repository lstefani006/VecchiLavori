using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Xml;
using System.Xml.Serialization;
using GME.BL;
using GME.Utility;
using GME.Web;
using GME.Zip;
using MeRT_Algo;
using MeRT_IBL;

namespace MeRT_BL
{
	/// <summary>
	/// Summary description for AlgoRunner.
	/// </summary>
	[RemotableServer]
	public class AlgoRunner : BLBase, IAlgoRunner
	{
		private SqlConnection cn;

		#region Costruttore Dispose

		private Container components = null;

		public AlgoRunner(IContainer container)
		{
			container.Add(this);
			InitializeComponent();

			cn.ConnectionString = BLBase.SqlConnectionstring;

		}

		public AlgoRunner()
		{
			InitializeComponent();
			cn.ConnectionString = BLBase.SqlConnectionstring;
		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose(bool disposing)
		{
			if (disposing)
			{
				if (components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}

		#endregion

		#region Component Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.cn = new System.Data.SqlClient.SqlConnection();
			// 
			// cn
			// 
			this.cn.ConnectionString = "workstation id=STEFANI;packet size=4096;user id=MeRT_User;data source=BILSVR1;per" +
				"sist security info=False;initial catalog=MeRT";

		}

		#endregion

		public void LanciaAlgoritmo(string mercato, DateTime flowDate, byte flowHour, string algoritmo, double prezzoMassimoAcquisto)
		{
			int progressivoEsecuzione = -1;
			try
			{

				// qui leggo i dati dal DB e creo il record EsecuzioneOra
				cn.Open();
				DatiElaborazione de = ProduciDatiIngresso(mercato, flowDate, flowHour, algoritmo, prezzoMassimoAcquisto, out progressivoEsecuzione);
				cn.Close();

				// qui sparo l'elaborazione all'WS dell'algoritmo
				Algo ws = new Algo();
				WSClient.Setup(ws, "MeRT_Algo");
				ws.Elabora(de);

				byte[] deZip = CreaBlobAlgoIn(de, progressivoEsecuzione);

				cn.Open();
				StoreBlobAlgoIn(mercato, flowDate, flowHour, progressivoEsecuzione, deZip);
				cn.Close();

			}
			catch (Exception e)
			{
				smError(e);
				throw;
			}
			finally
			{
				cn.Dispose();
			}
		}

		private DatiElaborazione ProduciDatiIngresso(string mercato, DateTime flowDate, byte flowHour, string algoritmo, double prezzoMassimoAcquisto, out int progressivoElaborazione)
		{
			Debug.Assert(mercato == "MGP" || mercato == "MA1");
			Debug.Assert(flowHour >= 1 && flowHour <= 25);
			Debug.Assert(algoritmo == "PrezzoUnico" || algoritmo == "PrezzoZonale");


			DatiElaborazione de = new DatiElaborazione();
			de.idElaborazione = Guid.NewGuid().ToString("N");
			de.mercato = (TipoMercato) Enum.Parse(typeof (TipoMercato), mercato, true);
			de.dataFlusso = flowDate;
			de.oraFlusso = flowHour;
			de.Version = "1.0";


			SqlCommand cmd = cn.CreateCommand();
			cmd.CommandText = "AlgoRunner_ProduciDatiIngresso";
			cmd.CommandType = CommandType.StoredProcedure;
			cmd.CommandTimeout = AppSettings.ToInt32("AlgoRunner_ProduciDatiIngresso_Timeout", 30);

			cmd.Parameters.Add("@idElaborazione", de.idElaborazione);
			cmd.Parameters.Add("@codiceMercato", mercato);
			cmd.Parameters.Add("@flowDate", flowDate);
			cmd.Parameters.Add("@flowHour", flowHour);
			cmd.Parameters.Add("@algoritmo", algoritmo);
			cmd.Parameters.Add("@prezzoMassimoAcquisto", prezzoMassimoAcquisto);
			cmd.Parameters.Add(new SqlParameter("@progressivoEsecuzioneOut", SqlDbType.Int, 4, ParameterDirection.Output, false, 0, 0, "", DataRowVersion.Current, null));
			//cmd.Parameters.Add(new SqlParameter("@progressivoEsecuzioneOut", SqlDbType.Int, 4, ParameterDirection.InputOutput, false, 0, 0, "", DataRowVersion.Current, 0));

			using (SqlDataReader rd = cmd.ExecuteReader())
			{
				if (true)
				{
					ClassReader crd = new ClassReader(typeof (Zona), rd);
					crd.MapColName("CodiceZona", "zona");
					crd.MapColName("TipoZona", "tipoZona");
					de.Zona = (Zona[]) crd.Read();
				}

				if (true)
				{
					if (rd.NextResult())
					{
						ClassReader crd = new ClassReader(typeof (VincoloInterzonale), rd);
						de.VincoloInterzonale = (VincoloInterzonale[]) crd.Read();
					}
					else
						de.VincoloInterzonale = new VincoloInterzonale[0];
				}


				if (true)
				{
					ArrayList vgAL = new ArrayList();
					if (rd.NextResult())
					{
						int colNomeVincolo = rd.GetOrdinal("NomeVincolo");
						int colFlussoMassimo = rd.GetOrdinal("FlussoMassimo");
						int colCodceZona = rd.GetOrdinal("CodiceZona");
						int colCoefficienteTrasporto = rd.GetOrdinal("CoefficienteTrasporto");


						VincoloGeneralizzato vgCurr = ReadNextVincoloGeneralizzato(rd, colNomeVincolo, colFlussoMassimo, colCodceZona, colCoefficienteTrasporto);
						VincoloGeneralizzato vgNext = null;
						if (vgCurr != null)
							vgNext = ReadNextVincoloGeneralizzato(rd, colNomeVincolo, colFlussoMassimo, colCodceZona, colCoefficienteTrasporto);

						VincoloGeneralizzato vg = null;
						ArrayList vgcAL = new ArrayList();

						while (vgCurr != null)
						{
							if (vg == null)
							{
								vg = new VincoloGeneralizzato();
								vg.nomeVincolo = vgCurr.nomeVincolo;
								vg.flussoMassimo = vgCurr.flussoMassimo;
								vgAL.Add(vg);
								vgcAL.Clear();
							}

							vgcAL.Add(vgCurr.VincoloGeneralizzatoCoefficiente[0]);

							if (vgNext == null || vgCurr.nomeVincolo != vgNext.nomeVincolo)
							{
								// il prossimo e` un altro VincoloGeneralizzato
								// o sono a EOF
								vg.VincoloGeneralizzatoCoefficiente = (VincoloGeneralizzatoCoefficiente[]) vgcAL.ToArray(typeof (VincoloGeneralizzatoCoefficiente));
								vg = null;
							}


							vgCurr = vgNext;
							if (vgCurr != null)
								vgNext = ReadNextVincoloGeneralizzato(rd, colNomeVincolo, colFlussoMassimo, colCodceZona, colCoefficienteTrasporto);
						}
					}
					de.VincoloGeneralizzato = (VincoloGeneralizzato[]) vgAL.ToArray(typeof (VincoloGeneralizzato));
				}

				if (true)
				{
					if (rd.NextResult())
					{
						//OffertaVendita ov = new OffertaVendita();
						ClassReader crd = new ClassReader(typeof (OffertaVendita), rd);
						crd.MapColName("CodiceGME", "idOfferta");
						crd.MapColName("CodiceZona", "zona");
						crd.MapColName("PrezzoOfferta", "prezzo");
						crd.MapColName("QuantitaOffertaMWh", "quantitaMWh");
						de.OffertaVendita = (OffertaVendita[]) crd.Read();
					}
					else
						de.OffertaVendita = new OffertaVendita[0];
				}

				if (true)
				{
					if (rd.NextResult())
					{
						ClassReader crd = new ClassReader(typeof (OffertaAcquisto), rd);
						crd.MapColName("CodiceGME", "idOfferta");
						crd.MapColName("CodiceZona", "zona");
						crd.MapColName("PrezzoOfferta", "prezzo");
						crd.MapColName("QuantitaOffertaMWh", "quantitaMWh");
						crd.MapColName("PrezzoDaCalcolare", "prezzoDaCalcolare");
						de.OffertaAcquisto = (OffertaAcquisto[]) crd.Read();
					}
					else
						de.OffertaAcquisto = new OffertaAcquisto[0];
				}

				if (true)
				{
					progressivoElaborazione = (int) cmd.Parameters["@progressivoEsecuzioneOut"].Value;
				}
			}

			return de;
		}

		private void StoreBlobAlgoIn(string codiceMercato, DateTime flowDate, byte flowHour, int progressivoEsecuzione, byte[] zip)
		{
			SqlCommand cmd = cn.CreateCommand();

			cmd.CommandText = "dbo.[AlgoRunner_StoreBlobAlgoIn]";
			cmd.CommandTimeout = AppSettings.ToInt32("AlgoRunner_StoreBlobAlgoIn_Timeout", 30);
			cmd.CommandType = CommandType.StoredProcedure;
			cmd.Parameters.Add(new SqlParameter("@RETURN_VALUE", SqlDbType.Int, 4, ParameterDirection.ReturnValue, false, ((Byte) (0)), ((Byte) (0)), "", DataRowVersion.Current, null));
			cmd.Parameters.Add(new SqlParameter("@flowDate", SqlDbType.SmallDateTime));
			cmd.Parameters.Add(new SqlParameter("@flowHour", SqlDbType.TinyInt));
			cmd.Parameters.Add(new SqlParameter("@codiceMercato", SqlDbType.VarChar, 4));
			cmd.Parameters.Add(new SqlParameter("@progressivoEsecuzione", SqlDbType.Int));
			cmd.Parameters.Add(new SqlParameter("@xmlIngressoAlgo", SqlDbType.VarBinary));


			cmd.Parameters["@codiceMercato"].Value = codiceMercato;
			cmd.Parameters["@flowDate"].Value = flowDate;
			cmd.Parameters["@flowHour"].Value = flowHour;
			cmd.Parameters["@progressivoEsecuzione"].Value = progressivoEsecuzione;
			cmd.Parameters["@xmlIngressoAlgo"].Value = zip;

			cmd.ExecuteNonQuery();
		}

		private static byte[] CreaBlobAlgoIn(DatiElaborazione de, int progressivoEsecuzione)
		{
			MemoryStream ms = new MemoryStream();
			XmlTextWriter xw = new XmlTextWriter(ms, Encoding.UTF8);
			XmlSerializer x = new XmlSerializer(typeof (DatiElaborazione));
			xw.Formatting = Formatting.Indented;
			xw.IndentChar = '\t';
			xw.Indentation = 1;
			x.Serialize(xw, de);
			xw.Close();

			byte[] bms = ms.ToArray();
			string nomeFile = string.Format("In_{0:yy}{0:MM}{0:dd}_{1}_{2}_{3}.xml", de.dataFlusso, de.oraFlusso, de.mercato, progressivoEsecuzione);
			return ZipFile.ZipSingleFile(nomeFile, bms);
		}

		#region Implementazione

		private VincoloGeneralizzato ReadNextVincoloGeneralizzato(SqlDataReader rd,
		                                                          int colNomeVincolo,
		                                                          int colFlussoMassimo,
		                                                          int colCodceZona,
		                                                          int colCoefficienteTrasporto
			)
		{
			VincoloGeneralizzato vg = null;
			if (rd.Read())
			{
				vg = new VincoloGeneralizzato();
				vg.nomeVincolo = rd.GetSqlString(colNomeVincolo).Value;
				vg.flussoMassimo = (double) rd.GetSqlDecimal(colFlussoMassimo).Value;
				vg.VincoloGeneralizzatoCoefficiente = new VincoloGeneralizzatoCoefficiente[1];
				vg.VincoloGeneralizzatoCoefficiente[0] = new VincoloGeneralizzatoCoefficiente();
				vg.VincoloGeneralizzatoCoefficiente[0].zona = rd.GetSqlString(colCodceZona).Value;
				vg.VincoloGeneralizzatoCoefficiente[0].coefficienteTrasporto = (double) rd.GetSqlDecimal(colCoefficienteTrasporto).Value;
			}
			return vg;
		}

		#endregion
	}
}