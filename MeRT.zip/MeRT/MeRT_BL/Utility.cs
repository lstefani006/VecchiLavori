using System;
using System.Collections;
using System.Collections.Specialized;
using System.Data.SqlClient;
using System.Reflection;

namespace MeRT_BL
{
	public class ClassReader
	{
		public ClassReader(Type recordType, SqlDataReader rd)
		{
			_recordType = recordType;
			_rd = rd;

			if (!recordType.IsClass)
				throw new ArgumentNullException("recordType", "deve essere una classe!");

			_ci = _recordType.GetConstructor(new Type[] {});
			if (_ci == null)
				throw new ArgumentException("recordType", "il costruttore deve essere senza parametri");

			_map = new NameValueCollection();

		}

		public void MapColName(string dbName, string fieldName)
		{
			if (_recordType.GetMember("fieldName", _bindingFlag) == null)
				throw new ArgumentException("fieldName", "non esiste un campo con questo nome");

			_map.Set(dbName, fieldName);
		}

		public void MapColName(string dbName, FieldInfo fi)
		{
			_map.Set(dbName, fi.Name);
		}


		private void Init()
		{
			_fiValue = new FieldInfo[_rd.FieldCount];
			_fiSpecified = new FieldInfo[_rd.FieldCount];
			for (int f = 0; f < _rd.FieldCount; ++f)
			{
				string colName = _rd.GetName(f);
				if (_map.GetValues(colName) != null)
					colName = _map.GetValues(colName)[0];

				FieldInfo fiValue = _recordType.GetField(colName, _bindingFlag);
				_fiValue[f] = fiValue; // se e` null va bene... lo salto dopo

				if (fiValue != null)
				{
					FieldInfo fiSpecified = _recordType.GetField(colName + "Specified", _bindingFlag);
					if (fiSpecified != null && fiSpecified.FieldType == typeof (bool))
						_fiSpecified[f] = fiSpecified; // se e` null va bene... lo salto dopo
				}
			}
		}

		public Array Read()
		{
			if (_fiValue == null)
				Init();

			_ar = new ArrayList();
			while (_rd.Read())
			{
				object r = _ci.Invoke(null);

				int nf = _rd.FieldCount;
				for (int f = 0; f < nf; ++f)
				{
					FieldInfo fiValue = _fiValue[f];
					if (fiValue == null)
						continue;

					bool colNull = _rd.IsDBNull(f);
					FieldInfo fiSpecified = _fiSpecified[f];
					if (fiSpecified != null)
					{
						bool Specified = !colNull;
						_fiSpecified[f].SetValue(r, Specified);
					}

					if (fiSpecified == null && colNull)
						throw new Exception(string.Format("{0} e` null ma la classe non ha il campo xxxSpecified", _rd.GetName(f)));

					if (colNull == false)
					{
						object colValue = _rd[f];

						if (fiValue.FieldType.IsEnum)
						{
							object v = Enum.Parse(fiValue.FieldType, (string) colValue, true);
							fiValue.SetValue(r, v);
						}
						else if (fiValue.FieldType == typeof (Double))
						{
							object v = Convert.ToDouble(colValue);
							fiValue.SetValue(r, v);
						}
						else
						{
							fiValue.SetValue(r, colValue);
						}
					}
				}

				_ar.Add(r);
			}

			return _ar.ToArray(_recordType);
		}

		private Type _recordType;
		private SqlDataReader _rd;

		private FieldInfo[] _fiValue;
		private FieldInfo[] _fiSpecified;

		private ConstructorInfo _ci;

		private ArrayList _ar;

		private NameValueCollection _map;

		private static BindingFlags _bindingFlag = BindingFlags.IgnoreCase | BindingFlags.Public | BindingFlags.Instance;

	}
}