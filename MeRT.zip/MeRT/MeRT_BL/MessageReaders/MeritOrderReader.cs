using System;
using System.Data;
using System.Data.SqlTypes;
using System.Data.SqlClient;
using System.Xml;
using System.Xml.Serialization;

using MeRT_BL.Messaging.MeritOrderTypes;
using Messaging;
using PIPEDoc;

namespace MeRT_BL.Messaging
{
	public class MeritOrderFacade : TransactionFacade
	{
		public MeritOrderFacade(PIPTransaction tr)
			: base(tr, PIPTransactionAttributes.ReferenceNumber){}

		public override string FA_MarketParticipantNumber
		{
			get
			{
				if (_element == null)
					return PIPTransaction.ReferenceNumber;
				return _element.MarketParticipantNumber;
			}
		}

		public override string FA_TransactionType
		{
			get { return "FA"; }
		}

		public override void Read(XmlReader xr)
		{
			_element = (MeritOrder) _serializer.Deserialize(xr);
		}

		public override void Write(XmlWriter xw)
		{
			if (_element == null)
				return;

			WriteStartPIP(xw);
			_serializer.Serialize(xw, _element);
			WriteEndPIP(xw);
		}
		public override void Execute(object executeState)
		{
			if (this.Valid == false)
				return;

			SqlConnection cn = executeState as SqlConnection;
			if (cn == null)// TODO
				return;
			try
			{
				Offerte_UpdateOrdineMerito.Execute(cn
					, _element.MarketParticipantNumber
					, SimpleType.IntegerFifteenTypeToInt(_element.Value));
			}
			catch (Exception e)
			{
				this.SetError(MessagingError.E0.ToString(), e.Message);
			}
		}

		private static XmlSerializer _serializer = new XmlSerializer(typeof(MeritOrder));
		private MeritOrder _element = null;
	}
	#region Offerte_UpdateOrdineMerito Wrapper
	/// <summary>
	/// This class is a wrapper for the Offerte_UpdateOrdineMerito stored procedure.
	/// </summary>
	internal class Offerte_UpdateOrdineMerito
	{
		#region Member Variables
		protected int _recordsAffected = -1;
		protected int _returnValue = 0;
		protected SqlString _codiceGME = SqlString.Null;
		protected bool _codiceGMESet = false;
		protected SqlInt32 _ordineMerito = SqlInt32.Null;
		protected bool _ordineMeritoSet = false;
		#endregion
		
		#region Constructors
		public Offerte_UpdateOrdineMerito()
		{
		}
		#endregion
		
		#region Public Properties
		/// <summary>
		/// Gets the return value from the Offerte_UpdateOrdineMerito stored procedure.
		/// </summary>
		public int ReturnValue
		{
			get {return _returnValue;}
		}
		
		/// <summary>
		/// Gets the number of rows changed, inserted, or deleted by execution of the Offerte_UpdateOrdineMerito stored procedure.
		/// </summary>
		public int RecordsAffected
		{
			get {return _recordsAffected;}
		}
		
		public SqlString codiceGME
		{
			get {return _codiceGME;}
			set
			{
				_codiceGME = value;
				_codiceGMESet = true;
			}
		}

		public SqlInt32 ordineMerito
		{
			get {return _ordineMerito;}
			set
			{
				_ordineMerito = value;
				_ordineMeritoSet = true;
			}
		}
		#endregion
		
		#region Execute Methods
		/// <summary>
		/// This method calls the Offerte_UpdateOrdineMerito stored procedure.
		/// </summary>
		public virtual void Execute(SqlConnection cn)
		{
			SqlCommand cmd = cn.CreateCommand();
			
			try
			{
				cmd.CommandText = "[dbo].[Offerte_UpdateOrdineMerito]";
				cmd.CommandType = CommandType.StoredProcedure;
				
				#region Populate Parameters
				SqlParameter prmReturnValue = cmd.Parameters.Add("@RETURN_VALUE", SqlDbType.Int);
				prmReturnValue.Direction = ParameterDirection.ReturnValue;
				
				SqlParameter prmcodiceGME = cmd.Parameters.Add("@codiceGME", SqlDbType.VarChar);
				prmcodiceGME.Direction = ParameterDirection.Input;
				prmcodiceGME.Size = 32;
				if (_codiceGMESet == true || this.codiceGME.IsNull == false)
				{
					prmcodiceGME.Value = this.codiceGME;
				}
				
				SqlParameter prmordineMerito = cmd.Parameters.Add("@ordineMerito", SqlDbType.Int);
				prmordineMerito.Direction = ParameterDirection.Input;
				if (_ordineMeritoSet == true || this.ordineMerito.IsNull == false)
				{
					prmordineMerito.Value = this.ordineMerito;
				}
				#endregion
				
				#region Execute Command
				_recordsAffected = cmd.ExecuteNonQuery();
				#endregion
				
				#region Get Output Parameters
				if (prmReturnValue.Value != null && prmReturnValue.Value != DBNull.Value)
				{
					_returnValue = (int)prmReturnValue.Value;
				}
				
				#endregion
			}
			finally
			{
				cmd.Dispose();
			}
		}
		
		/// <summary>
		/// This method calls the Offerte_UpdateOrdineMerito stored procedure.
		/// </summary>
		/// <param name="cn">La connessione da usare</param>
		/// <param name="codiceGME"></param>
		/// <param name="ordineMerito"></param>
		public static void Execute(
			#region Parameters
			SqlConnection cn,
			SqlString codiceGME,
			SqlInt32 ordineMerito
			#endregion
			)
		{
			Offerte_UpdateOrdineMerito offerte_UpdateOrdineMerito = new Offerte_UpdateOrdineMerito();
			
			#region Assign Property Values
			offerte_UpdateOrdineMerito.codiceGME = codiceGME;
			offerte_UpdateOrdineMerito.ordineMerito = ordineMerito;
			#endregion
			
			offerte_UpdateOrdineMerito.Execute(cn);
			
			#region Get Property Values
			
			#endregion
		}
		#endregion
	}
	#endregion
}
