using System;
using System.Collections;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Globalization;
using System.IO;
using System.Text;
using System.Xml;
using System.Xml.Serialization;

using GME.BL;
using GME.Zip;
using MeRT_IBL;
using Messaging;
using PIPEDoc;

namespace MeRT_BL.Messaging
{
	public enum MessagingError
	{
		E0 = 0,
		Z1,
		Z2,
		Z3,
		Z4,
		Z5,
        Z6,
		Z7,
		Z8,
		Z9,
		Z10,
		Z11,
		Z12,
	}
	public class MessagingExecption : Exception
	{
		public MessagingExecption(MessagingError code, string fmt, params object[] args)
		{
			Msg = string.Format(fmt, args);
			Code = code;
		}

		public MessagingExecption(MessagingError code, string fmt)
		{
			Msg = fmt;
			Code = code;
		}

		public readonly string Msg;
		public readonly MessagingError Code;

	}
	public class SimpleType
	{
		private static CultureInfo _ci = new CultureInfo("it-IT");

		public static int IntegerFifteenTypeToInt(string integerFifteenType)
		{
			//TODO 999999999999999 > 2147483647
			return int.Parse(integerFifteenType, _ci);
		}
		public static double LocaleDecimalToDouble(string localeDecimal)
		{
			return double.Parse(localeDecimal, _ci);
		}
		public static byte HourIntervalTypeToByte(string hourInterval)
		{
			return byte.Parse(hourInterval, _ci);
		}
		public static DateTime DateTypeToDateTime(string date)
		{
			return DateTime.ParseExact(date, "yyyyMMdd", _ci);
		}
	}

	[RemotableServer]
	public class TransactionReader : BLBase, ITransactionReader
	{

		#region Costruttori cn ecc

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private Container components = null;

		private SqlConnection cn = new SqlConnection();

		public TransactionReader(IContainer container)
		{
			container.Add(this);
			InitializeComponent();
			cn.ConnectionString = SqlConnectionstring;
		}

		public TransactionReader()
		{
			InitializeComponent();
			cn.ConnectionString = SqlConnectionstring;
		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose(bool disposing)
		{
			if (disposing)
				if (components != null)
					components.Dispose();

			base.Dispose(disposing);
		}

		#endregion

		#region Component Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{

		}

		#endregion

		public void ReadMessage(string codiceOperatoreCanale, string codiceUtenteCanale, string nomeFile, string encoding, byte[] fileXml)
		{
			try
			{
				// qui si legge il messaggio
				Message msg = null;
				if (true)
				{
					MessageReader rd = new MessageReader();

					rd.AddToFactoryTable("BidSubmittalMA1", typeof (BidSubmittalMA1Facade));
					rd.AddToFactoryTable("BidSubmittalMGP", typeof (BidSubmittalMGPFacade));
					rd.AddToFactoryTable("BidSubmittalMSD", typeof (BidSubmittalMSDFacade));
					rd.AddToFactoryTable("EstimatedDemandInformation", typeof (EstimatedDemandInformationFacade));
					rd.AddToFactoryTable("EstimatedPriceInformation", typeof (EstimatedPriceInformationFacade));
					rd.AddToFactoryTable("MarketParticipant", typeof (MarketParticipantFacade));
					rd.AddToFactoryTable("MeritOrder", typeof (MeritOrderFacade));
					rd.AddToFactoryTable("MustRunSchedule", typeof (MustRunScheduleFacade));
					rd.AddToFactoryTable("RelevantExchangePoint", typeof (RelevantExchangePointFacade));
					rd.AddToFactoryTable("UnitInformation", typeof (UnitInformationFacade));
					rd.AddToFactoryTable("UnitRelate", typeof (UnitRelateFacade));
					rd.AddToFactoryTable("ZoneDefinition", typeof (ZoneDefinitionFacade));
					rd.AddToFactoryTable("ZoneInformation", typeof (ZoneInformationFacade));

					rd.AddRootOperator("IDGME"); // TODO mettere una configurazione.... prima pensarci.

					// TODO mettere a posto gli schemi (dove sono ecc)
					//string fileSchema = @"..\..\Schemi\PIPEDocument.xsd";
					string fileSchema = GME.Utility.AppSettings.ToString("Messaging_SchemaFile");
					if (!Path.IsPathRooted(fileSchema))
						fileSchema = Path.Combine(AppDomain.CurrentDomain.SetupInformation.ApplicationBase, fileSchema);

					// qui si fa la lettura
					XmlReader xr = new Translater().ToXmlReader(new XmlTextReader(new MemoryStream(fileXml)));
					msg = rd.ReadMessage(fileSchema, xr, codiceOperatoreCanale);
					xr.Close();
				}

				// qui msg potrebbe essere
				// 1) tutto non valido (es xml non ben formattato)
				// 2) valido con transazioni (che possono essere valide o no indifferentemente)

				int IdMessageIn;
				if (true)
				{
					// momorizzo il messaggio in ingresso.
					MessageIn mi = new MessageIn();
					mi.CodiceOperatore = msg.PIPEDocument.TradingPartnerDirectory.Sender.TradingPartner.CompanyIdentifier;
					mi.CodiceUtente = codiceUtenteCanale;
					mi.NomeFile = nomeFile;
					mi.Encoding = encoding;
					mi.ReferenceNumber = msg.PIPEDocument.ReferenceNumber;
					mi.CreationDate = DateTime.Now;
					mi.Version = "1.0";
					mi.MessageBlob = fileXml;
					mi.Store(cn, MessageIn.Action.Comprimi | MessageIn.Action.Controfirma, out IdMessageIn);
				}

				if (msg.Valid) // il messaggio e` valido
				{
					// se e` valido elaboro tutte le transazioni del messaggio
					for (int progressivoTransazione = 0; progressivoTransazione < msg.Transaction.Count; ++progressivoTransazione)
					{
						TransactionFacade tr = msg.Transaction[progressivoTransazione];

						// qui si legge la transazione, la si valida, si stora nel db (se tutto va bene)
						if (tr.Valid)
						{
							tr.Execute(cn);
							// notare che a fronte dell'elaborazione, una tr valida
							// puo` andare in stato non valido
						}

						// qui scrivo i dati della transazione nella tabella TransazioneIN.
						// lo faccio dopo zi.Elabora(cn) dato che devo valorizzare
						// lo stato della transazione in TransazioneIN con tr.Valid
						if (true)
						{
							MemoryStream ms = new MemoryStream();
							XmlTextWriter xw = new XmlTextWriter(ms, Encoding.UTF8);
							xw.Indentation = 1;
							xw.IndentChar = ' ';
							xw.Formatting = Formatting.Indented;
							tr.Write(xw);
							xw.Close();
							string nomeTR = string.Format("TR_{0}_{1}.xml", IdMessageIn, progressivoTransazione);
							byte[] trBlob = ZipFile.ZipSingleFile(nomeTR, ms.ToArray());

							string statoTransazione = tr.Valid ? "V" : "F";

							Messaging_StoreTransazioneIN.Execute(
								cn, 
								IdMessageIn, 
								progressivoTransazione,
								tr.FA_TransactionType, 
								tr.PIPTransaction.ReferenceNumber,
								tr.FA_MarketParticipantNumber,
								trBlob, 
								statoTransazione);
						}
					}
				}

				// memorizzo l'FA associato al messaggio (sia se il messaggio e` valido che non)
				int IdMessageOut = 0;
				if (true)
				{
					string faReferenceNumber = MessageHelper.GenerateId30();
					MemoryStream ms = new MemoryStream();
					XmlTextWriter xw = new XmlTextWriter(ms, Encoding.UTF8);
					xw.Indentation = 1;
					xw.IndentChar = ' ';
					xw.Formatting = Formatting.Indented;
					msg.WriteFA(xw, faReferenceNumber);
					xw.Close();
					string nomeFileFA = "FA_" + nomeFile;
					byte[] fa = ZipFile.ZipSingleFile(nomeFileFA, ms.ToArray());

					SqlInt32 rr = new SqlInt32(0);

					Messaging_StoreMessageOUT.Execute(
						cn,
						msg.PIPEDocument.TradingPartnerDirectory.Sender.TradingPartner.CompanyIdentifier,
						nomeFileFA,
						"ZIP",
						false,
						"UTF8",
						faReferenceNumber,
						DateTime.Now, 
						"1.0",
						fa,
						IdMessageIn,
						ref rr);
					IdMessageOut = rr.Value;
				}

				if (msg.Valid == true)
				{
					// se e` valido scrivo il risultato per ogni transazione (FA)

					for (int progressivoTransazione = 0; progressivoTransazione < msg.Transaction.Count; ++progressivoTransazione)
					{
						TransactionFacade tr = msg.Transaction[progressivoTransazione];

						MemoryStream ms = new MemoryStream();
						XmlTextWriter xw = new XmlTextWriter(ms, Encoding.UTF8);
						xw.Indentation = 1;
						xw.IndentChar = ' ';
						xw.Formatting = Formatting.Indented;
						tr.WriteFA(xw);
						xw.Close();
						string nomeTR = string.Format("FA_{0}_{1}.xml", IdMessageIn, progressivoTransazione);
						byte[] faBlob = ZipFile.ZipSingleFile(nomeTR, ms.ToArray());


						Messaging_StoreTransazioneOUT.Execute(cn,
							IdMessageOut, 
							progressivoTransazione, 
							tr.FA_TransactionType,
							MessageHelper.GenerateId30(),
							msg.PIPEDocument.TradingPartnerDirectory.Sender.TradingPartner.CompanyIdentifier,  // ???
							faBlob,
							tr.FA_MarketParticipantNumber,
							IdMessageIn,
							progressivoTransazione);
					}
				}
			}
			catch (Exception ex)
			{
				smError(ex);
				throw;
			}
		}
		private class Translater : MessageTranslater
		{
			private readonly XmlNamespaceManager _namespaceManager = null;
			public Translater()
			{
				_namespaceManager = new XmlNamespaceManager(new NameTable());
				_namespaceManager.AddNamespace("s", "urn:XML-PIPE");
			}
			protected override void TranslatePIPTransaction(XmlElement transaction)
			{
				XmlElement market = transaction.SelectSingleNode("//s:BidSubmittal/s:Market", _namespaceManager) as XmlElement;
				if (market != null)
				{
					string newName = null;
					switch (market.InnerText)
					{
						case "MA1":
							newName = "BidSubmittalMA1";
							break;
						case "MGP":
							newName = "BidSubmittalMGP";
							break;
						case"MSD":
							newName = "BidSubmittalMSD";
							break;
						default:
							return;
					}
					string xml = transaction.InnerXml;
					xml = xml.Replace("BidSubmittal", newName);
					transaction.InnerXml = xml;
				}
			}
		}
	}
	public class MessageIn
	{
		public string CodiceOperatore;
		public string CodiceUtente;
		public string NomeFile;
		private string Compressed;
		private bool FirmatoInIngresso;
		private bool Controfirmato;
		public string Encoding;
		public string ReferenceNumber;
		public DateTime CreationDate;
		public string Version;
		public byte[] MessageBlob;

		[Flags]
			public enum Action
		{
			Controfirma = 1,
			Comprimi = 2
		}

		private void Comprimi()
		{
			if (Compressed == null || Compressed == string.Empty)
			{
				MessageBlob = ZipFile.ZipSingleFile(NomeFile, MessageBlob);
				Compressed = "ZIP";
			}
		}

		private void ControFirma()
		{
			if (FirmatoInIngresso == false && IsFirmatoInIngresso())
				FirmatoInIngresso = true;

			if (FirmatoInIngresso == true)
			{
				Controfirmato = true;
				// TODO LEO
				// fai la firma digitale del file invocendo il WS che sta nelle galassie
			}
		}

		public bool IsFirmatoInIngresso()
		{
			// TODO leggere MessageBlob e capire se e` firmato
			return false;
		}


		public void Store(SqlConnection cn, Action action, out int IdMessageIn)
		{
			if ((action & Action.Controfirma) > 0)
				ControFirma();

			if ((action & Action.Comprimi) > 0)
				Comprimi();


			SqlInt32 rr = new SqlInt32(0);
			Messaging_StoreMessageIN.Execute(
				cn, 
				CodiceOperatore, 
				CodiceUtente, 
				NomeFile, 
				Compressed, 
				FirmatoInIngresso, 
				Controfirmato, Encoding, ReferenceNumber, CreationDate, Version, MessageBlob, ref rr);

			IdMessageIn = rr.Value;

		}
	}
		#region Messaging_StoreMessageIN Wrapper
	/// <summary>
	/// This class is a wrapper for the Messaging_StoreMessageIN stored procedure.
	/// </summary>
	public class Messaging_StoreMessageIN
	{
		#region Member Variables
		protected int _recordsAffected = -1;
		protected int _returnValue = 0;
		protected SqlString _codiceOperatore = SqlString.Null;
		protected bool _codiceOperatoreSet = false;
		protected SqlString _codiceUtente = SqlString.Null;
		protected bool _codiceUtenteSet = false;
		protected SqlString _nomeFile = SqlString.Null;
		protected bool _nomeFileSet = false;
		protected SqlString _compressed = SqlString.Null;
		protected bool _compressedSet = false;
		protected SqlBoolean _firmatoInIngresso = SqlBoolean.Null;
		protected bool _firmatoInIngressoSet = false;
		protected SqlBoolean _controfirmato = SqlBoolean.Null;
		protected bool _controfirmatoSet = false;
		protected SqlString _encoding = SqlString.Null;
		protected bool _encodingSet = false;
		protected SqlString _referenceNumber = SqlString.Null;
		protected bool _referenceNumberSet = false;
		protected SqlDateTime _creationDate = SqlDateTime.Null;
		protected bool _creationDateSet = false;
		protected SqlString _version = SqlString.Null;
		protected bool _versionSet = false;
		protected SqlBinary _messageBlob = SqlBinary.Null;
		protected bool _messageBlobSet = false;
		protected SqlInt32 _idMessageIn = SqlInt32.Null;
		protected bool _idMessageInSet = false;
		#endregion
		
		#region Constructors
		public Messaging_StoreMessageIN()
		{
		}
		#endregion
		
		#region Public Properties
		/// <summary>
		/// Gets the return value from the Messaging_StoreMessageIN stored procedure.
		/// </summary>
		public int ReturnValue
		{
			get {return _returnValue;}
		}
		
		/// <summary>
		/// Gets the number of rows changed, inserted, or deleted by execution of the Messaging_StoreMessageIN stored procedure.
		/// </summary>
		public int RecordsAffected
		{
			get {return _recordsAffected;}
		}
		
		public SqlString CodiceOperatore
		{
			get {return _codiceOperatore;}
			set
			{
				_codiceOperatore = value;
				_codiceOperatoreSet = true;
			}
		}

		public SqlString CodiceUtente
		{
			get {return _codiceUtente;}
			set
			{
				_codiceUtente = value;
				_codiceUtenteSet = true;
			}
		}

		public SqlString NomeFile
		{
			get {return _nomeFile;}
			set
			{
				_nomeFile = value;
				_nomeFileSet = true;
			}
		}

		public SqlString Compressed
		{
			get {return _compressed;}
			set
			{
				_compressed = value;
				_compressedSet = true;
			}
		}

		public SqlBoolean FirmatoInIngresso
		{
			get {return _firmatoInIngresso;}
			set
			{
				_firmatoInIngresso = value;
				_firmatoInIngressoSet = true;
			}
		}

		public SqlBoolean Controfirmato
		{
			get {return _controfirmato;}
			set
			{
				_controfirmato = value;
				_controfirmatoSet = true;
			}
		}

		public SqlString Encoding
		{
			get {return _encoding;}
			set
			{
				_encoding = value;
				_encodingSet = true;
			}
		}

		public SqlString ReferenceNumber
		{
			get {return _referenceNumber;}
			set
			{
				_referenceNumber = value;
				_referenceNumberSet = true;
			}
		}

		public SqlDateTime CreationDate
		{
			get {return _creationDate;}
			set
			{
				_creationDate = value;
				_creationDateSet = true;
			}
		}

		public SqlString Version
		{
			get {return _version;}
			set
			{
				_version = value;
				_versionSet = true;
			}
		}

		public SqlBinary MessageBlob
		{
			get {return _messageBlob;}
			set
			{
				_messageBlob = value;
				_messageBlobSet = true;
			}
		}

		public SqlInt32 IdMessageIn
		{
			get {return _idMessageIn;}
			set
			{
				_idMessageIn = value;
				_idMessageInSet = true;
			}
		}
		#endregion
		
		#region Execute Methods
		/// <summary>
		/// This method calls the Messaging_StoreMessageIN stored procedure.
		/// </summary>
		public virtual void Execute(SqlConnection cn)
		{
			SqlCommand cmd = cn.CreateCommand();
			
			try
			{
				//cmd.CommandText = "[dbo].[Messaging_StoreMessageIN]";
				cmd.CommandText = "Messaging_StoreMessageIN";
				cmd.CommandType = CommandType.StoredProcedure;
				
				#region Populate Parameters
				SqlParameter prmReturnValue = cmd.Parameters.Add("@RETURN_VALUE", SqlDbType.Int);
				prmReturnValue.Direction = ParameterDirection.ReturnValue;
				
				SqlParameter prmCodiceOperatore = cmd.Parameters.Add("@CodiceOperatore", SqlDbType.VarChar);
				prmCodiceOperatore.Direction = ParameterDirection.Input;
				prmCodiceOperatore.Size = 16;
				if (_codiceOperatoreSet == true || this.CodiceOperatore.IsNull == false)
				{
					prmCodiceOperatore.Value = this.CodiceOperatore;
				}
				
				SqlParameter prmCodiceUtente = cmd.Parameters.Add("@CodiceUtente", SqlDbType.VarChar);
				prmCodiceUtente.Direction = ParameterDirection.Input;
				prmCodiceUtente.Size = 16;
				if (_codiceUtenteSet == true || this.CodiceUtente.IsNull == false)
				{
					prmCodiceUtente.Value = this.CodiceUtente;
				}
				
				SqlParameter prmNomeFile = cmd.Parameters.Add("@NomeFile", SqlDbType.VarChar);
				prmNomeFile.Direction = ParameterDirection.Input;
				prmNomeFile.Size = 512;
				if (_nomeFileSet == true || this.NomeFile.IsNull == false)
				{
					prmNomeFile.Value = this.NomeFile;
				}
				
				SqlParameter prmCompressed = cmd.Parameters.Add("@Compressed", SqlDbType.VarChar);
				prmCompressed.Direction = ParameterDirection.Input;
				prmCompressed.Size = 8;
				if (_compressedSet == true || this.Compressed.IsNull == false)
				{
					prmCompressed.Value = this.Compressed;
				}
				
				SqlParameter prmFirmatoInIngresso = cmd.Parameters.Add("@FirmatoInIngresso", SqlDbType.Bit);
				prmFirmatoInIngresso.Direction = ParameterDirection.Input;
				if (_firmatoInIngressoSet == true || this.FirmatoInIngresso.IsNull == false)
				{
					prmFirmatoInIngresso.Value = this.FirmatoInIngresso;
				}
				
				SqlParameter prmControfirmato = cmd.Parameters.Add("@Controfirmato", SqlDbType.Bit);
				prmControfirmato.Direction = ParameterDirection.Input;
				if (_controfirmatoSet == true || this.Controfirmato.IsNull == false)
				{
					prmControfirmato.Value = this.Controfirmato;
				}
				
				SqlParameter prmEncoding = cmd.Parameters.Add("@Encoding", SqlDbType.VarChar);
				prmEncoding.Direction = ParameterDirection.Input;
				prmEncoding.Size = 16;
				if (_encodingSet == true || this.Encoding.IsNull == false)
				{
					prmEncoding.Value = this.Encoding;
				}
				
				SqlParameter prmReferenceNumber = cmd.Parameters.Add("@ReferenceNumber", SqlDbType.VarChar);
				prmReferenceNumber.Direction = ParameterDirection.Input;
				prmReferenceNumber.Size = 30;
				if (_referenceNumberSet == true || this.ReferenceNumber.IsNull == false)
				{
					prmReferenceNumber.Value = this.ReferenceNumber;
				}
				
				SqlParameter prmCreationDate = cmd.Parameters.Add("@CreationDate", SqlDbType.DateTime);
				prmCreationDate.Direction = ParameterDirection.Input;
				if (_creationDateSet == true || this.CreationDate.IsNull == false)
				{
					prmCreationDate.Value = this.CreationDate;
				}
				
				SqlParameter prmVersion = cmd.Parameters.Add("@Version", SqlDbType.VarChar);
				prmVersion.Direction = ParameterDirection.Input;
				prmVersion.Size = 5;
				if (_versionSet == true || this.Version.IsNull == false)
				{
					prmVersion.Value = this.Version;
				}
				
				SqlParameter prmMessageBlob = cmd.Parameters.Add("@MessageBlob", SqlDbType.Image);
				prmMessageBlob.Direction = ParameterDirection.Input;
				if (_messageBlobSet == true || this.MessageBlob.IsNull == false)
				{
					prmMessageBlob.Value = this.MessageBlob;
				}
				
				SqlParameter prmIdMessageIn = cmd.Parameters.Add("@IdMessageIn", SqlDbType.Int);
				if (_idMessageInSet == true)
				{
					prmIdMessageIn.Direction = ParameterDirection.InputOutput;
				}
				else
				{
					prmIdMessageIn.Direction = ParameterDirection.Output;
				}
				if (_idMessageInSet == true || this.IdMessageIn.IsNull == false)
				{
					prmIdMessageIn.Value = this.IdMessageIn;
				}
				#endregion
				
				#region Execute Command
				cn.Open();
				_recordsAffected = cmd.ExecuteNonQuery();
				#endregion
				
				#region Get Output Parameters
				if (prmReturnValue.Value != null && prmReturnValue.Value != DBNull.Value)
				{
					_returnValue = (int)prmReturnValue.Value;
				}
				
				if (prmIdMessageIn != null && prmIdMessageIn.Value != null)
				{
					if (prmIdMessageIn.Value is SqlInt32)
					{
						this.IdMessageIn = (SqlInt32)prmIdMessageIn.Value;
					}
					else
					{
						if (prmIdMessageIn.Value != DBNull.Value)
						{
							this.IdMessageIn = new SqlInt32((int)prmIdMessageIn.Value);
						}
						else
						{
							this.IdMessageIn = SqlInt32.Null;
						}
					}
				}
				else
				{
					this.IdMessageIn = SqlInt32.Null;
				}
				#endregion
			}
			finally
			{
				cmd.Dispose();
			}
		}
		
		/// <summary>
		/// This method calls the Messaging_StoreMessageIN stored procedure.
		/// </summary>
		/// <param name="cn">La connessione da usare</param>
		/// <param name="codiceOperatore"></param>
		/// <param name="codiceUtente"></param>
		/// <param name="nomeFile"></param>
		/// <param name="compressed"></param>
		/// <param name="firmatoInIngresso"></param>
		/// <param name="controfirmato"></param>
		/// <param name="encoding"></param>
		/// <param name="referenceNumber"></param>
		/// <param name="creationDate"></param>
		/// <param name="version"></param>
		/// <param name="messageBlob"></param>
		/// <param name="idMessageIn"></param>
		public static void Execute(
			#region Parameters
			SqlConnection cn,
			SqlString codiceOperatore,
			SqlString codiceUtente,
			SqlString nomeFile,
			SqlString compressed,
			SqlBoolean firmatoInIngresso,
			SqlBoolean controfirmato,
			SqlString encoding,
			SqlString referenceNumber,
			SqlDateTime creationDate,
			SqlString version,
			SqlBinary messageBlob,
			ref SqlInt32 idMessageIn
			#endregion
			)
		{
			Messaging_StoreMessageIN messaging_StoreMessageIN = new Messaging_StoreMessageIN();
			
			#region Assign Property Values
			messaging_StoreMessageIN.CodiceOperatore = codiceOperatore;
			messaging_StoreMessageIN.CodiceUtente = codiceUtente;
			messaging_StoreMessageIN.NomeFile = nomeFile;
			messaging_StoreMessageIN.Compressed = compressed;
			messaging_StoreMessageIN.FirmatoInIngresso = firmatoInIngresso;
			messaging_StoreMessageIN.Controfirmato = controfirmato;
			messaging_StoreMessageIN.Encoding = encoding;
			messaging_StoreMessageIN.ReferenceNumber = referenceNumber;
			messaging_StoreMessageIN.CreationDate = creationDate;
			messaging_StoreMessageIN.Version = version;
			messaging_StoreMessageIN.MessageBlob = messageBlob;
			messaging_StoreMessageIN.IdMessageIn = idMessageIn;
			#endregion
			
			messaging_StoreMessageIN.Execute(cn);
			
			#region Get Property Values
			idMessageIn = messaging_StoreMessageIN.IdMessageIn;
			#endregion
		}
		#endregion
	}
	#endregion
	
	
	#region Messaging_StoreTransazioneIN Wrapper
	/// <summary>
	/// This class is a wrapper for the Messaging_StoreTransazioneIN stored procedure.
	/// </summary>
	public class Messaging_StoreTransazioneIN
	{
		#region Member Variables
		protected int _recordsAffected = -1;
		protected int _returnValue = 0;
		protected SqlInt32 _idMessageIn = SqlInt32.Null;
		protected bool _idMessageInSet = false;
		protected SqlInt32 _progressivoTransazioneIn = SqlInt32.Null;
		protected bool _progressivoTransazioneInSet = false;
		protected SqlString _tipoTransazioneIn = SqlString.Null;
		protected bool _tipoTransazioneInSet = false;
		protected SqlString _referenceNumber = SqlString.Null;
		protected bool _referenceNumberSet = false;
		protected SqlString _marketParticipantNumber = SqlString.Null;
		protected bool _marketParticipantNumberSet = false;
		protected SqlBinary _transactionBlob = SqlBinary.Null;
		protected bool _transactionBlobSet = false;
		protected SqlString _statoTransazioneIn = SqlString.Null;
		protected bool _statoTransazioneInSet = false;
		#endregion
		
		#region Constructors
		public Messaging_StoreTransazioneIN()
		{
		}
		#endregion
		
		#region Public Properties
		/// <summary>
		/// Gets the return value from the Messaging_StoreTransazioneIN stored procedure.
		/// </summary>
		public int ReturnValue
		{
			get {return _returnValue;}
		}
		
		/// <summary>
		/// Gets the number of rows changed, inserted, or deleted by execution of the Messaging_StoreTransazioneIN stored procedure.
		/// </summary>
		public int RecordsAffected
		{
			get {return _recordsAffected;}
		}
		
		public SqlInt32 IdMessageIn
		{
			get {return _idMessageIn;}
			set
			{
				_idMessageIn = value;
				_idMessageInSet = true;
			}
		}

		public SqlInt32 ProgressivoTransazioneIn
		{
			get {return _progressivoTransazioneIn;}
			set
			{
				_progressivoTransazioneIn = value;
				_progressivoTransazioneInSet = true;
			}
		}

		public SqlString TipoTransazioneIn
		{
			get {return _tipoTransazioneIn;}
			set
			{
				_tipoTransazioneIn = value;
				_tipoTransazioneInSet = true;
			}
		}

		public SqlString ReferenceNumber
		{
			get {return _referenceNumber;}
			set
			{
				_referenceNumber = value;
				_referenceNumberSet = true;
			}
		}

		public SqlString MarketParticipantNumber
		{
			get {return _marketParticipantNumber;}
			set
			{
				_marketParticipantNumber = value;
				_marketParticipantNumberSet = true;
			}
		}

		public SqlBinary TransactionBlob
		{
			get {return _transactionBlob;}
			set
			{
				_transactionBlob = value;
				_transactionBlobSet = true;
			}
		}

		public SqlString StatoTransazioneIn
		{
			get {return _statoTransazioneIn;}
			set
			{
				_statoTransazioneIn = value;
				_statoTransazioneInSet = true;
			}
		}
		#endregion
		
		#region Execute Methods
		/// <summary>
		/// This method calls the Messaging_StoreTransazioneIN stored procedure.
		/// </summary>
		public virtual void Execute(SqlConnection cn)
		{
			SqlCommand cmd = cn.CreateCommand();
			
			try
			{
				cmd.CommandText = "[dbo].[Messaging_StoreTransazioneIN]";
				cmd.CommandType = CommandType.StoredProcedure;
				
				#region Populate Parameters
				SqlParameter prmReturnValue = cmd.Parameters.Add("@RETURN_VALUE", SqlDbType.Int);
				prmReturnValue.Direction = ParameterDirection.ReturnValue;
				
				SqlParameter prmIdMessageIn = cmd.Parameters.Add("@IdMessageIn", SqlDbType.Int);
				prmIdMessageIn.Direction = ParameterDirection.Input;
				if (_idMessageInSet == true || this.IdMessageIn.IsNull == false)
				{
					prmIdMessageIn.Value = this.IdMessageIn;
				}
				
				SqlParameter prmProgressivoTransazioneIn = cmd.Parameters.Add("@ProgressivoTransazioneIn", SqlDbType.Int);
				prmProgressivoTransazioneIn.Direction = ParameterDirection.Input;
				if (_progressivoTransazioneInSet == true || this.ProgressivoTransazioneIn.IsNull == false)
				{
					prmProgressivoTransazioneIn.Value = this.ProgressivoTransazioneIn;
				}
				
				SqlParameter prmTipoTransazioneIn = cmd.Parameters.Add("@TipoTransazioneIn", SqlDbType.VarChar);
				prmTipoTransazioneIn.Direction = ParameterDirection.Input;
				prmTipoTransazioneIn.Size = 6;
				if (_tipoTransazioneInSet == true || this.TipoTransazioneIn.IsNull == false)
				{
					prmTipoTransazioneIn.Value = this.TipoTransazioneIn;
				}
				
				SqlParameter prmReferenceNumber = cmd.Parameters.Add("@ReferenceNumber", SqlDbType.VarChar);
				prmReferenceNumber.Direction = ParameterDirection.Input;
				prmReferenceNumber.Size = 30;
				if (_referenceNumberSet == true || this.ReferenceNumber.IsNull == false)
				{
					prmReferenceNumber.Value = this.ReferenceNumber;
				}
				
				SqlParameter prmMarketParticipantNumber = cmd.Parameters.Add("@MarketParticipantNumber", SqlDbType.VarChar);
				prmMarketParticipantNumber.Direction = ParameterDirection.Input;
				prmMarketParticipantNumber.Size = 30;
				if (_marketParticipantNumberSet == true || this.MarketParticipantNumber.IsNull == false)
				{
					prmMarketParticipantNumber.Value = this.MarketParticipantNumber;
				}
				
				SqlParameter prmTransactionBlob = cmd.Parameters.Add("@TransactionBlob", SqlDbType.Image);
				prmTransactionBlob.Direction = ParameterDirection.Input;
				if (_transactionBlobSet == true || this.TransactionBlob.IsNull == false)
				{
					prmTransactionBlob.Value = this.TransactionBlob;
				}
				
				SqlParameter prmStatoTransazioneIn = cmd.Parameters.Add("@StatoTransazioneIn", SqlDbType.Char);
				prmStatoTransazioneIn.Direction = ParameterDirection.Input;
				prmStatoTransazioneIn.Size = 1;
				if (_statoTransazioneInSet == true || this.StatoTransazioneIn.IsNull == false)
				{
					prmStatoTransazioneIn.Value = this.StatoTransazioneIn;
				}
				#endregion
				
				#region Execute Command
				_recordsAffected = cmd.ExecuteNonQuery();
				#endregion
				
				#region Get Output Parameters
				if (prmReturnValue.Value != null && prmReturnValue.Value != DBNull.Value)
				{
					_returnValue = (int)prmReturnValue.Value;
				}
				
				#endregion
			}
			finally
			{
				cmd.Dispose();
			}
		}
		
		/// <summary>
		/// This method calls the Messaging_StoreTransazioneIN stored procedure.
		/// </summary>
		/// <param name="cn">La connessione da usare</param>
		/// <param name="idMessageIn"></param>
		/// <param name="progressivoTransazioneIn"></param>
		/// <param name="tipoTransazioneIn"></param>
		/// <param name="referenceNumber"></param>
		/// <param name="marketParticipantNumber"></param>
		/// <param name="transactionBlob"></param>
		/// <param name="statoTransazioneIn"></param>
		public static void Execute(
			#region Parameters
			SqlConnection cn,
			SqlInt32 idMessageIn,
			SqlInt32 progressivoTransazioneIn,
			SqlString tipoTransazioneIn,
			SqlString referenceNumber,
			SqlString marketParticipantNumber,
			SqlBinary transactionBlob,
			SqlString statoTransazioneIn
			#endregion
			)
		{
			Messaging_StoreTransazioneIN messaging_StoreTransazioneIN = new Messaging_StoreTransazioneIN();
			
			#region Assign Property Values
			messaging_StoreTransazioneIN.IdMessageIn = idMessageIn;
			messaging_StoreTransazioneIN.ProgressivoTransazioneIn = progressivoTransazioneIn;
			messaging_StoreTransazioneIN.TipoTransazioneIn = tipoTransazioneIn;
			messaging_StoreTransazioneIN.ReferenceNumber = referenceNumber;
			messaging_StoreTransazioneIN.MarketParticipantNumber = marketParticipantNumber;
			messaging_StoreTransazioneIN.TransactionBlob = transactionBlob;
			messaging_StoreTransazioneIN.StatoTransazioneIn = statoTransazioneIn;
			#endregion
			
			messaging_StoreTransazioneIN.Execute(cn);
			
			#region Get Property Values
			
			#endregion
		}
		#endregion
	}
	#endregion
	
	
	#region Messaging_StoreTransazioneOUT Wrapper
	/// <summary>
	/// This class is a wrapper for the Messaging_StoreTransazioneOUT stored procedure.
	/// </summary>
	public class Messaging_StoreTransazioneOUT
	{
		#region Member Variables
		protected int _recordsAffected = -1;
		protected int _returnValue = 0;
		protected SqlInt32 _idMessageOut = SqlInt32.Null;
		protected bool _idMessageOutSet = false;
		protected SqlInt32 _progressivoTransazioneOut = SqlInt32.Null;
		protected bool _progressivoTransazioneOutSet = false;
		protected SqlString _tipoTransazioneOut = SqlString.Null;
		protected bool _tipoTransazioneOutSet = false;
		protected SqlString _referenceNumber = SqlString.Null;
		protected bool _referenceNumberSet = false;
		protected SqlString _marketParticipantNumber = SqlString.Null;
		protected bool _marketParticipantNumberSet = false;
		protected SqlBinary _transactionBlob = SqlBinary.Null;
		protected bool _transactionBlobSet = false;
		protected SqlString _originalReferenceNumber = SqlString.Null;
		protected bool _originalReferenceNumberSet = false;
		protected SqlInt32 _idMessageIn = SqlInt32.Null;
		protected bool _idMessageInSet = false;
		protected SqlInt32 _progressivoTransazioneIn = SqlInt32.Null;
		protected bool _progressivoTransazioneInSet = false;
		#endregion
		
		#region Constructors
		public Messaging_StoreTransazioneOUT()
		{
		}
		#endregion
		
		#region Public Properties
		/// <summary>
		/// Gets the return value from the Messaging_StoreTransazioneOUT stored procedure.
		/// </summary>
		public int ReturnValue
		{
			get {return _returnValue;}
		}
		
		/// <summary>
		/// Gets the number of rows changed, inserted, or deleted by execution of the Messaging_StoreTransazioneOUT stored procedure.
		/// </summary>
		public int RecordsAffected
		{
			get {return _recordsAffected;}
		}
		
		public SqlInt32 IdMessageOut
		{
			get {return _idMessageOut;}
			set
			{
				_idMessageOut = value;
				_idMessageOutSet = true;
			}
		}

		public SqlInt32 ProgressivoTransazioneOut
		{
			get {return _progressivoTransazioneOut;}
			set
			{
				_progressivoTransazioneOut = value;
				_progressivoTransazioneOutSet = true;
			}
		}

		public SqlString TipoTransazioneOut
		{
			get {return _tipoTransazioneOut;}
			set
			{
				_tipoTransazioneOut = value;
				_tipoTransazioneOutSet = true;
			}
		}

		public SqlString ReferenceNumber
		{
			get {return _referenceNumber;}
			set
			{
				_referenceNumber = value;
				_referenceNumberSet = true;
			}
		}

		public SqlString MarketParticipantNumber
		{
			get {return _marketParticipantNumber;}
			set
			{
				_marketParticipantNumber = value;
				_marketParticipantNumberSet = true;
			}
		}

		public SqlBinary TransactionBlob
		{
			get {return _transactionBlob;}
			set
			{
				_transactionBlob = value;
				_transactionBlobSet = true;
			}
		}

		public SqlString OriginalReferenceNumber
		{
			get {return _originalReferenceNumber;}
			set
			{
				_originalReferenceNumber = value;
				_originalReferenceNumberSet = true;
			}
		}

		public SqlInt32 IdMessageIn
		{
			get {return _idMessageIn;}
			set
			{
				_idMessageIn = value;
				_idMessageInSet = true;
			}
		}

		public SqlInt32 ProgressivoTransazioneIn
		{
			get {return _progressivoTransazioneIn;}
			set
			{
				_progressivoTransazioneIn = value;
				_progressivoTransazioneInSet = true;
			}
		}
		#endregion
		
		#region Execute Methods
		/// <summary>
		/// This method calls the Messaging_StoreTransazioneOUT stored procedure.
		/// </summary>
		public virtual void Execute(SqlConnection cn)
		{
			SqlCommand cmd = cn.CreateCommand();
			
			try
			{
				cmd.CommandText = "[dbo].[Messaging_StoreTransazioneOUT]";
				cmd.CommandType = CommandType.StoredProcedure;
				
				#region Populate Parameters
				SqlParameter prmReturnValue = cmd.Parameters.Add("@RETURN_VALUE", SqlDbType.Int);
				prmReturnValue.Direction = ParameterDirection.ReturnValue;
				
				SqlParameter prmIdMessageOut = cmd.Parameters.Add("@IdMessageOut", SqlDbType.Int);
				prmIdMessageOut.Direction = ParameterDirection.Input;
				if (_idMessageOutSet == true || this.IdMessageOut.IsNull == false)
				{
					prmIdMessageOut.Value = this.IdMessageOut;
				}
				
				SqlParameter prmProgressivoTransazioneOut = cmd.Parameters.Add("@ProgressivoTransazioneOut", SqlDbType.Int);
				prmProgressivoTransazioneOut.Direction = ParameterDirection.Input;
				if (_progressivoTransazioneOutSet == true || this.ProgressivoTransazioneOut.IsNull == false)
				{
					prmProgressivoTransazioneOut.Value = this.ProgressivoTransazioneOut;
				}
				
				SqlParameter prmTipoTransazioneOut = cmd.Parameters.Add("@TipoTransazioneOut", SqlDbType.VarChar);
				prmTipoTransazioneOut.Direction = ParameterDirection.Input;
				prmTipoTransazioneOut.Size = 6;
				if (_tipoTransazioneOutSet == true || this.TipoTransazioneOut.IsNull == false)
				{
					prmTipoTransazioneOut.Value = this.TipoTransazioneOut;
				}
				
				SqlParameter prmReferenceNumber = cmd.Parameters.Add("@ReferenceNumber", SqlDbType.VarChar);
				prmReferenceNumber.Direction = ParameterDirection.Input;
				prmReferenceNumber.Size = 30;
				if (_referenceNumberSet == true || this.ReferenceNumber.IsNull == false)
				{
					prmReferenceNumber.Value = this.ReferenceNumber;
				}
				
				SqlParameter prmMarketParticipantNumber = cmd.Parameters.Add("@MarketParticipantNumber", SqlDbType.VarChar);
				prmMarketParticipantNumber.Direction = ParameterDirection.Input;
				prmMarketParticipantNumber.Size = 30;
				if (_marketParticipantNumberSet == true || this.MarketParticipantNumber.IsNull == false)
				{
					prmMarketParticipantNumber.Value = this.MarketParticipantNumber;
				}
				
				SqlParameter prmTransactionBlob = cmd.Parameters.Add("@TransactionBlob", SqlDbType.Image);
				prmTransactionBlob.Direction = ParameterDirection.Input;
				if (_transactionBlobSet == true || this.TransactionBlob.IsNull == false)
				{
					prmTransactionBlob.Value = this.TransactionBlob;
				}
				
				SqlParameter prmOriginalReferenceNumber = cmd.Parameters.Add("@OriginalReferenceNumber", SqlDbType.VarChar);
				prmOriginalReferenceNumber.Direction = ParameterDirection.Input;
				prmOriginalReferenceNumber.Size = 30;
				if (_originalReferenceNumberSet == true || this.OriginalReferenceNumber.IsNull == false)
				{
					prmOriginalReferenceNumber.Value = this.OriginalReferenceNumber;
				}
				
				SqlParameter prmIdMessageIn = cmd.Parameters.Add("@IdMessageIn", SqlDbType.Int);
				prmIdMessageIn.Direction = ParameterDirection.Input;
				if (_idMessageInSet == true || this.IdMessageIn.IsNull == false)
				{
					prmIdMessageIn.Value = this.IdMessageIn;
				}
				
				SqlParameter prmProgressivoTransazioneIn = cmd.Parameters.Add("@ProgressivoTransazioneIn", SqlDbType.Int);
				prmProgressivoTransazioneIn.Direction = ParameterDirection.Input;
				if (_progressivoTransazioneInSet == true || this.ProgressivoTransazioneIn.IsNull == false)
				{
					prmProgressivoTransazioneIn.Value = this.ProgressivoTransazioneIn;
				}
				#endregion
				
				#region Execute Command
				_recordsAffected = cmd.ExecuteNonQuery();
				#endregion
				
				#region Get Output Parameters
				if (prmReturnValue.Value != null && prmReturnValue.Value != DBNull.Value)
				{
					_returnValue = (int)prmReturnValue.Value;
				}
				
				#endregion
			}
			finally
			{
				cmd.Dispose();
			}
		}
		
		/// <summary>
		/// This method calls the Messaging_StoreTransazioneOUT stored procedure.
		/// </summary>
		/// <param name="cn">La connessione da usare</param>
		/// <param name="idMessageOut"></param>
		/// <param name="progressivoTransazioneOut"></param>
		/// <param name="tipoTransazioneOut"></param>
		/// <param name="referenceNumber"></param>
		/// <param name="marketParticipantNumber"></param>
		/// <param name="transactionBlob"></param>
		/// <param name="originalReferenceNumber"></param>
		/// <param name="idMessageIn"></param>
		/// <param name="progressivoTransazioneIn"></param>
		public static void Execute(
			#region Parameters
			SqlConnection cn,
			SqlInt32 idMessageOut,
			SqlInt32 progressivoTransazioneOut,
			SqlString tipoTransazioneOut,
			SqlString referenceNumber,
			SqlString marketParticipantNumber,
			SqlBinary transactionBlob,
			SqlString originalReferenceNumber,
			SqlInt32 idMessageIn,
			SqlInt32 progressivoTransazioneIn
			#endregion
			)
		{
			Messaging_StoreTransazioneOUT messaging_StoreTransazioneOUT = new Messaging_StoreTransazioneOUT();
			
			#region Assign Property Values
			messaging_StoreTransazioneOUT.IdMessageOut = idMessageOut;
			messaging_StoreTransazioneOUT.ProgressivoTransazioneOut = progressivoTransazioneOut;
			messaging_StoreTransazioneOUT.TipoTransazioneOut = tipoTransazioneOut;
			messaging_StoreTransazioneOUT.ReferenceNumber = referenceNumber;
			messaging_StoreTransazioneOUT.MarketParticipantNumber = marketParticipantNumber;
			messaging_StoreTransazioneOUT.TransactionBlob = transactionBlob;
			messaging_StoreTransazioneOUT.OriginalReferenceNumber = originalReferenceNumber;
			messaging_StoreTransazioneOUT.IdMessageIn = idMessageIn;
			messaging_StoreTransazioneOUT.ProgressivoTransazioneIn = progressivoTransazioneIn;
			#endregion
			
			messaging_StoreTransazioneOUT.Execute(cn);
			
			#region Get Property Values
			
			#endregion
		}
		#endregion
	}
	#endregion

	#region Messaging_StoreMessageOUT Wrapper
	/// <summary>
	/// This class is a wrapper for the Messaging_StoreMessageOUT stored procedure.
	/// </summary>
	public class Messaging_StoreMessageOUT
	{
		#region Member Variables
		protected int _recordsAffected = -1;
		protected int _returnValue = 0;
		protected SqlString _codiceOperatore = SqlString.Null;
		protected bool _codiceOperatoreSet = false;
		protected SqlString _nomeFile = SqlString.Null;
		protected bool _nomeFileSet = false;
		protected SqlString _compressed = SqlString.Null;
		protected bool _compressedSet = false;
		protected SqlBoolean _firmatoInUscita = SqlBoolean.Null;
		protected bool _firmatoInUscitaSet = false;
		protected SqlString _encoding = SqlString.Null;
		protected bool _encodingSet = false;
		protected SqlString _referenceNumber = SqlString.Null;
		protected bool _referenceNumberSet = false;
		protected SqlDateTime _creationDate = SqlDateTime.Null;
		protected bool _creationDateSet = false;
		protected SqlString _version = SqlString.Null;
		protected bool _versionSet = false;
		protected SqlBinary _messageBlob = SqlBinary.Null;
		protected bool _messageBlobSet = false;
		protected SqlInt32 _idMessageIn = SqlInt32.Null;
		protected bool _idMessageInSet = false;
		protected SqlInt32 _idMessageOut = SqlInt32.Null;
		protected bool _idMessageOutSet = false;
		#endregion
		
		#region Constructors
		public Messaging_StoreMessageOUT()
		{
		}
		#endregion
		
		#region Public Properties
		/// <summary>
		/// Gets the return value from the Messaging_StoreMessageOUT stored procedure.
		/// </summary>
		public int ReturnValue
		{
			get {return _returnValue;}
		}
		
		/// <summary>
		/// Gets the number of rows changed, inserted, or deleted by execution of the Messaging_StoreMessageOUT stored procedure.
		/// </summary>
		public int RecordsAffected
		{
			get {return _recordsAffected;}
		}
		
		public SqlString CodiceOperatore
		{
			get {return _codiceOperatore;}
			set
			{
				_codiceOperatore = value;
				_codiceOperatoreSet = true;
			}
		}

		public SqlString NomeFile
		{
			get {return _nomeFile;}
			set
			{
				_nomeFile = value;
				_nomeFileSet = true;
			}
		}

		public SqlString Compressed
		{
			get {return _compressed;}
			set
			{
				_compressed = value;
				_compressedSet = true;
			}
		}

		public SqlBoolean FirmatoInUscita
		{
			get {return _firmatoInUscita;}
			set
			{
				_firmatoInUscita = value;
				_firmatoInUscitaSet = true;
			}
		}

		public SqlString Encoding
		{
			get {return _encoding;}
			set
			{
				_encoding = value;
				_encodingSet = true;
			}
		}

		public SqlString ReferenceNumber
		{
			get {return _referenceNumber;}
			set
			{
				_referenceNumber = value;
				_referenceNumberSet = true;
			}
		}

		public SqlDateTime CreationDate
		{
			get {return _creationDate;}
			set
			{
				_creationDate = value;
				_creationDateSet = true;
			}
		}

		public SqlString Version
		{
			get {return _version;}
			set
			{
				_version = value;
				_versionSet = true;
			}
		}

		public SqlBinary MessageBlob
		{
			get {return _messageBlob;}
			set
			{
				_messageBlob = value;
				_messageBlobSet = true;
			}
		}

		public SqlInt32 IdMessageIn
		{
			get {return _idMessageIn;}
			set
			{
				_idMessageIn = value;
				_idMessageInSet = true;
			}
		}

		public SqlInt32 IdMessageOut
		{
			get {return _idMessageOut;}
			set
			{
				_idMessageOut = value;
				_idMessageOutSet = true;
			}
		}
		#endregion
		
		#region Execute Methods
		/// <summary>
		/// This method calls the Messaging_StoreMessageOUT stored procedure.
		/// </summary>
		public virtual void Execute(SqlConnection cn)
		{
			SqlCommand cmd = cn.CreateCommand();
			
			try
			{
				cmd.CommandText = "[dbo].[Messaging_StoreMessageOUT]";
				cmd.CommandType = CommandType.StoredProcedure;
				
				#region Populate Parameters
				SqlParameter prmReturnValue = cmd.Parameters.Add("@RETURN_VALUE", SqlDbType.Int);
				prmReturnValue.Direction = ParameterDirection.ReturnValue;
				
				SqlParameter prmCodiceOperatore = cmd.Parameters.Add("@CodiceOperatore", SqlDbType.VarChar);
				prmCodiceOperatore.Direction = ParameterDirection.Input;
				prmCodiceOperatore.Size = 16;
				if (_codiceOperatoreSet == true || this.CodiceOperatore.IsNull == false)
				{
					prmCodiceOperatore.Value = this.CodiceOperatore;
				}
				
				SqlParameter prmNomeFile = cmd.Parameters.Add("@NomeFile", SqlDbType.VarChar);
				prmNomeFile.Direction = ParameterDirection.Input;
				prmNomeFile.Size = 512;
				if (_nomeFileSet == true || this.NomeFile.IsNull == false)
				{
					prmNomeFile.Value = this.NomeFile;
				}
				
				SqlParameter prmCompressed = cmd.Parameters.Add("@Compressed", SqlDbType.VarChar);
				prmCompressed.Direction = ParameterDirection.Input;
				prmCompressed.Size = 8;
				if (_compressedSet == true || this.Compressed.IsNull == false)
				{
					prmCompressed.Value = this.Compressed;
				}
				
				SqlParameter prmFirmatoInUscita = cmd.Parameters.Add("@FirmatoInUscita", SqlDbType.Bit);
				prmFirmatoInUscita.Direction = ParameterDirection.Input;
				if (_firmatoInUscitaSet == true || this.FirmatoInUscita.IsNull == false)
				{
					prmFirmatoInUscita.Value = this.FirmatoInUscita;
				}
				
				SqlParameter prmEncoding = cmd.Parameters.Add("@Encoding", SqlDbType.VarChar);
				prmEncoding.Direction = ParameterDirection.Input;
				prmEncoding.Size = 16;
				if (_encodingSet == true || this.Encoding.IsNull == false)
				{
					prmEncoding.Value = this.Encoding;
				}
				
				SqlParameter prmReferenceNumber = cmd.Parameters.Add("@ReferenceNumber", SqlDbType.VarChar);
				prmReferenceNumber.Direction = ParameterDirection.Input;
				prmReferenceNumber.Size = 30;
				if (_referenceNumberSet == true || this.ReferenceNumber.IsNull == false)
				{
					prmReferenceNumber.Value = this.ReferenceNumber;
				}
				
				SqlParameter prmCreationDate = cmd.Parameters.Add("@CreationDate", SqlDbType.DateTime);
				prmCreationDate.Direction = ParameterDirection.Input;
				if (_creationDateSet == true || this.CreationDate.IsNull == false)
				{
					prmCreationDate.Value = this.CreationDate;
				}
				
				SqlParameter prmVersion = cmd.Parameters.Add("@Version", SqlDbType.VarChar);
				prmVersion.Direction = ParameterDirection.Input;
				prmVersion.Size = 5;
				if (_versionSet == true || this.Version.IsNull == false)
				{
					prmVersion.Value = this.Version;
				}
				
				SqlParameter prmMessageBlob = cmd.Parameters.Add("@MessageBlob", SqlDbType.Image);
				prmMessageBlob.Direction = ParameterDirection.Input;
				if (_messageBlobSet == true || this.MessageBlob.IsNull == false)
				{
					prmMessageBlob.Value = this.MessageBlob;
				}
				
				SqlParameter prmIdMessageIn = cmd.Parameters.Add("@IdMessageIn", SqlDbType.Int);
				prmIdMessageIn.Direction = ParameterDirection.Input;
				if (_idMessageInSet == true || this.IdMessageIn.IsNull == false)
				{
					prmIdMessageIn.Value = this.IdMessageIn;
				}
				
				SqlParameter prmIdMessageOut = cmd.Parameters.Add("@IdMessageOut", SqlDbType.Int);
				if (_idMessageOutSet == true)
				{
					prmIdMessageOut.Direction = ParameterDirection.InputOutput;
				}
				else
				{
					prmIdMessageOut.Direction = ParameterDirection.Output;
				}
				if (_idMessageOutSet == true || this.IdMessageOut.IsNull == false)
				{
					prmIdMessageOut.Value = this.IdMessageOut;
				}
				#endregion
				
				#region Execute Command
				_recordsAffected = cmd.ExecuteNonQuery();
				#endregion
				
				#region Get Output Parameters
				if (prmReturnValue.Value != null && prmReturnValue.Value != DBNull.Value)
				{
					_returnValue = (int)prmReturnValue.Value;
				}
				
				if (prmIdMessageOut != null && prmIdMessageOut.Value != null)
				{
					if (prmIdMessageOut.Value is SqlInt32)
					{
						this.IdMessageOut = (SqlInt32)prmIdMessageOut.Value;
					}
					else
					{
						if (prmIdMessageOut.Value != DBNull.Value)
						{
							this.IdMessageOut = new SqlInt32((int)prmIdMessageOut.Value);
						}
						else
						{
							this.IdMessageOut = SqlInt32.Null;
						}
					}
				}
				else
				{
					this.IdMessageOut = SqlInt32.Null;
				}
				#endregion
			}
			finally
			{
				cmd.Dispose();
			}
		}
		
		/// <summary>
		/// This method calls the Messaging_StoreMessageOUT stored procedure.
		/// </summary>
		/// <param name="cn">La connessione da usare</param>
		/// <param name="codiceOperatore"></param>
		/// <param name="nomeFile"></param>
		/// <param name="compressed"></param>
		/// <param name="firmatoInUscita"></param>
		/// <param name="encoding"></param>
		/// <param name="referenceNumber"></param>
		/// <param name="creationDate"></param>
		/// <param name="version"></param>
		/// <param name="messageBlob"></param>
		/// <param name="idMessageIn"></param>
		/// <param name="idMessageOut"></param>
		public static void Execute(
			#region Parameters
			SqlConnection cn,
			SqlString codiceOperatore,
			SqlString nomeFile,
			SqlString compressed,
			SqlBoolean firmatoInUscita,
			SqlString encoding,
			SqlString referenceNumber,
			SqlDateTime creationDate,
			SqlString version,
			SqlBinary messageBlob,
			SqlInt32 idMessageIn,
			ref SqlInt32 idMessageOut
			#endregion
			)
		{
			Messaging_StoreMessageOUT messaging_StoreMessageOUT = new Messaging_StoreMessageOUT();
			
			#region Assign Property Values
			messaging_StoreMessageOUT.CodiceOperatore = codiceOperatore;
			messaging_StoreMessageOUT.NomeFile = nomeFile;
			messaging_StoreMessageOUT.Compressed = compressed;
			messaging_StoreMessageOUT.FirmatoInUscita = firmatoInUscita;
			messaging_StoreMessageOUT.Encoding = encoding;
			messaging_StoreMessageOUT.ReferenceNumber = referenceNumber;
			messaging_StoreMessageOUT.CreationDate = creationDate;
			messaging_StoreMessageOUT.Version = version;
			messaging_StoreMessageOUT.MessageBlob = messageBlob;
			messaging_StoreMessageOUT.IdMessageIn = idMessageIn;
			messaging_StoreMessageOUT.IdMessageOut = idMessageOut;
			#endregion
			
			messaging_StoreMessageOUT.Execute(cn);
			
			#region Get Property Values
			idMessageOut = messaging_StoreMessageOUT.IdMessageOut;
			#endregion
		}
		#endregion
	}
	#endregion
	
}