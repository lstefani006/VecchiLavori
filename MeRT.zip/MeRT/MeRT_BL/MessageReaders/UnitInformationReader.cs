using System;
using System.Data;
using System.Data.SqlTypes;
using System.Data.SqlClient;
using System.Xml;
using System.Xml.Serialization;

using MeRT_BL.Messaging.UnitInformationTypes;
using Messaging;
using PIPEDoc;

namespace MeRT_BL.Messaging
{
	public class UnitInformationFacade : TransactionFacade
	{
		public UnitInformationFacade(PIPTransaction tr)
			: base(tr, PIPTransactionAttributes.All){}

		public override string FA_MarketParticipantNumber
		{
			get { return PIPTransaction.ReferenceNumber; }
		}
		
		public override string FA_TransactionType
		{
			get { return "FA"; }
		}

		public override void Read(XmlReader xr)
		{
			_element = (UnitInformation) _serializer.Deserialize(xr);
		}

		public override void Write(XmlWriter xw)
		{
			if (_element == null)
				return;

			WriteStartPIP(xw);
			_serializer.Serialize(xw, _element);
			WriteEndPIP(xw);
		}
		private static string MustRunTypeToString(mustRunType type)
		{
			// TODO
			string s = type.ToString();
			if (s.Length > 4)
				return s.Substring(0, 4);
			return s;
		}
		private static string UnitSubTypeToString(unitSubType type)
		{
			// TODO
			return type.ToString("d");
		}
		private static bool UnitStatusCodeTypeToBoolean(unitStatusCodeType type)
		{
			// TODO
			if (unitStatusCodeType.Enabled == type)
				return true;

			return false;
		}
		private static SqlString OptionalStringToSqlString(string value)
		{
			if (value == null || value == string.Empty)
				return SqlString.Null;

			return value;
		}
		private static string UnitTypeToString(unitType type)
		{
			// TODO
			switch (type)
			{
				case unitType.Production:
					return "PROD";
				case unitType.Consumption:
					return "CONS";
				default:
					return "BOTH";
			}
		}
		public override void Execute(object executeState)
		{
			if (this.Valid == false)
				return;
			SqlConnection cn = executeState as SqlConnection;
			if (cn == null)// TODO
				return;

			try
			{
				// TODO <element name = "UnitDetail" minOccurs="1" maxOccurs="unbounded">
				UnitDetail ud = _element.UnitDetail[0];

				/*
UnitName							<UnitName>UNIT� DI PRODUZIONE DELL' IMPIANTO IGCC DI APIENERGIA DI FAL</UnitName>
UnitReferenceNumber.Value			<UnitReferenceNumber>UP_PNRGIAIGCC_1</UnitReferenceNumber>
UnitReferenceNumber.MustRun			<UnitReferenceNumber MustRun="CIP6"></UnitReferenceNumber>
UnitType.Value						<UnitType>Production</UnitType>
UnitType.SubType					<UnitType SubType="TERMICO COMBINATO"></UnitType>
TransmissionLossFactor				<TransmissionLossFactor> 1,000</TransmissionLossFactor>
GridSupplyPoint						<GridSupplyPoint>PSR_250</GridSupplyPoint>
MinimumPower						<MaximumPower>297,5</MaximumPower>
MaximumPower						<MinimumPower>4,5</MinimumPower>
InjectionOrWithdrawalPointNumber	<InjectionOrWithdrawalPointNumber>UP_PNRGIAIGCC_1</InjectionOrWithdrawalPointNumber>
MeritOrder							<MeritOrder>3000</MeritOrder>
ud.StatusCode						<StatusCode>Enabled</StatusCode>
ReferenceMarketParticipantNumber	<ReferenceMarketParticipantNumber>IDGRTN</ReferenceMarketParticipantNumber>
						<MarketInformation>
							<Market Eligibility="Able">MGP</Market>
							<Market Eligibility="Able">MA1</Market>
							<Market Eligibility="NotAble">MSD</Market>
						</MarketInformation>
					</UnitDetail>
				 * */

				// TODO string.Empty || null || ud.UnitReferenceNumber.MustRunSpecified
				SqlString mustRunCD = SqlString.Null;
				if (ud.UnitReferenceNumber.MustRunSpecified)
					mustRunCD = MustRunTypeToString(ud.UnitReferenceNumber.MustRun);
				
				//unita_Store.Execute(cn);
				Unita_Store.Execute(cn
					, ud.UnitReferenceNumber.Value
					, UnitTypeToString(ud.UnitType.Value)
					, UnitSubTypeToString(ud.UnitType.SubType)
					, ud.UnitName
					, SimpleType.LocaleDecimalToDouble(ud.TransmissionLossFactor)
					, ud.GridSupplyPoint
					, SimpleType.LocaleDecimalToDouble(ud.MinimumPower)
					, SimpleType.LocaleDecimalToDouble(ud.MaximumPower)
					// TODO ud.MeritOrder | ud.BilateralMeritOrder
					, int.Parse(ud.MeritOrder, System.Globalization.CultureInfo.InvariantCulture)
					// TODO			SqlBoolean abilitata, <StatusCode>Enabled</StatusCode>
					, UnitStatusCodeTypeToBoolean(ud.StatusCode)
					, OptionalStringToSqlString(ud.UnbalancedMarketParticipantNumber)
					, OptionalStringToSqlString(ud.InjectionOrWithdrawalPointNumber)
					, mustRunCD
					, ud.ReferenceMarketParticipantNumber
					);
			}
			catch (Exception e)
			{
				this.SetError(MessagingError.E0.ToString(), e.Message);
			}
		}

		private static XmlSerializer _serializer =
			new XmlSerializer(typeof(UnitInformation));
		private UnitInformation _element = null;
	}

	#region Unita_Store Wrapper
	/// <summary>
	/// This class is a wrapper for the Unita_Store stored procedure.
	/// </summary>
	internal class Unita_Store
	{
		#region Member Variables
		protected int _recordsAffected = -1;
		protected int _returnValue = 0;
		protected SqlString _codiceUnita = SqlString.Null;
		protected bool _codiceUnitaSet = false;
		protected SqlString _tipoUnita = SqlString.Null;
		protected bool _tipoUnitaSet = false;
		protected SqlString _sottotipoUnita = SqlString.Null;
		protected bool _sottotipoUnitaSet = false;
		protected SqlString _descrizioneUnita = SqlString.Null;
		protected bool _descrizioneUnitaSet = false;
		protected SqlDouble _coefficientePerdita = SqlDouble.Null;
		protected bool _coefficientePerditaSet = false;
		protected SqlString _codicePDSR = SqlString.Null;
		protected bool _codicePDSRSet = false;
		protected SqlDouble _potenzaMinimaMWh = SqlDouble.Null;
		protected bool _potenzaMinimaMWhSet = false;
		protected SqlDouble _potenzaMassimaMWh = SqlDouble.Null;
		protected bool _potenzaMassimaMWhSet = false;
		protected SqlInt32 _ordineMeritoUnita = SqlInt32.Null;
		protected bool _ordineMeritoUnitaSet = false;
		protected SqlBoolean _abilitata = SqlBoolean.Null;
		protected bool _abilitataSet = false;
		protected SqlString _unbalancedParticipantNumber = SqlString.Null;
		protected bool _unbalancedParticipantNumberSet = false;
		protected SqlString _injectionOrWithdrawalPointNumber = SqlString.Null;
		protected bool _injectionOrWithdrawalPointNumberSet = false;
		protected SqlString _mustRunCD = SqlString.Null;
		protected bool _mustRunCDSet = false;
		protected SqlString _codiceOperatoreRif = SqlString.Null;
		protected bool _codiceOperatoreRifSet = false;
		#endregion
		
		#region Constructors
		public Unita_Store()
		{
		}
		#endregion
		
		#region Public Properties
		/// <summary>
		/// Gets the return value from the Unita_Store stored procedure.
		/// </summary>
		public int ReturnValue
		{
			get {return _returnValue;}
		}
		
		/// <summary>
		/// Gets the number of rows changed, inserted, or deleted by execution of the Unita_Store stored procedure.
		/// </summary>
		public int RecordsAffected
		{
			get {return _recordsAffected;}
		}
		
		public SqlString CodiceUnita
		{
			get {return _codiceUnita;}
			set
			{
				_codiceUnita = value;
				_codiceUnitaSet = true;
			}
		}

		public SqlString TipoUnita
		{
			get {return _tipoUnita;}
			set
			{
				_tipoUnita = value;
				_tipoUnitaSet = true;
			}
		}

		public SqlString SottotipoUnita
		{
			get {return _sottotipoUnita;}
			set
			{
				_sottotipoUnita = value;
				_sottotipoUnitaSet = true;
			}
		}

		public SqlString DescrizioneUnita
		{
			get {return _descrizioneUnita;}
			set
			{
				_descrizioneUnita = value;
				_descrizioneUnitaSet = true;
			}
		}

		public SqlDouble CoefficientePerdita
		{
			get {return _coefficientePerdita;}
			set
			{
				_coefficientePerdita = value;
				_coefficientePerditaSet = true;
			}
		}

		public SqlString CodicePDSR
		{
			get {return _codicePDSR;}
			set
			{
				_codicePDSR = value;
				_codicePDSRSet = true;
			}
		}

		public SqlDouble PotenzaMinimaMWh
		{
			get {return _potenzaMinimaMWh;}
			set
			{
				_potenzaMinimaMWh = value;
				_potenzaMinimaMWhSet = true;
			}
		}

		public SqlDouble PotenzaMassimaMWh
		{
			get {return _potenzaMassimaMWh;}
			set
			{
				_potenzaMassimaMWh = value;
				_potenzaMassimaMWhSet = true;
			}
		}

		public SqlInt32 OrdineMeritoUnita
		{
			get {return _ordineMeritoUnita;}
			set
			{
				_ordineMeritoUnita = value;
				_ordineMeritoUnitaSet = true;
			}
		}

		public SqlBoolean Abilitata
		{
			get {return _abilitata;}
			set
			{
				_abilitata = value;
				_abilitataSet = true;
			}
		}

		public SqlString UnbalancedParticipantNumber
		{
			get {return _unbalancedParticipantNumber;}
			set
			{
				_unbalancedParticipantNumber = value;
				_unbalancedParticipantNumberSet = true;
			}
		}

		public SqlString InjectionOrWithdrawalPointNumber
		{
			get {return _injectionOrWithdrawalPointNumber;}
			set
			{
				_injectionOrWithdrawalPointNumber = value;
				_injectionOrWithdrawalPointNumberSet = true;
			}
		}

		public SqlString MustRunCD
		{
			get {return _mustRunCD;}
			set
			{
				_mustRunCD = value;
				_mustRunCDSet = true;
			}
		}

		public SqlString CodiceOperatoreRif
		{
			get {return _codiceOperatoreRif;}
			set
			{
				_codiceOperatoreRif = value;
				_codiceOperatoreRifSet = true;
			}
		}
		#endregion
		
		#region Execute Methods
		/// <summary>
		/// This method calls the Unita_Store stored procedure.
		/// </summary>
		public virtual void Execute(SqlConnection cn)
		{
			SqlCommand cmd = cn.CreateCommand();
			
			try
			{
				cmd.CommandText = "[dbo].[Unita_Store]";
				cmd.CommandType = CommandType.StoredProcedure;
				
				#region Populate Parameters
				SqlParameter prmReturnValue = cmd.Parameters.Add("@RETURN_VALUE", SqlDbType.Int);
				prmReturnValue.Direction = ParameterDirection.ReturnValue;
				
				SqlParameter prmCodiceUnita = cmd.Parameters.Add("@CodiceUnita", SqlDbType.VarChar);
				prmCodiceUnita.Direction = ParameterDirection.Input;
				prmCodiceUnita.Size = 16;
				if (_codiceUnitaSet == true || this.CodiceUnita.IsNull == false)
				{
					prmCodiceUnita.Value = this.CodiceUnita;
				}
				
				SqlParameter prmTipoUnita = cmd.Parameters.Add("@TipoUnita", SqlDbType.VarChar);
				prmTipoUnita.Direction = ParameterDirection.Input;
				prmTipoUnita.Size = 4;
				if (_tipoUnitaSet == true || this.TipoUnita.IsNull == false)
				{
					prmTipoUnita.Value = this.TipoUnita;
				}
				
				SqlParameter prmSottotipoUnita = cmd.Parameters.Add("@SottotipoUnita", SqlDbType.VarChar);
				prmSottotipoUnita.Direction = ParameterDirection.Input;
				prmSottotipoUnita.Size = 4;
				if (_sottotipoUnitaSet == true || this.SottotipoUnita.IsNull == false)
				{
					prmSottotipoUnita.Value = this.SottotipoUnita;
				}
				
				SqlParameter prmDescrizioneUnita = cmd.Parameters.Add("@DescrizioneUnita", SqlDbType.NVarChar);
				prmDescrizioneUnita.Direction = ParameterDirection.Input;
				prmDescrizioneUnita.Size = 60;
				if (_descrizioneUnitaSet == true || this.DescrizioneUnita.IsNull == false)
				{
					prmDescrizioneUnita.Value = this.DescrizioneUnita;
				}
				
				SqlParameter prmCoefficientePerdita = cmd.Parameters.Add("@CoefficientePerdita", SqlDbType.Float);
				prmCoefficientePerdita.Direction = ParameterDirection.Input;
				prmCoefficientePerdita.Precision = 15;
				prmCoefficientePerdita.Scale = 0;
				if (_coefficientePerditaSet == true || this.CoefficientePerdita.IsNull == false)
				{
					prmCoefficientePerdita.Value = this.CoefficientePerdita;
				}
				
				SqlParameter prmCodicePDSR = cmd.Parameters.Add("@CodicePDSR", SqlDbType.VarChar);
				prmCodicePDSR.Direction = ParameterDirection.Input;
				prmCodicePDSR.Size = 16;
				if (_codicePDSRSet == true || this.CodicePDSR.IsNull == false)
				{
					prmCodicePDSR.Value = this.CodicePDSR;
				}
				
				SqlParameter prmPotenzaMinimaMWh = cmd.Parameters.Add("@PotenzaMinimaMWh", SqlDbType.Float);
				prmPotenzaMinimaMWh.Direction = ParameterDirection.Input;
				prmPotenzaMinimaMWh.Precision = 15;
				prmPotenzaMinimaMWh.Scale = 0;
				if (_potenzaMinimaMWhSet == true || this.PotenzaMinimaMWh.IsNull == false)
				{
					prmPotenzaMinimaMWh.Value = this.PotenzaMinimaMWh;
				}
				
				SqlParameter prmPotenzaMassimaMWh = cmd.Parameters.Add("@PotenzaMassimaMWh", SqlDbType.Float);
				prmPotenzaMassimaMWh.Direction = ParameterDirection.Input;
				prmPotenzaMassimaMWh.Precision = 15;
				prmPotenzaMassimaMWh.Scale = 0;
				if (_potenzaMassimaMWhSet == true || this.PotenzaMassimaMWh.IsNull == false)
				{
					prmPotenzaMassimaMWh.Value = this.PotenzaMassimaMWh;
				}
				
				SqlParameter prmOrdineMeritoUnita = cmd.Parameters.Add("@OrdineMeritoUnita", SqlDbType.Int);
				prmOrdineMeritoUnita.Direction = ParameterDirection.Input;
				if (_ordineMeritoUnitaSet == true || this.OrdineMeritoUnita.IsNull == false)
				{
					prmOrdineMeritoUnita.Value = this.OrdineMeritoUnita;
				}
				
				SqlParameter prmAbilitata = cmd.Parameters.Add("@Abilitata", SqlDbType.Bit);
				prmAbilitata.Direction = ParameterDirection.Input;
				if (_abilitataSet == true || this.Abilitata.IsNull == false)
				{
					prmAbilitata.Value = this.Abilitata;
				}
				
				SqlParameter prmUnbalancedParticipantNumber = cmd.Parameters.Add("@UnbalancedParticipantNumber", SqlDbType.VarChar);
				prmUnbalancedParticipantNumber.Direction = ParameterDirection.Input;
				prmUnbalancedParticipantNumber.Size = 16;
				if (_unbalancedParticipantNumberSet == true || this.UnbalancedParticipantNumber.IsNull == false)
				{
					prmUnbalancedParticipantNumber.Value = this.UnbalancedParticipantNumber;
				}
				
				SqlParameter prmInjectionOrWithdrawalPointNumber = cmd.Parameters.Add("@InjectionOrWithdrawalPointNumber", SqlDbType.VarChar);
				prmInjectionOrWithdrawalPointNumber.Direction = ParameterDirection.Input;
				prmInjectionOrWithdrawalPointNumber.Size = 16;
				if (_injectionOrWithdrawalPointNumberSet == true || this.InjectionOrWithdrawalPointNumber.IsNull == false)
				{
					prmInjectionOrWithdrawalPointNumber.Value = this.InjectionOrWithdrawalPointNumber;
				}
				
				SqlParameter prmMustRunCD = cmd.Parameters.Add("@MustRunCD", SqlDbType.VarChar);
				prmMustRunCD.Direction = ParameterDirection.Input;
				prmMustRunCD.Size = 4;
				if (_mustRunCDSet == true || this.MustRunCD.IsNull == false)
				{
					prmMustRunCD.Value = this.MustRunCD;
				}
				
				SqlParameter prmCodiceOperatoreRif = cmd.Parameters.Add("@CodiceOperatoreRif", SqlDbType.VarChar);
				prmCodiceOperatoreRif.Direction = ParameterDirection.Input;
				prmCodiceOperatoreRif.Size = 16;
				if (_codiceOperatoreRifSet == true || this.CodiceOperatoreRif.IsNull == false)
				{
					prmCodiceOperatoreRif.Value = this.CodiceOperatoreRif;
				}
				#endregion
				
				#region Execute Command
				_recordsAffected = cmd.ExecuteNonQuery();
				#endregion
				
				#region Get Output Parameters
				if (prmReturnValue.Value != null && prmReturnValue.Value != DBNull.Value)
				{
					_returnValue = (int)prmReturnValue.Value;
				}
				
				#endregion
			}
			finally
			{
				cmd.Dispose();
			}
		}
		
		/// <summary>
		/// This method calls the Unita_Store stored procedure.
		/// </summary>
		/// <param name="cn">La connessione da usare</param>
		/// <param name="codiceUnita"></param>
		/// <param name="tipoUnita"></param>
		/// <param name="sottotipoUnita"></param>
		/// <param name="descrizioneUnita"></param>
		/// <param name="coefficientePerdita"></param>
		/// <param name="codicePDSR"></param>
		/// <param name="potenzaMinimaMWh"></param>
		/// <param name="potenzaMassimaMWh"></param>
		/// <param name="ordineMeritoUnita"></param>
		/// <param name="abilitata"></param>
		/// <param name="unbalancedParticipantNumber"></param>
		/// <param name="injectionOrWithdrawalPointNumber"></param>
		/// <param name="mustRunCD"></param>
		/// <param name="codiceOperatoreRif"></param>
		public static void Execute(
			#region Parameters
			SqlConnection cn,
			SqlString codiceUnita,
			SqlString tipoUnita,
			SqlString sottotipoUnita,
			SqlString descrizioneUnita,
			SqlDouble coefficientePerdita,
			SqlString codicePDSR,
			SqlDouble potenzaMinimaMWh,
			SqlDouble potenzaMassimaMWh,
			SqlInt32 ordineMeritoUnita,
			SqlBoolean abilitata,
			SqlString unbalancedParticipantNumber,
			SqlString injectionOrWithdrawalPointNumber,
			SqlString mustRunCD,
			SqlString codiceOperatoreRif
			#endregion
			)
		{
			Unita_Store unita_Store = new Unita_Store();
			
			#region Assign Property Values
			unita_Store.CodiceUnita = codiceUnita;
			unita_Store.TipoUnita = tipoUnita;
			unita_Store.SottotipoUnita = sottotipoUnita;
			unita_Store.DescrizioneUnita = descrizioneUnita;
			unita_Store.CoefficientePerdita = coefficientePerdita;
			unita_Store.CodicePDSR = codicePDSR;
			unita_Store.PotenzaMinimaMWh = potenzaMinimaMWh;
			unita_Store.PotenzaMassimaMWh = potenzaMassimaMWh;
			unita_Store.OrdineMeritoUnita = ordineMeritoUnita;
			unita_Store.Abilitata = abilitata;
			unita_Store.UnbalancedParticipantNumber = unbalancedParticipantNumber;
			unita_Store.InjectionOrWithdrawalPointNumber = injectionOrWithdrawalPointNumber;
			unita_Store.MustRunCD = mustRunCD;
			unita_Store.CodiceOperatoreRif = codiceOperatoreRif;
			#endregion
			
			unita_Store.Execute(cn);
			
			#region Get Property Values
			
			#endregion
		}
		#endregion
	}
	#endregion

}
