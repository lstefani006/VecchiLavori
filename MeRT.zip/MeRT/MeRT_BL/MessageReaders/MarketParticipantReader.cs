using System;
using System.Data;
using System.Data.SqlTypes;
using System.Data.SqlClient;
using System.Xml;
using System.Xml.Serialization;

using MeRT_BL.Messaging.MarketParticipantTypes;
using Messaging;
using PIPEDoc;

namespace MeRT_BL.Messaging
{
	public class MarketParticipantFacade : TransactionFacade
	{
		public MarketParticipantFacade(PIPTransaction tr)
			: base(tr, PIPTransactionAttributes.ReferenceNumber){}

		public override string FA_MarketParticipantNumber
		{
			get
			{
				if (_element == null)
					return PIPTransaction.ReferenceNumber;
				return _element.CodOp;
			}
		}

		public override string FA_TransactionType
		{
			get { return "FA"; }
		}

		public override void Read(XmlReader xr)
		{
			_element = (MarketParticipant) _serializer.Deserialize(xr);
		}

		public override void Write(XmlWriter xw)
		{
			if (_element == null)
				return;

			WriteStartPIP(xw);
			_serializer.Serialize(xw, _element);
			WriteEndPIP(xw);
		}
		public override void Execute(object executeState)
		{
			if (this.Valid == false)
				return;
			SqlConnection cn = executeState as SqlConnection;
			if (cn == null)// TODO
				return;

			try
			{
				Operatori_Store.Execute(cn
					, _element.CodOp
					, _element.RagioneSociale
					, _element.Addr1
					, _element.Addr2
					, _element.Citta
					, _element.Stato
					, _element.CodFiscale
					, _element.PIVA
					, _element.Fax
					, _element.Email
					, _element.ReferenteAmministrativo
					, _element.SedeAmministrativa
					, true
					);
			}
			catch (Exception e)
			{
				this.SetError(MessagingError.E0.ToString(), e.Message);
			}
		}


		private static XmlSerializer _serializer =
			new XmlSerializer(typeof(MarketParticipant));
		private MarketParticipant _element = null;
	}
	#region Operatori_Store Wrapper
	/// <summary>
	/// This class is a wrapper for the Operatori_Store stored procedure.
	/// </summary>
	internal class Operatori_Store
	{
		#region Member Variables
		protected int _recordsAffected = -1;
		protected int _returnValue = 0;
		protected SqlString _codiceOperatore = SqlString.Null;
		protected bool _codiceOperatoreSet = false;
		protected SqlString _ragioneSociale = SqlString.Null;
		protected bool _ragioneSocialeSet = false;
		protected SqlString _indirizzo1 = SqlString.Null;
		protected bool _indirizzo1Set = false;
		protected SqlString _indirizzo2 = SqlString.Null;
		protected bool _indirizzo2Set = false;
		protected SqlString _citta = SqlString.Null;
		protected bool _cittaSet = false;
		protected SqlString _nazione = SqlString.Null;
		protected bool _nazioneSet = false;
		protected SqlString _codiceFiscale = SqlString.Null;
		protected bool _codiceFiscaleSet = false;
		protected SqlString _partitaIVA = SqlString.Null;
		protected bool _partitaIVASet = false;
		protected SqlString _fax = SqlString.Null;
		protected bool _faxSet = false;
		protected SqlString _email = SqlString.Null;
		protected bool _emailSet = false;
		protected SqlString _referenteAmministrativo = SqlString.Null;
		protected bool _referenteAmministrativoSet = false;
		protected SqlString _sedeAmministrativa = SqlString.Null;
		protected bool _sedeAmministrativaSet = false;
		protected SqlBoolean _abilitato = SqlBoolean.Null;
		protected bool _abilitatoSet = false;
		#endregion
		
		#region Constructors
		public Operatori_Store()
		{
		}
		#endregion
		
		#region Public Properties
		/// <summary>
		/// Gets the return value from the Operatori_Store stored procedure.
		/// </summary>
		public int ReturnValue
		{
			get {return _returnValue;}
		}
		
		/// <summary>
		/// Gets the number of rows changed, inserted, or deleted by execution of the Operatori_Store stored procedure.
		/// </summary>
		public int RecordsAffected
		{
			get {return _recordsAffected;}
		}
		
		public SqlString CodiceOperatore
		{
			get {return _codiceOperatore;}
			set
			{
				_codiceOperatore = value;
				_codiceOperatoreSet = true;
			}
		}

		public SqlString RagioneSociale
		{
			get {return _ragioneSociale;}
			set
			{
				_ragioneSociale = value;
				_ragioneSocialeSet = true;
			}
		}

		public SqlString Indirizzo1
		{
			get {return _indirizzo1;}
			set
			{
				_indirizzo1 = value;
				_indirizzo1Set = true;
			}
		}

		public SqlString Indirizzo2
		{
			get {return _indirizzo2;}
			set
			{
				_indirizzo2 = value;
				_indirizzo2Set = true;
			}
		}

		public SqlString Citta
		{
			get {return _citta;}
			set
			{
				_citta = value;
				_cittaSet = true;
			}
		}

		public SqlString Nazione
		{
			get {return _nazione;}
			set
			{
				_nazione = value;
				_nazioneSet = true;
			}
		}

		public SqlString CodiceFiscale
		{
			get {return _codiceFiscale;}
			set
			{
				_codiceFiscale = value;
				_codiceFiscaleSet = true;
			}
		}

		public SqlString PartitaIVA
		{
			get {return _partitaIVA;}
			set
			{
				_partitaIVA = value;
				_partitaIVASet = true;
			}
		}

		public SqlString Fax
		{
			get {return _fax;}
			set
			{
				_fax = value;
				_faxSet = true;
			}
		}

		public SqlString Email
		{
			get {return _email;}
			set
			{
				_email = value;
				_emailSet = true;
			}
		}

		public SqlString ReferenteAmministrativo
		{
			get {return _referenteAmministrativo;}
			set
			{
				_referenteAmministrativo = value;
				_referenteAmministrativoSet = true;
			}
		}

		public SqlString SedeAmministrativa
		{
			get {return _sedeAmministrativa;}
			set
			{
				_sedeAmministrativa = value;
				_sedeAmministrativaSet = true;
			}
		}

		public SqlBoolean Abilitato
		{
			get {return _abilitato;}
			set
			{
				_abilitato = value;
				_abilitatoSet = true;
			}
		}
		#endregion
		
		#region Execute Methods
		/// <summary>
		/// This method calls the Operatori_Store stored procedure.
		/// </summary>
		public virtual void Execute(SqlConnection cn)
		{
			SqlCommand cmd = cn.CreateCommand();
			
			try
			{
				cmd.CommandText = "[dbo].[Operatori_Store]";
				cmd.CommandType = CommandType.StoredProcedure;
				
				#region Populate Parameters
				SqlParameter prmReturnValue = cmd.Parameters.Add("@RETURN_VALUE", SqlDbType.Int);
				prmReturnValue.Direction = ParameterDirection.ReturnValue;
				
				SqlParameter prmCodiceOperatore = cmd.Parameters.Add("@CodiceOperatore", SqlDbType.VarChar);
				prmCodiceOperatore.Direction = ParameterDirection.Input;
				prmCodiceOperatore.Size = 16;
				if (_codiceOperatoreSet == true || this.CodiceOperatore.IsNull == false)
				{
					prmCodiceOperatore.Value = this.CodiceOperatore;
				}
				
				SqlParameter prmRagioneSociale = cmd.Parameters.Add("@RagioneSociale", SqlDbType.NVarChar);
				prmRagioneSociale.Direction = ParameterDirection.Input;
				prmRagioneSociale.Size = 256;
				if (_ragioneSocialeSet == true || this.RagioneSociale.IsNull == false)
				{
					prmRagioneSociale.Value = this.RagioneSociale;
				}
				
				SqlParameter prmIndirizzo1 = cmd.Parameters.Add("@Indirizzo1", SqlDbType.NVarChar);
				prmIndirizzo1.Direction = ParameterDirection.Input;
				prmIndirizzo1.Size = 60;
				if (_indirizzo1Set == true || this.Indirizzo1.IsNull == false)
				{
					prmIndirizzo1.Value = this.Indirizzo1;
				}
				
				SqlParameter prmIndirizzo2 = cmd.Parameters.Add("@Indirizzo2", SqlDbType.NVarChar);
				prmIndirizzo2.Direction = ParameterDirection.Input;
				prmIndirizzo2.Size = 60;
				if (_indirizzo2Set == true || this.Indirizzo2.IsNull == false)
				{
					prmIndirizzo2.Value = this.Indirizzo2;
				}
				
				SqlParameter prmCitta = cmd.Parameters.Add("@Citta", SqlDbType.NVarChar);
				prmCitta.Direction = ParameterDirection.Input;
				prmCitta.Size = 60;
				if (_cittaSet == true || this.Citta.IsNull == false)
				{
					prmCitta.Value = this.Citta;
				}
				
				SqlParameter prmNazione = cmd.Parameters.Add("@Nazione", SqlDbType.NVarChar);
				prmNazione.Direction = ParameterDirection.Input;
				prmNazione.Size = 30;
				if (_nazioneSet == true || this.Nazione.IsNull == false)
				{
					prmNazione.Value = this.Nazione;
				}
				
				SqlParameter prmCodiceFiscale = cmd.Parameters.Add("@CodiceFiscale", SqlDbType.VarChar);
				prmCodiceFiscale.Direction = ParameterDirection.Input;
				prmCodiceFiscale.Size = 16;
				if (_codiceFiscaleSet == true || this.CodiceFiscale.IsNull == false)
				{
					prmCodiceFiscale.Value = this.CodiceFiscale;
				}
				
				SqlParameter prmPartitaIVA = cmd.Parameters.Add("@PartitaIVA", SqlDbType.VarChar);
				prmPartitaIVA.Direction = ParameterDirection.Input;
				prmPartitaIVA.Size = 10;
				if (_partitaIVASet == true || this.PartitaIVA.IsNull == false)
				{
					prmPartitaIVA.Value = this.PartitaIVA;
				}
				
				SqlParameter prmFax = cmd.Parameters.Add("@Fax", SqlDbType.VarChar);
				prmFax.Direction = ParameterDirection.Input;
				prmFax.Size = 32;
				if (_faxSet == true || this.Fax.IsNull == false)
				{
					prmFax.Value = this.Fax;
				}
				
				SqlParameter prmEmail = cmd.Parameters.Add("@Email", SqlDbType.NVarChar);
				prmEmail.Direction = ParameterDirection.Input;
				prmEmail.Size = 128;
				if (_emailSet == true || this.Email.IsNull == false)
				{
					prmEmail.Value = this.Email;
				}
				
				SqlParameter prmReferenteAmministrativo = cmd.Parameters.Add("@ReferenteAmministrativo", SqlDbType.NVarChar);
				prmReferenteAmministrativo.Direction = ParameterDirection.Input;
				prmReferenteAmministrativo.Size = 256;
				if (_referenteAmministrativoSet == true || this.ReferenteAmministrativo.IsNull == false)
				{
					prmReferenteAmministrativo.Value = this.ReferenteAmministrativo;
				}
				
				SqlParameter prmSedeAmministrativa = cmd.Parameters.Add("@SedeAmministrativa", SqlDbType.NVarChar);
				prmSedeAmministrativa.Direction = ParameterDirection.Input;
				prmSedeAmministrativa.Size = 256;
				if (_sedeAmministrativaSet == true || this.SedeAmministrativa.IsNull == false)
				{
					prmSedeAmministrativa.Value = this.SedeAmministrativa;
				}
				
				SqlParameter prmAbilitato = cmd.Parameters.Add("@Abilitato", SqlDbType.Bit);
				prmAbilitato.Direction = ParameterDirection.Input;
				if (_abilitatoSet == true || this.Abilitato.IsNull == false)
				{
					prmAbilitato.Value = this.Abilitato;
				}
				#endregion
				
				#region Execute Command
				_recordsAffected = cmd.ExecuteNonQuery();
				#endregion
				
				#region Get Output Parameters
				if (prmReturnValue.Value != null && prmReturnValue.Value != DBNull.Value)
				{
					_returnValue = (int)prmReturnValue.Value;
				}
				
				#endregion
			}
			finally
			{
				cmd.Dispose();
			}
		}
		
		/// <summary>
		/// This method calls the Operatori_Store stored procedure.
		/// </summary>
		/// <param name="cn">La connessione da usare</param>
		/// <param name="codiceOperatore"></param>
		/// <param name="ragioneSociale"></param>
		/// <param name="indirizzo1"></param>
		/// <param name="indirizzo2"></param>
		/// <param name="citta"></param>
		/// <param name="nazione"></param>
		/// <param name="codiceFiscale"></param>
		/// <param name="partitaIVA"></param>
		/// <param name="fax"></param>
		/// <param name="email"></param>
		/// <param name="referenteAmministrativo"></param>
		/// <param name="sedeAmministrativa"></param>
		/// <param name="abilitato"></param>
		public static void Execute(
			#region Parameters
			SqlConnection cn,
			SqlString codiceOperatore,
			SqlString ragioneSociale,
			SqlString indirizzo1,
			SqlString indirizzo2,
			SqlString citta,
			SqlString nazione,
			SqlString codiceFiscale,
			SqlString partitaIVA,
			SqlString fax,
			SqlString email,
			SqlString referenteAmministrativo,
			SqlString sedeAmministrativa,
			SqlBoolean abilitato
			#endregion
			)
		{
			Operatori_Store operatori_Store = new Operatori_Store();
			
			#region Assign Property Values
			operatori_Store.CodiceOperatore = codiceOperatore;
			operatori_Store.RagioneSociale = ragioneSociale;
			operatori_Store.Indirizzo1 = indirizzo1;
			operatori_Store.Indirizzo2 = indirizzo2;
			operatori_Store.Citta = citta;
			operatori_Store.Nazione = nazione;
			operatori_Store.CodiceFiscale = codiceFiscale;
			operatori_Store.PartitaIVA = partitaIVA;
			operatori_Store.Fax = fax;
			operatori_Store.Email = email;
			operatori_Store.ReferenteAmministrativo = referenteAmministrativo;
			operatori_Store.SedeAmministrativa = sedeAmministrativa;
			operatori_Store.Abilitato = abilitato;
			#endregion
			
			operatori_Store.Execute(cn);
			
			#region Get Property Values
			
			#endregion
		}
		#endregion
	}
	#endregion
}
