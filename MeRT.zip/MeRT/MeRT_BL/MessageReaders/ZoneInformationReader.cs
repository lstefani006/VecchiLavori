using System;
using System.Collections;
using System.Collections.Specialized;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Globalization;
using System.Xml;
using System.Xml.Serialization;

using MeRT_BL.Messaging.ZoneInformationTypes;
using Messaging;
using PIPEDoc;

namespace MeRT_BL.Messaging
{
	public class ZoneInformationFacade : TransactionFacade
	{
		static ZoneInformationFacade()
		{
			_xZi = new XmlSerializer(typeof (ZoneInformation));
		}

		public ZoneInformationFacade(PIPTransaction tr)
			: base(tr, PIPTransactionAttributes.ReferenceNumber) // TODO capire quali attributi ci vogliono
		{
			_zi = null;
		}

		public override string FA_MarketParticipantNumber
		{
			get { return PIPTransaction.ReferenceNumber; } //LEO TODO ??? non esiste dentro : che ci metto ?
		}

		public override string FA_TransactionType
		{
			get { return "FA"; }
		}

		public override void Read(XmlReader xr)
		{
			_zi = (ZoneInformation) _xZi.Deserialize(xr);
		}

		public override void Write(XmlWriter xw)
		{
			base.WriteStartPIP(xw);
			_xZi.Serialize(xw, _zi);
			base.WriteEndPIP(xw);
		}

		public override void Execute(object executeState)
		{
			if (this.Valid == false)
				return;
			SqlConnection cn = executeState as SqlConnection;
			if (cn == null)// TODO
				return;

			try
			{
				// qui leggo i dati e li accorpo
				ValueFlussiList ar = new ValueFlussiList();
				foreach (MarketDetail md in _zi.MarketDetail)
				{
					string dataFlusso = _zi.Date;
					string codiceMercato = md.Market.ToString();

					foreach (InterZonalDetail zd in md.InterZonalDetail)
					{
						string daZona = zd.FromZone.ToString();
						string aZona = zd.ToZone.ToString();

						foreach (InterZonalLimits izl in zd.InterZonalLimits)
						{
							string coeff = izl.ConnectionCoefficient;
							string limit = izl.ConnectionLimit;
							string ora = izl.Hour;

							ValueFlussi vf = new ValueFlussi(dataFlusso, ora, codiceMercato, daZona, aZona, coeff, limit);
							ar.Add(vf);
						}
					}
				}

				// qui controllo eventuali limiti/limiti inversi dimenticati
				foreach (ValueFlussi vf in ar)
					vf.Check();

				// qui Salvo!!
				StringCollection mercatiCancellati = new StringCollection();
				foreach (ValueFlussi vf in ar)
				{
					if (mercatiCancellati.Contains(vf.mercato) == false)
					{
						mercatiCancellati.Add(vf.mercato);
						IP_VincoliInterzonali_DeleteFlowDate.Execute(cn, vf.dataFlusso, vf.mercato);
					}

					IP_VincoliInterZonali_Store.Execute(cn, vf.dataFlusso, vf.ora, vf.mercato, vf.daZona, vf.aZona, vf.coeff,  vf.limit, vf.rlimit);
				}

			}
			catch (MessagingExecption e)
			{
				this.SetError(e.Code.ToString(), e.Msg);
			}
		}

		private class ValueFlussiList
		{
			private ArrayList ar = new ArrayList();

			public void Add(ValueFlussi vf)
			{
				bool found = false;
				foreach (ValueFlussi c in ar)
				{
					if (c.IsSameFlusso(vf))
					{
						c.Aggiorna(vf);
						found = true;
						break;
					}
				}
				if (found == false)
					ar.Add(vf);
			}


			public IEnumerator GetEnumerator()
			{
				return ar.GetEnumerator();
			}
		}

		private class ValueFlussi
		{
			public readonly DateTime dataFlusso;
			public readonly byte ora;
			public readonly string mercato;
			public readonly string daZona;
			public readonly string aZona;
			public readonly double coeff;

			public double limit
			{
				get { return _limit; }
			}

			public double rlimit
			{
				get { return _rlimit; }
			}

			private double _limit;
			private double _rlimit;
			private bool _limitSet = false;
			private bool _rlimitSet = false;

			private static CultureInfo it = new CultureInfo("it-it");


			public ValueFlussi(string df, string ora, string m, string da, string a, string c, string lim)
			{
				if (m == null || m.Length == 0)
					throw  new MessagingExecption(MessagingError.Z1, "codice mercato in formato errato");

				if (da == null || da.Length == 0)
					throw  new MessagingExecption(MessagingError.Z2, "zona in formato errato");

				if (a == null || a.Length == 0)
					throw  new MessagingExecption(MessagingError.Z3, "zona in formato errato");

				try
				{
					this.dataFlusso = GetDate(df);
				}
				catch (Exception)
				{
					throw new MessagingExecption(MessagingError.Z4, "da={0} a={1}: data di flusso in formato errato", da, a);
				}

				try
				{
					this.ora = (byte)int.Parse(ora, it);
				}
				catch (Exception)
				{
					throw new MessagingExecption(MessagingError.Z5, "da={0} a={1}: ora in formato errato", da, a);
				}

				this.mercato = m;


				double d_c;
				if (!double.TryParse(c, NumberStyles.Float, it, out d_c))
					throw new MessagingExecption(MessagingError.Z6, "da={0} a={1}: coefficiente in formato errato", da, a);

				double d_l;
				if (!double.TryParse(lim, NumberStyles.Float, it, out d_l))
					throw new MessagingExecption(MessagingError.Z7, "da={0} a={1}: limite in formato errato", da, a);


				if (string.Compare(da, a) > 0)
				{
					this.daZona = da;
					this.aZona = a;
					this.coeff = d_c;
					this._limit = d_l;
					this._limitSet = true;
				}
				else
				{
					this.daZona = a;
					this.aZona = da;
					this.coeff = d_c;
					this._rlimit = -d_l;
					this._rlimitSet = true;
				}
			}

			public bool IsSameFlusso(ValueFlussi vf)
			{
				if (vf.dataFlusso != this.dataFlusso) return false;
				if (vf.mercato != this.mercato) return false;
				if (vf.ora != this.ora) return false;
				if (vf.daZona == this.daZona && vf.aZona == this.aZona) return true;
				if (vf.daZona == this.aZona && vf.aZona == this.daZona) return true;
				return false;
			}

			public void Aggiorna(ValueFlussi vf)
			{
				if (this.coeff != vf.coeff)
					throw new MessagingExecption(MessagingError.Z8, "Coefficiente da={0} a={1} diverso dal coeff da={1} a={0}", this.daZona, this.aZona);

				if (vf.daZona == this.daZona && vf.aZona == this.aZona)
				{
					if (_limitSet)
						throw new MessagingExecption(MessagingError.Z9, "Limite da={0} a={1} gia` impostato", this.daZona, this.aZona);
					this._limit = vf._limit;
					this._limitSet = true;
				}
				else if (vf.daZona == this.aZona && vf.aZona == this.daZona)
				{
					if (_rlimitSet)
						throw new MessagingExecption(MessagingError.Z10, "Limite inverso da={0} a={1} gia` impostato", this.daZona, this.aZona);
					this._rlimit = vf._limit;
					this._rlimitSet = true;
				}
				else
					throw new Exception("Problema in IsSameFlusso");
			}

			private static DateTime GetDate(string g)
			{
				int anno = int.Parse(g.Substring(0, 4));
				int mese = int.Parse(g.Substring(4, 2));
				int giorno = int.Parse(g.Substring(6, 2));
				return new DateTime(anno, mese, giorno);
			}

			public void Check()
			{
				if (_limitSet == false)
					throw new MessagingExecption(MessagingError.Z11, "Limite da={0} a={1} non impostato", this.daZona, this.aZona);

				if (_rlimitSet == false)
					throw new MessagingExecption(MessagingError.Z12, "Limite inverso da={0} a={1} non impostato", this.daZona, this.aZona);
			}
		}


		private static XmlSerializer _xZi;
		protected ZoneInformation _zi;
	}

	
	#region DB Wrappers


	#region IP_VincoliInterZonali_Store Wrapper
	/// <summary>
	/// This class is a wrapper for the IP_VincoliInterZonali_Store stored procedure.
	/// </summary>
	internal class IP_VincoliInterZonali_Store
	{
		#region Member Variables
		protected int _recordsAffected = -1;
		protected int _returnValue = 0;
		protected SqlDateTime _flowDate = SqlDateTime.Null;
		protected bool _flowDateSet = false;
		protected SqlByte _ora = SqlByte.Null;
		protected bool _oraSet = false;
		protected SqlString _codiceMercato = SqlString.Null;
		protected bool _codiceMercatoSet = false;
		protected SqlString _daZona = SqlString.Null;
		protected bool _daZonaSet = false;
		protected SqlString _aZona = SqlString.Null;
		protected bool _aZonaSet = false;
		protected SqlDouble _coefficienteTrasporto = SqlDouble.Null;
		protected bool _coefficienteTrasportoSet = false;
		protected SqlDouble _flussoMassimoDaA = SqlDouble.Null;
		protected bool _flussoMassimoDaASet = false;
		protected SqlDouble _flussoMassimoADa = SqlDouble.Null;
		protected bool _flussoMassimoADaSet = false;
		#endregion
		
		#region Constructors
		public IP_VincoliInterZonali_Store()
		{
		}
		#endregion
		
		#region Public Properties
		/// <summary>
		/// Gets the return value from the IP_VincoliInterZonali_Store stored procedure.
		/// </summary>
		public int ReturnValue
		{
			get {return _returnValue;}
		}
		
		/// <summary>
		/// Gets the number of rows changed, inserted, or deleted by execution of the IP_VincoliInterZonali_Store stored procedure.
		/// </summary>
		public int RecordsAffected
		{
			get {return _recordsAffected;}
		}
		
		public SqlDateTime FlowDate
		{
			get {return _flowDate;}
			set
			{
				_flowDate = value;
				_flowDateSet = true;
			}
		}

		public SqlByte Ora
		{
			get {return _ora;}
			set
			{
				_ora = value;
				_oraSet = true;
			}
		}

		public SqlString CodiceMercato
		{
			get {return _codiceMercato;}
			set
			{
				_codiceMercato = value;
				_codiceMercatoSet = true;
			}
		}

		public SqlString daZona
		{
			get {return _daZona;}
			set
			{
				_daZona = value;
				_daZonaSet = true;
			}
		}

		public SqlString aZona
		{
			get {return _aZona;}
			set
			{
				_aZona = value;
				_aZonaSet = true;
			}
		}

		public SqlDouble CoefficienteTrasporto
		{
			get {return _coefficienteTrasporto;}
			set
			{
				_coefficienteTrasporto = value;
				_coefficienteTrasportoSet = true;
			}
		}

		public SqlDouble FlussoMassimoDaA
		{
			get {return _flussoMassimoDaA;}
			set
			{
				_flussoMassimoDaA = value;
				_flussoMassimoDaASet = true;
			}
		}

		public SqlDouble FlussoMassimoADa
		{
			get {return _flussoMassimoADa;}
			set
			{
				_flussoMassimoADa = value;
				_flussoMassimoADaSet = true;
			}
		}
		#endregion
		
		#region Execute Methods
		/// <summary>
		/// This method calls the IP_VincoliInterZonali_Store stored procedure.
		/// </summary>
		public virtual void Execute(SqlConnection cn)
		{
			SqlCommand cmd = cn.CreateCommand();
			
			try
			{
				cmd.CommandText = "[dbo].[IP_VincoliInterZonali_Store]";
				cmd.CommandType = CommandType.StoredProcedure;
				
				#region Populate Parameters
				SqlParameter prmReturnValue = cmd.Parameters.Add("@RETURN_VALUE", SqlDbType.Int);
				prmReturnValue.Direction = ParameterDirection.ReturnValue;
				
				SqlParameter prmFlowDate = cmd.Parameters.Add("@FlowDate", SqlDbType.SmallDateTime);
				prmFlowDate.Direction = ParameterDirection.Input;
				if (_flowDateSet == true || this.FlowDate.IsNull == false)
				{
					prmFlowDate.Value = this.FlowDate;
				}
				
				SqlParameter prmOra = cmd.Parameters.Add("@Ora", SqlDbType.TinyInt);
				prmOra.Direction = ParameterDirection.Input;
				if (_oraSet == true || this.Ora.IsNull == false)
				{
					prmOra.Value = this.Ora;
				}
				
				SqlParameter prmCodiceMercato = cmd.Parameters.Add("@CodiceMercato", SqlDbType.VarChar);
				prmCodiceMercato.Direction = ParameterDirection.Input;
				prmCodiceMercato.Size = 4;
				if (_codiceMercatoSet == true || this.CodiceMercato.IsNull == false)
				{
					prmCodiceMercato.Value = this.CodiceMercato;
				}
				
				SqlParameter prmdaZona = cmd.Parameters.Add("@daZona", SqlDbType.VarChar);
				prmdaZona.Direction = ParameterDirection.Input;
				prmdaZona.Size = 4;
				if (_daZonaSet == true || this.daZona.IsNull == false)
				{
					prmdaZona.Value = this.daZona;
				}
				
				SqlParameter prmaZona = cmd.Parameters.Add("@aZona", SqlDbType.VarChar);
				prmaZona.Direction = ParameterDirection.Input;
				prmaZona.Size = 4;
				if (_aZonaSet == true || this.aZona.IsNull == false)
				{
					prmaZona.Value = this.aZona;
				}
				
				SqlParameter prmCoefficienteTrasporto = cmd.Parameters.Add("@CoefficienteTrasporto", SqlDbType.Float);
				prmCoefficienteTrasporto.Direction = ParameterDirection.Input;
				prmCoefficienteTrasporto.Precision = 15;
				prmCoefficienteTrasporto.Scale = 0;
				if (_coefficienteTrasportoSet == true || this.CoefficienteTrasporto.IsNull == false)
				{
					prmCoefficienteTrasporto.Value = this.CoefficienteTrasporto;
				}
				
				SqlParameter prmFlussoMassimoDaA = cmd.Parameters.Add("@FlussoMassimoDaA", SqlDbType.Float);
				prmFlussoMassimoDaA.Direction = ParameterDirection.Input;
				prmFlussoMassimoDaA.Precision = 15;
				prmFlussoMassimoDaA.Scale = 0;
				if (_flussoMassimoDaASet == true || this.FlussoMassimoDaA.IsNull == false)
				{
					prmFlussoMassimoDaA.Value = this.FlussoMassimoDaA;
				}
				
				SqlParameter prmFlussoMassimoADa = cmd.Parameters.Add("@FlussoMassimoADa", SqlDbType.Float);
				prmFlussoMassimoADa.Direction = ParameterDirection.Input;
				prmFlussoMassimoADa.Precision = 15;
				prmFlussoMassimoADa.Scale = 0;
				if (_flussoMassimoADaSet == true || this.FlussoMassimoADa.IsNull == false)
				{
					prmFlussoMassimoADa.Value = this.FlussoMassimoADa;
				}
				#endregion
				
				#region Execute Command
				_recordsAffected = cmd.ExecuteNonQuery();
				#endregion
				
				#region Get Output Parameters
				if (prmReturnValue.Value != null && prmReturnValue.Value != DBNull.Value)
				{
					_returnValue = (int)prmReturnValue.Value;
				}
				
				#endregion
			}
			finally
			{
				cmd.Dispose();
			}
		}
		
		/// <summary>
		/// This method calls the IP_VincoliInterZonali_Store stored procedure.
		/// </summary>
		/// <param name="cn">La connessione da usare</param>
		/// <param name="flowDate"></param>
		/// <param name="ora"></param>
		/// <param name="codiceMercato"></param>
		/// <param name="daZona"></param>
		/// <param name="aZona"></param>
		/// <param name="coefficienteTrasporto"></param>
		/// <param name="flussoMassimoDaA"></param>
		/// <param name="flussoMassimoADa"></param>
		public static void Execute(
			#region Parameters
			SqlConnection cn,
			SqlDateTime flowDate,
			SqlByte ora,
			SqlString codiceMercato,
			SqlString daZona,
			SqlString aZona,
			SqlDouble coefficienteTrasporto,
			SqlDouble flussoMassimoDaA,
			SqlDouble flussoMassimoADa
			#endregion
			)
		{
			IP_VincoliInterZonali_Store iP_VincoliInterZonali_Store = new IP_VincoliInterZonali_Store();
			
			#region Assign Property Values
			iP_VincoliInterZonali_Store.FlowDate = flowDate;
			iP_VincoliInterZonali_Store.Ora = ora;
			iP_VincoliInterZonali_Store.CodiceMercato = codiceMercato;
			iP_VincoliInterZonali_Store.daZona = daZona;
			iP_VincoliInterZonali_Store.aZona = aZona;
			iP_VincoliInterZonali_Store.CoefficienteTrasporto = coefficienteTrasporto;
			iP_VincoliInterZonali_Store.FlussoMassimoDaA = flussoMassimoDaA;
			iP_VincoliInterZonali_Store.FlussoMassimoADa = flussoMassimoADa;
			#endregion
			
			iP_VincoliInterZonali_Store.Execute(cn);
			
			#region Get Property Values
			
			#endregion
		}
		#endregion
	}
	#endregion
	#region IP_VincoliInterzonali_DeleteFlowDate Wrapper
	/// <summary>
	/// This class is a wrapper for the IP_VincoliInterzonali_DeleteFlowDate stored procedure.
	/// </summary>
	internal class IP_VincoliInterzonali_DeleteFlowDate
	{
		#region Member Variables
		protected int _recordsAffected = -1;
		protected int _returnValue = 0;
		protected SqlDateTime _flowDate = SqlDateTime.Null;
		protected bool _flowDateSet = false;
		protected SqlString _codiceMercato = SqlString.Null;
		protected bool _codiceMercatoSet = false;
		#endregion
		
		#region Constructors
		public IP_VincoliInterzonali_DeleteFlowDate()
		{
		}
		#endregion
		
		#region Public Properties
		/// <summary>
		/// Gets the return value from the IP_VincoliInterzonali_DeleteFlowDate stored procedure.
		/// </summary>
		public int ReturnValue
		{
			get {return _returnValue;}
		}
		
		/// <summary>
		/// Gets the number of rows changed, inserted, or deleted by execution of the IP_VincoliInterzonali_DeleteFlowDate stored procedure.
		/// </summary>
		public int RecordsAffected
		{
			get {return _recordsAffected;}
		}
		
		public SqlDateTime FlowDate
		{
			get {return _flowDate;}
			set
			{
				_flowDate = value;
				_flowDateSet = true;
			}
		}

		public SqlString CodiceMercato
		{
			get {return _codiceMercato;}
			set
			{
				_codiceMercato = value;
				_codiceMercatoSet = true;
			}
		}
		#endregion
		
		#region Execute Methods
		/// <summary>
		/// This method calls the IP_VincoliInterzonali_DeleteFlowDate stored procedure.
		/// </summary>
		public virtual void Execute(SqlConnection cn)
		{
			SqlCommand cmd = cn.CreateCommand();
			
			try
			{
				cmd.CommandText = "[dbo].[IP_VincoliInterzonali_DeleteFlowDate]";
				cmd.CommandType = CommandType.StoredProcedure;
				
				#region Populate Parameters
				SqlParameter prmReturnValue = cmd.Parameters.Add("@RETURN_VALUE", SqlDbType.Int);
				prmReturnValue.Direction = ParameterDirection.ReturnValue;
				
				SqlParameter prmFlowDate = cmd.Parameters.Add("@FlowDate", SqlDbType.SmallDateTime);
				prmFlowDate.Direction = ParameterDirection.Input;
				if (_flowDateSet == true || this.FlowDate.IsNull == false)
				{
					prmFlowDate.Value = this.FlowDate;
				}
				
				SqlParameter prmCodiceMercato = cmd.Parameters.Add("@CodiceMercato", SqlDbType.VarChar);
				prmCodiceMercato.Direction = ParameterDirection.Input;
				prmCodiceMercato.Size = 4;
				if (_codiceMercatoSet == true || this.CodiceMercato.IsNull == false)
				{
					prmCodiceMercato.Value = this.CodiceMercato;
				}
				#endregion
				
				#region Execute Command
				_recordsAffected = cmd.ExecuteNonQuery();
				#endregion
				
				#region Get Output Parameters
				if (prmReturnValue.Value != null && prmReturnValue.Value != DBNull.Value)
				{
					_returnValue = (int)prmReturnValue.Value;
				}
				
				#endregion
			}
			finally
			{
				cmd.Dispose();
			}
		}
		
		/// <summary>
		/// This method calls the IP_VincoliInterzonali_DeleteFlowDate stored procedure.
		/// </summary>
		/// <param name="cn">La connessione da usare</param>
		/// <param name="flowDate"></param>
		/// <param name="codiceMercato"></param>
		public static void Execute(
			#region Parameters
			SqlConnection cn,
			SqlDateTime flowDate,
			SqlString codiceMercato
			#endregion
			)
		{
			IP_VincoliInterzonali_DeleteFlowDate iP_VincoliInterzonali_DeleteFlowDate = new IP_VincoliInterzonali_DeleteFlowDate();
			
			#region Assign Property Values
			iP_VincoliInterzonali_DeleteFlowDate.FlowDate = flowDate;
			iP_VincoliInterzonali_DeleteFlowDate.CodiceMercato = codiceMercato;
			#endregion
			
			iP_VincoliInterzonali_DeleteFlowDate.Execute(cn);
			
			#region Get Property Values
			
			#endregion
		}
		#endregion
	}
	#endregion

	#endregion

}