using System;
using System.Data;
using System.Data.SqlTypes;
using System.Data.SqlClient;
using System.Xml;
using System.Xml.Serialization;

using MeRT_BL.Messaging.RelevantExchangePointTypes;
using Messaging;
using PIPEDoc;

namespace MeRT_BL.Messaging
{
	public class RelevantExchangePointFacade : TransactionFacade
	{
		public RelevantExchangePointFacade(PIPTransaction tr) 
			: base(tr, PIPTransactionAttributes.ReferenceNumber)
		{
			_element = null;
		}

		public override string FA_MarketParticipantNumber
		{
			get 
			{ 
				if (_element == null)
					return PIPTransaction.ReferenceNumber;
				return _element.RelevantExchangePointID; 
			}
		}

		public override string FA_TransactionType
		{
			get { return "FA"; }
		}

		public override void Read(XmlReader xr)
		{
			_element = (RelevantExchangePoint) _serializer.Deserialize(xr);
		}

		public override void Write(XmlWriter xw)
		{
			if (_element == null)
				return;

			WriteStartPIP(xw);
			_serializer.Serialize(xw, _element);
			WriteEndPIP(xw);
		}
		public override void Execute(object executeState)
		{
			if (this.Valid == false)
				return;
			SqlConnection cn = executeState as SqlConnection;
			if (cn == null)// TODO
				return;

			try
			{
				PuntiDiScambioRilevanti_Store.Execute(cn
					, _element.RelevantExchangePointID
					, _element.Zone.ToString()
					, _element.Name
					, SimpleType.LocaleDecimalToDouble(_element.TransmissionLossFactor));
			}
			catch (Exception e)
			{
				this.SetError(MessagingError.E0.ToString(), e.Message);
			}
		}


		private static XmlSerializer _serializer = 
			new XmlSerializer(typeof(RelevantExchangePoint));
		private RelevantExchangePoint _element = null;
	}
	#region PuntiDiScambioRilevanti_Store Wrapper
    /// <summary>
    /// This class is a wrapper for the PuntiDiScambioRilevanti_Store stored procedure.
    /// </summary>
    internal class PuntiDiScambioRilevanti_Store
    {
		#region Member Variables
		protected int _recordsAffected = -1;
		protected int _returnValue = 0;
		protected SqlString _codicePDSR = SqlString.Null;
		protected bool _codicePDSRSet = false;
		protected SqlString _codiceZona = SqlString.Null;
		protected bool _codiceZonaSet = false;
		protected SqlString _descrizione = SqlString.Null;
		protected bool _descrizioneSet = false;
		protected SqlDouble _coefficientePerdita = SqlDouble.Null;
		protected bool _coefficientePerditaSet = false;
		#endregion
		
		#region Constructors
		public PuntiDiScambioRilevanti_Store()
		{
		}
		#endregion
		
		#region Public Properties
		/// <summary>
		/// Gets the return value from the PuntiDiScambioRilevanti_Store stored procedure.
		/// </summary>
		public int ReturnValue
		{
			get {return _returnValue;}
		}
		
		/// <summary>
		/// Gets the number of rows changed, inserted, or deleted by execution of the PuntiDiScambioRilevanti_Store stored procedure.
		/// </summary>
		public int RecordsAffected
		{
			get {return _recordsAffected;}
		}
		
		public SqlString CodicePDSR
		{
			get {return _codicePDSR;}
			set
			{
				_codicePDSR = value;
				_codicePDSRSet = true;
			}
		}

		public SqlString CodiceZona
		{
			get {return _codiceZona;}
			set
			{
				_codiceZona = value;
				_codiceZonaSet = true;
			}
		}

		public SqlString Descrizione
		{
			get {return _descrizione;}
			set
			{
				_descrizione = value;
				_descrizioneSet = true;
			}
		}

		public SqlDouble CoefficientePerdita
		{
			get {return _coefficientePerdita;}
			set
			{
				_coefficientePerdita = value;
				_coefficientePerditaSet = true;
			}
		}
		#endregion
		
		#region Execute Methods
		/// <summary>
		/// This method calls the PuntiDiScambioRilevanti_Store stored procedure.
		/// </summary>
		public virtual void Execute(SqlConnection cn)
		{
			SqlCommand cmd = cn.CreateCommand();
			
			try
			{
				cmd.CommandText = "[dbo].[PuntiDiScambioRilevanti_Store]";
				cmd.CommandType = CommandType.StoredProcedure;
				
				#region Populate Parameters
				SqlParameter prmReturnValue = cmd.Parameters.Add("@RETURN_VALUE", SqlDbType.Int);
				prmReturnValue.Direction = ParameterDirection.ReturnValue;
				
				SqlParameter prmCodicePDSR = cmd.Parameters.Add("@CodicePDSR", SqlDbType.VarChar);
				prmCodicePDSR.Direction = ParameterDirection.Input;
					prmCodicePDSR.Size = 16;
				if (_codicePDSRSet == true || this.CodicePDSR.IsNull == false)
				{
					prmCodicePDSR.Value = this.CodicePDSR;
				}
				
				SqlParameter prmCodiceZona = cmd.Parameters.Add("@CodiceZona", SqlDbType.VarChar);
				prmCodiceZona.Direction = ParameterDirection.Input;
					prmCodiceZona.Size = 4;
				if (_codiceZonaSet == true || this.CodiceZona.IsNull == false)
				{
					prmCodiceZona.Value = this.CodiceZona;
				}
				
				SqlParameter prmDescrizione = cmd.Parameters.Add("@Descrizione", SqlDbType.NVarChar);
				prmDescrizione.Direction = ParameterDirection.Input;
					prmDescrizione.Size = 80;
				if (_descrizioneSet == true || this.Descrizione.IsNull == false)
				{
					prmDescrizione.Value = this.Descrizione;
				}
				
				SqlParameter prmCoefficientePerdita = cmd.Parameters.Add("@CoefficientePerdita", SqlDbType.Float);
				prmCoefficientePerdita.Direction = ParameterDirection.Input;
					prmCoefficientePerdita.Precision = 15;
					prmCoefficientePerdita.Scale = 0;
				if (_coefficientePerditaSet == true || this.CoefficientePerdita.IsNull == false)
				{
					prmCoefficientePerdita.Value = this.CoefficientePerdita;
				}
				#endregion
				
				#region Execute Command
				_recordsAffected = cmd.ExecuteNonQuery();
				#endregion
				
				#region Get Output Parameters
				if (prmReturnValue.Value != null && prmReturnValue.Value != DBNull.Value)
				{
					_returnValue = (int)prmReturnValue.Value;
				}
				
				#endregion
			}
			finally
			{
				cmd.Dispose();
			}
		}
		
		/// <summary>
		/// This method calls the PuntiDiScambioRilevanti_Store stored procedure.
		/// </summary>
		/// <param name="cn">La connessione da usare</param>
		/// <param name="codicePDSR"></param>
		/// <param name="codiceZona"></param>
		/// <param name="descrizione"></param>
		/// <param name="coefficientePerdita"></param>
		public static void Execute(
				#region Parameters
				SqlConnection cn,
				SqlString codicePDSR,
				SqlString codiceZona,
				SqlString descrizione,
				SqlDouble coefficientePerdita
				#endregion
		    )
		{
			PuntiDiScambioRilevanti_Store puntiDiScambioRilevanti_Store = new PuntiDiScambioRilevanti_Store();
			
			#region Assign Property Values
			puntiDiScambioRilevanti_Store.CodicePDSR = codicePDSR;
			puntiDiScambioRilevanti_Store.CodiceZona = codiceZona;
			puntiDiScambioRilevanti_Store.Descrizione = descrizione;
			puntiDiScambioRilevanti_Store.CoefficientePerdita = coefficientePerdita;
			#endregion
			
			puntiDiScambioRilevanti_Store.Execute(cn);
			
			#region Get Property Values
			
			#endregion
		}
		#endregion
	}
	#endregion
}
