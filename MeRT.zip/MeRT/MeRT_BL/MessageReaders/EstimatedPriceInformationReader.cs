using System;
using System.Data;
using System.Data.SqlTypes;
using System.Data.SqlClient;
using System.Xml;
using System.Xml.Serialization;

using MeRT_BL.Messaging.EstimatedPriceInformationTypes;
using Messaging;
using PIPEDoc;

namespace MeRT_BL.Messaging
{
	public class EstimatedPriceInformationFacade: TransactionFacade
	{
		public EstimatedPriceInformationFacade(PIPTransaction tr)
			: base(tr, PIPTransactionAttributes.ReferenceNumber){}

		public override string FA_MarketParticipantNumber
		{
			get { return PIPTransaction.ReferenceNumber; }
		}

		public override string FA_TransactionType
		{
			get { return "FA"; }
		}

		public override void Read(XmlReader xr)
		{
			_element = (EstimatedPriceInformation) _serializer.Deserialize(xr);
		}

		public override void Write(XmlWriter xw)
		{
			if (_element == null)
				return;

			WriteStartPIP(xw);
			_serializer.Serialize(xw, _element);
			WriteEndPIP(xw);
		}

		public override void Execute(object executeState)
		{
			if (this.Valid == false)
				return;
			SqlConnection cn = executeState as SqlConnection;
			if (cn == null)// TODO
				return;
			try
			{
				DateTime flowDate = SimpleType.DateTypeToDateTime(_element.Date);
				string codiceMercato = _element.Market.ToString();
				foreach (EstimatedPriceInformationZoneDetail zona in _element.ZoneDetail)
				{
					string codiceZona = zona.Zone.ToString();
					foreach (EstimatedPrice price in zona.EstimatedPrice)
					{
						IP_PrezzoConvenzionale_Store.Execute(cn
							, flowDate
							, SimpleType.HourIntervalTypeToByte(price.Hour)
							, codiceMercato
							, codiceZona
							, SimpleType.LocaleDecimalToDouble(price.Value)
							);
					}
				}
			}
			catch (Exception e)
			{
				this.SetError(MessagingError.E0.ToString(), e.Message);
			}
		}

		private static XmlSerializer _serializer =
			new XmlSerializer(typeof(EstimatedPriceInformation));
		private EstimatedPriceInformation _element;
	}
	#region IP_PrezzoConvenzionale_Store Wrapper
	/// <summary>
	/// This class is a wrapper for the IP_PrezzoConvenzionale_Store stored procedure.
	/// </summary>
	internal class IP_PrezzoConvenzionale_Store
	{
		#region Member Variables
		protected int _recordsAffected = -1;
		protected int _returnValue = 0;
		protected SqlDateTime _flowDate = SqlDateTime.Null;
		protected bool _flowDateSet = false;
		protected SqlByte _ora = SqlByte.Null;
		protected bool _oraSet = false;
		protected SqlString _codiceMercato = SqlString.Null;
		protected bool _codiceMercatoSet = false;
		protected SqlString _codiceZona = SqlString.Null;
		protected bool _codiceZonaSet = false;
		protected SqlDouble _prezzo = SqlDouble.Null;
		protected bool _prezzoSet = false;
		#endregion
		
		#region Constructors
		public IP_PrezzoConvenzionale_Store()
		{
		}
		#endregion
		
		#region Public Properties
		/// <summary>
		/// Gets the return value from the IP_PrezzoConvenzionale_Store stored procedure.
		/// </summary>
		public int ReturnValue
		{
			get {return _returnValue;}
		}
		
		/// <summary>
		/// Gets the number of rows changed, inserted, or deleted by execution of the IP_PrezzoConvenzionale_Store stored procedure.
		/// </summary>
		public int RecordsAffected
		{
			get {return _recordsAffected;}
		}
		
		public SqlDateTime FlowDate
		{
			get {return _flowDate;}
			set
			{
				_flowDate = value;
				_flowDateSet = true;
			}
		}

		public SqlByte Ora
		{
			get {return _ora;}
			set
			{
				_ora = value;
				_oraSet = true;
			}
		}

		public SqlString CodiceMercato
		{
			get {return _codiceMercato;}
			set
			{
				_codiceMercato = value;
				_codiceMercatoSet = true;
			}
		}

		public SqlString CodiceZona
		{
			get {return _codiceZona;}
			set
			{
				_codiceZona = value;
				_codiceZonaSet = true;
			}
		}

		public SqlDouble Prezzo
		{
			get {return _prezzo;}
			set
			{
				_prezzo = value;
				_prezzoSet = true;
			}
		}
		#endregion
		
		#region Execute Methods
		/// <summary>
		/// This method calls the IP_PrezzoConvenzionale_Store stored procedure.
		/// </summary>
		public virtual void Execute(SqlConnection cn)
		{
			SqlCommand cmd = cn.CreateCommand();
			
			try
			{
				cmd.CommandText = "[dbo].[IP_PrezzoConvenzionale_Store]";
				cmd.CommandType = CommandType.StoredProcedure;
				
				#region Populate Parameters
				SqlParameter prmReturnValue = cmd.Parameters.Add("@RETURN_VALUE", SqlDbType.Int);
				prmReturnValue.Direction = ParameterDirection.ReturnValue;
				
				SqlParameter prmFlowDate = cmd.Parameters.Add("@FlowDate", SqlDbType.SmallDateTime);
				prmFlowDate.Direction = ParameterDirection.Input;
				if (_flowDateSet == true || this.FlowDate.IsNull == false)
				{
					prmFlowDate.Value = this.FlowDate;
				}
				
				SqlParameter prmOra = cmd.Parameters.Add("@Ora", SqlDbType.TinyInt);
				prmOra.Direction = ParameterDirection.Input;
				if (_oraSet == true || this.Ora.IsNull == false)
				{
					prmOra.Value = this.Ora;
				}
				
				SqlParameter prmCodiceMercato = cmd.Parameters.Add("@CodiceMercato", SqlDbType.VarChar);
				prmCodiceMercato.Direction = ParameterDirection.Input;
				prmCodiceMercato.Size = 4;
				if (_codiceMercatoSet == true || this.CodiceMercato.IsNull == false)
				{
					prmCodiceMercato.Value = this.CodiceMercato;
				}
				
				SqlParameter prmCodiceZona = cmd.Parameters.Add("@CodiceZona", SqlDbType.VarChar);
				prmCodiceZona.Direction = ParameterDirection.Input;
				prmCodiceZona.Size = 4;
				if (_codiceZonaSet == true || this.CodiceZona.IsNull == false)
				{
					prmCodiceZona.Value = this.CodiceZona;
				}
				
				SqlParameter prmPrezzo = cmd.Parameters.Add("@Prezzo", SqlDbType.Float);
				prmPrezzo.Direction = ParameterDirection.Input;
				prmPrezzo.Precision = 15;
				prmPrezzo.Scale = 0;
				if (_prezzoSet == true || this.Prezzo.IsNull == false)
				{
					prmPrezzo.Value = this.Prezzo;
				}
				#endregion
				
				#region Execute Command
				_recordsAffected = cmd.ExecuteNonQuery();
				#endregion
				
				#region Get Output Parameters
				if (prmReturnValue.Value != null && prmReturnValue.Value != DBNull.Value)
				{
					_returnValue = (int)prmReturnValue.Value;
				}
				
				#endregion
			}
			finally
			{
				cmd.Dispose();
			}
		}
		
		/// <summary>
		/// This method calls the IP_PrezzoConvenzionale_Store stored procedure.
		/// </summary>
		/// <param name="cn">La connessione da usare</param>
		/// <param name="flowDate"></param>
		/// <param name="ora"></param>
		/// <param name="codiceMercato"></param>
		/// <param name="codiceZona"></param>
		/// <param name="prezzo"></param>
		public static void Execute(
			#region Parameters
			SqlConnection cn,
			SqlDateTime flowDate,
			SqlByte ora,
			SqlString codiceMercato,
			SqlString codiceZona,
			SqlDouble prezzo
			#endregion
			)
		{
			IP_PrezzoConvenzionale_Store iP_PrezzoConvenzionale_Store = new IP_PrezzoConvenzionale_Store();
			
			#region Assign Property Values
			iP_PrezzoConvenzionale_Store.FlowDate = flowDate;
			iP_PrezzoConvenzionale_Store.Ora = ora;
			iP_PrezzoConvenzionale_Store.CodiceMercato = codiceMercato;
			iP_PrezzoConvenzionale_Store.CodiceZona = codiceZona;
			iP_PrezzoConvenzionale_Store.Prezzo = prezzo;
			#endregion
			
			iP_PrezzoConvenzionale_Store.Execute(cn);
			
			#region Get Property Values
			
			#endregion
		}
		#endregion
	}
	#endregion
}
