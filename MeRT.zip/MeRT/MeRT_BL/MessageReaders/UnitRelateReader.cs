using System;
using System.Data;
using System.Data.SqlTypes;
using System.Data.SqlClient;
using System.Xml;
using System.Xml.Serialization;

using MeRT_BL.Messaging.UnitRelateTypes;
using Messaging;
using PIPEDoc;

namespace MeRT_BL.Messaging
{
	public class UnitRelateFacade : TransactionFacade
	{
		public UnitRelateFacade(PIPTransaction tr)
			: base(tr, PIPTransactionAttributes.All){}

		public override string FA_MarketParticipantNumber
		{
			get
			{
				return PIPTransaction.ReferenceNumber;
			}
		}

		public override string FA_TransactionType
		{
			get { return "FA"; }
		}

		public override void Read(XmlReader xr)
		{
			_element = (UnitRelate) _serializer.Deserialize(xr);
		}

		public override void Write(XmlWriter xw)
		{
			if (_element == null)
				return;

			WriteStartPIP(xw);
			_serializer.Serialize(xw, _element);
			WriteEndPIP(xw);
		}
		public override void Execute(object executeState)
		{
			if (this.Valid == false)
				return;
			SqlConnection cn = executeState as SqlConnection;
			if (cn == null)// TODO
				return;

			try
			{
				if (unitRelateOperationType.Remove == _element.UnitRelateOperationType)
				{
					UnitRelate_Delete.Execute(cn, _element.UnitReferenceNumber, _element.MarketParticipantReferenceNumber);
				}
				else
				{
					bool insert = unitRelateOperationType.AddNew == _element.UnitRelateOperationType;
					UnitRelate_Store.Execute(cn, insert
						, _element.UnitReferenceNumber, _element.MarketParticipantReferenceNumber
						, _element.BidTaxType.ToString(), _element.OfferTaxType.ToString(), _element.FeeTaxType.ToString());
				}
			}
			catch (Exception e)
			{
				this.SetError(MessagingError.E0.ToString(), e.Message);
			}
		}

		private static XmlSerializer _serializer =
			new XmlSerializer(typeof(UnitRelate));
		private UnitRelate _element = null;
	}

	#region UnitRelate_Store Wrapper
	/// <summary>
	/// This class is a wrapper for the UnitRelate_Store stored procedure.
	/// </summary>
	internal class UnitRelate_Store
	{
		#region Member Variables
		protected int _recordsAffected = -1;
		protected int _returnValue = 0;
		protected SqlBoolean _isNew = SqlBoolean.Null;
		protected bool _isNewSet = false;
		protected SqlString _codiceUnita = SqlString.Null;
		protected bool _codiceUnitaSet = false;
		protected SqlString _codiceOperatore = SqlString.Null;
		protected bool _codiceOperatoreSet = false;
		protected SqlString _codiceIVAAcquisti = SqlString.Null;
		protected bool _codiceIVAAcquistiSet = false;
		protected SqlString _codiceIVAVendite = SqlString.Null;
		protected bool _codiceIVAVenditeSet = false;
		protected SqlString _codiceIVACorrispettivi = SqlString.Null;
		protected bool _codiceIVACorrispettiviSet = false;
		#endregion
		
		#region Constructors
		public UnitRelate_Store()
		{
		}
		#endregion
		
		#region Public Properties
		/// <summary>
		/// Gets the return value from the UnitRelate_Store stored procedure.
		/// </summary>
		public int ReturnValue
		{
			get {return _returnValue;}
		}
		
		/// <summary>
		/// Gets the number of rows changed, inserted, or deleted by execution of the UnitRelate_Store stored procedure.
		/// </summary>
		public int RecordsAffected
		{
			get {return _recordsAffected;}
		}
		
		public SqlBoolean IsNew
		{
			get {return _isNew;}
			set
			{
				_isNew = value;
				_isNewSet = true;
			}
		}

		public SqlString CodiceUnita
		{
			get {return _codiceUnita;}
			set
			{
				_codiceUnita = value;
				_codiceUnitaSet = true;
			}
		}

		public SqlString CodiceOperatore
		{
			get {return _codiceOperatore;}
			set
			{
				_codiceOperatore = value;
				_codiceOperatoreSet = true;
			}
		}

		public SqlString CodiceIVAAcquisti
		{
			get {return _codiceIVAAcquisti;}
			set
			{
				_codiceIVAAcquisti = value;
				_codiceIVAAcquistiSet = true;
			}
		}

		public SqlString CodiceIVAVendite
		{
			get {return _codiceIVAVendite;}
			set
			{
				_codiceIVAVendite = value;
				_codiceIVAVenditeSet = true;
			}
		}

		public SqlString CodiceIVACorrispettivi
		{
			get {return _codiceIVACorrispettivi;}
			set
			{
				_codiceIVACorrispettivi = value;
				_codiceIVACorrispettiviSet = true;
			}
		}
		#endregion
		
		#region Execute Methods
		/// <summary>
		/// This method calls the UnitRelate_Store stored procedure.
		/// </summary>
		public virtual void Execute(SqlConnection cn)
		{
			SqlCommand cmd = cn.CreateCommand();
			
			try
			{
				cmd.CommandText = "[dbo].[UnitRelate_Store]";
				cmd.CommandType = CommandType.StoredProcedure;
				
				#region Populate Parameters
				SqlParameter prmReturnValue = cmd.Parameters.Add("@RETURN_VALUE", SqlDbType.Int);
				prmReturnValue.Direction = ParameterDirection.ReturnValue;
				
				SqlParameter prmIsNew = cmd.Parameters.Add("@IsNew", SqlDbType.Bit);
				prmIsNew.Direction = ParameterDirection.Input;
				if (_isNewSet == true || this.IsNew.IsNull == false)
				{
					prmIsNew.Value = this.IsNew;
				}
				
				SqlParameter prmCodiceUnita = cmd.Parameters.Add("@CodiceUnita", SqlDbType.VarChar);
				prmCodiceUnita.Direction = ParameterDirection.Input;
				prmCodiceUnita.Size = 16;
				if (_codiceUnitaSet == true || this.CodiceUnita.IsNull == false)
				{
					prmCodiceUnita.Value = this.CodiceUnita;
				}
				
				SqlParameter prmCodiceOperatore = cmd.Parameters.Add("@CodiceOperatore", SqlDbType.VarChar);
				prmCodiceOperatore.Direction = ParameterDirection.Input;
				prmCodiceOperatore.Size = 16;
				if (_codiceOperatoreSet == true || this.CodiceOperatore.IsNull == false)
				{
					prmCodiceOperatore.Value = this.CodiceOperatore;
				}
				
				SqlParameter prmCodiceIVAAcquisti = cmd.Parameters.Add("@CodiceIVAAcquisti", SqlDbType.VarChar);
				prmCodiceIVAAcquisti.Direction = ParameterDirection.Input;
				prmCodiceIVAAcquisti.Size = 2;
				if (_codiceIVAAcquistiSet == true || this.CodiceIVAAcquisti.IsNull == false)
				{
					prmCodiceIVAAcquisti.Value = this.CodiceIVAAcquisti;
				}
				
				SqlParameter prmCodiceIVAVendite = cmd.Parameters.Add("@CodiceIVAVendite", SqlDbType.VarChar);
				prmCodiceIVAVendite.Direction = ParameterDirection.Input;
				prmCodiceIVAVendite.Size = 2;
				if (_codiceIVAVenditeSet == true || this.CodiceIVAVendite.IsNull == false)
				{
					prmCodiceIVAVendite.Value = this.CodiceIVAVendite;
				}
				
				SqlParameter prmCodiceIVACorrispettivi = cmd.Parameters.Add("@CodiceIVACorrispettivi", SqlDbType.VarChar);
				prmCodiceIVACorrispettivi.Direction = ParameterDirection.Input;
				prmCodiceIVACorrispettivi.Size = 2;
				if (_codiceIVACorrispettiviSet == true || this.CodiceIVACorrispettivi.IsNull == false)
				{
					prmCodiceIVACorrispettivi.Value = this.CodiceIVACorrispettivi;
				}
				#endregion
				
				#region Execute Command
				_recordsAffected = cmd.ExecuteNonQuery();
				#endregion
				
				#region Get Output Parameters
				if (prmReturnValue.Value != null && prmReturnValue.Value != DBNull.Value)
				{
					_returnValue = (int)prmReturnValue.Value;
				}
				
				#endregion
			}
			finally
			{
				cmd.Dispose();
			}
		}
		
		/// <summary>
		/// This method calls the UnitRelate_Store stored procedure.
		/// </summary>
		/// <param name="cn">La connessione da usare</param>
		/// <param name="isNew"></param>
		/// <param name="codiceUnita"></param>
		/// <param name="codiceOperatore"></param>
		/// <param name="codiceIVAAcquisti"></param>
		/// <param name="codiceIVAVendite"></param>
		/// <param name="codiceIVACorrispettivi"></param>
		public static void Execute(
			#region Parameters
			SqlConnection cn,
			SqlBoolean isNew,
			SqlString codiceUnita,
			SqlString codiceOperatore,
			SqlString codiceIVAAcquisti,
			SqlString codiceIVAVendite,
			SqlString codiceIVACorrispettivi
			#endregion
			)
		{
			UnitRelate_Store unitRelate_Store = new UnitRelate_Store();
			
			#region Assign Property Values
			unitRelate_Store.IsNew = isNew;
			unitRelate_Store.CodiceUnita = codiceUnita;
			unitRelate_Store.CodiceOperatore = codiceOperatore;
			unitRelate_Store.CodiceIVAAcquisti = codiceIVAAcquisti;
			unitRelate_Store.CodiceIVAVendite = codiceIVAVendite;
			unitRelate_Store.CodiceIVACorrispettivi = codiceIVACorrispettivi;
			#endregion
			
			unitRelate_Store.Execute(cn);
			
			#region Get Property Values
			
			#endregion
		}
		#endregion
	}
	#endregion

	#region UnitRelate_Delete Wrapper
	/// <summary>
	/// This class is a wrapper for the UnitRelate_Delete stored procedure.
	/// </summary>
	internal class UnitRelate_Delete
	{
		#region Member Variables
		protected int _recordsAffected = -1;
		protected int _returnValue = 0;
		protected SqlString _codiceUnita = SqlString.Null;
		protected bool _codiceUnitaSet = false;
		protected SqlString _codiceOperatore = SqlString.Null;
		protected bool _codiceOperatoreSet = false;
		#endregion
		
		#region Constructors
		public UnitRelate_Delete()
		{
		}
		#endregion
		
		#region Public Properties
		/// <summary>
		/// Gets the return value from the UnitRelate_Delete stored procedure.
		/// </summary>
		public int ReturnValue
		{
			get {return _returnValue;}
		}
		
		/// <summary>
		/// Gets the number of rows changed, inserted, or deleted by execution of the UnitRelate_Delete stored procedure.
		/// </summary>
		public int RecordsAffected
		{
			get {return _recordsAffected;}
		}
		
		public SqlString CodiceUnita
		{
			get {return _codiceUnita;}
			set
			{
				_codiceUnita = value;
				_codiceUnitaSet = true;
			}
		}

		public SqlString CodiceOperatore
		{
			get {return _codiceOperatore;}
			set
			{
				_codiceOperatore = value;
				_codiceOperatoreSet = true;
			}
		}
		#endregion
		
		#region Execute Methods
		/// <summary>
		/// This method calls the UnitRelate_Delete stored procedure.
		/// </summary>
		public virtual void Execute(SqlConnection cn)
		{
			SqlCommand cmd = cn.CreateCommand();
			
			try
			{
				cmd.CommandText = "[dbo].[UnitRelate_Delete]";
				cmd.CommandType = CommandType.StoredProcedure;
				
				#region Populate Parameters
				SqlParameter prmReturnValue = cmd.Parameters.Add("@RETURN_VALUE", SqlDbType.Int);
				prmReturnValue.Direction = ParameterDirection.ReturnValue;
				
				SqlParameter prmCodiceUnita = cmd.Parameters.Add("@CodiceUnita", SqlDbType.VarChar);
				prmCodiceUnita.Direction = ParameterDirection.Input;
				prmCodiceUnita.Size = 16;
				if (_codiceUnitaSet == true || this.CodiceUnita.IsNull == false)
				{
					prmCodiceUnita.Value = this.CodiceUnita;
				}
				
				SqlParameter prmCodiceOperatore = cmd.Parameters.Add("@CodiceOperatore", SqlDbType.VarChar);
				prmCodiceOperatore.Direction = ParameterDirection.Input;
				prmCodiceOperatore.Size = 16;
				if (_codiceOperatoreSet == true || this.CodiceOperatore.IsNull == false)
				{
					prmCodiceOperatore.Value = this.CodiceOperatore;
				}
				#endregion
				
				#region Execute Command
				_recordsAffected = cmd.ExecuteNonQuery();
				#endregion
				
				#region Get Output Parameters
				if (prmReturnValue.Value != null && prmReturnValue.Value != DBNull.Value)
				{
					_returnValue = (int)prmReturnValue.Value;
				}
				
				#endregion
			}
			finally
			{
				cmd.Dispose();
			}
		}
		
		/// <summary>
		/// This method calls the UnitRelate_Delete stored procedure.
		/// </summary>
		/// <param name="cn">La connessione da usare</param>
		/// <param name="codiceUnita"></param>
		/// <param name="codiceOperatore"></param>
		public static void Execute(
			#region Parameters
			SqlConnection cn,
			SqlString codiceUnita,
			SqlString codiceOperatore
			#endregion
			)
		{
			UnitRelate_Delete unitRelate_Delete = new UnitRelate_Delete();
			
			#region Assign Property Values
			unitRelate_Delete.CodiceUnita = codiceUnita;
			unitRelate_Delete.CodiceOperatore = codiceOperatore;
			#endregion
			
			unitRelate_Delete.Execute(cn);
			
			#region Get Property Values
			
			#endregion
		}
		#endregion
	}
	#endregion

}
