using System;
using System.Data;
using System.Data.SqlTypes;
using System.Data.SqlClient;
using System.Xml;
using System.Xml.Serialization;

using MeRT_BL.Messaging.BidSubmittalMA1Types;
using Messaging;
using PIPEDoc;

namespace MeRT_BL.Messaging
{
	public class BidSubmittalMA1Facade : TransactionFacade
	{
		public BidSubmittalMA1Facade(PIPTransaction tr)	: base(tr, PIPTransactionAttributes.All) {}

		public override string FA_MarketParticipantNumber
		{
			get
			{
				if (_element == null)
					return string.Empty;
				return _element.MarketParticipantNumber;
			}
		}

		public override string FA_TransactionType
		{
			get { return "FA"; }
		}

		public override void Read(XmlReader xr)
		{
			_element = (BidSubmittalMA1) _serializer.Deserialize(xr);
		}

		public override void Write(XmlWriter xw)
		{
			if (_element == null)
				return;

			WriteStartPIP(xw);
			_serializer.Serialize(xw, _element);
			WriteEndPIP(xw);
		}
		private static bool YesNoTypeToBoolean(yesNoType type)
		{
			if (yesNoType.Yes == type)
				return true;

			return false;
		}
		public override void Execute(object executeState)
		{
			if (this.Valid == false)
				return;
			SqlConnection cn = executeState as SqlConnection;
			if (cn == null)// TODO
				return;

			try
			{
				double offerta = SimpleType.LocaleDecimalToDouble(_element.BidQuantity.Value);
				if (purposeTradeType.Sell == _element.Purpose)
					offerta = offerta - offerta - offerta;

				// TODO <attribute name="ReplacementIndicator" type="pd:yesNoType" use="required"/>

				Offerte_Store.Execute(cn
					, SimpleType.DateTypeToDateTime(_element.Date)
					, SimpleType.HourIntervalTypeToByte(_element.Hour)
					, _element.Market.ToString()
					, "IDGRTN" //TODO TradingPartner
					, _element.UnitReferenceNumber
					, Guid.NewGuid().ToString("N") //TODO
					, offerta
					, SimpleType.LocaleDecimalToDouble(_element.EnergyPrice)
					, _element.MarketParticipantNumber //TODO null
					, false);
			}
			catch (Exception e)
			{
				this.SetError(MessagingError.E0.ToString(), e.Message);
			}
		}

		private static XmlSerializer _serializer =
			new XmlSerializer(typeof(BidSubmittalMA1));
		private BidSubmittalMA1 _element = null;
	}
	#region Offerte_Store Wrapper
	/// <summary>
	/// This class is a wrapper for the Offerte_Store stored procedure.
	/// </summary>
	internal class Offerte_Store
	{
		#region Member Variables
		protected int _recordsAffected = -1;
		protected int _returnValue = 0;
		protected SqlDateTime _flowDate = SqlDateTime.Null;
		protected bool _flowDateSet = false;
		protected SqlByte _ora = SqlByte.Null;
		protected bool _oraSet = false;
		protected SqlString _codiceMercato = SqlString.Null;
		protected bool _codiceMercatoSet = false;
		protected SqlString _codiceOperatore = SqlString.Null;
		protected bool _codiceOperatoreSet = false;
		protected SqlString _codiceUnita = SqlString.Null;
		protected bool _codiceUnitaSet = false;
		protected SqlString _codiceGME = SqlString.Null;
		protected bool _codiceGMESet = false;
		protected SqlDouble _quantitaOffertaMWh = SqlDouble.Null;
		protected bool _quantitaOffertaMWhSet = false;
		protected SqlDouble _prezzoOfferta = SqlDouble.Null;
		protected bool _prezzoOffertaSet = false;
		protected SqlString _marketParticipantNumber = SqlString.Null;
		protected bool _marketParticipantNumberSet = false;
		protected SqlBoolean _daPredefinita = SqlBoolean.Null;
		protected bool _daPredefinitaSet = false;
		#endregion
		
		#region Constructors
		public Offerte_Store()
		{
		}
		#endregion
		
		#region Public Properties
		/// <summary>
		/// Gets the return value from the Offerte_Store stored procedure.
		/// </summary>
		public int ReturnValue
		{
			get {return _returnValue;}
		}
		
		/// <summary>
		/// Gets the number of rows changed, inserted, or deleted by execution of the Offerte_Store stored procedure.
		/// </summary>
		public int RecordsAffected
		{
			get {return _recordsAffected;}
		}
		
		public SqlDateTime FlowDate
		{
			get {return _flowDate;}
			set
			{
				_flowDate = value;
				_flowDateSet = true;
			}
		}

		public SqlByte Ora
		{
			get {return _ora;}
			set
			{
				_ora = value;
				_oraSet = true;
			}
		}

		public SqlString CodiceMercato
		{
			get {return _codiceMercato;}
			set
			{
				_codiceMercato = value;
				_codiceMercatoSet = true;
			}
		}

		public SqlString CodiceOperatore
		{
			get {return _codiceOperatore;}
			set
			{
				_codiceOperatore = value;
				_codiceOperatoreSet = true;
			}
		}

		public SqlString CodiceUnita
		{
			get {return _codiceUnita;}
			set
			{
				_codiceUnita = value;
				_codiceUnitaSet = true;
			}
		}

		public SqlString CodiceGME
		{
			get {return _codiceGME;}
			set
			{
				_codiceGME = value;
				_codiceGMESet = true;
			}
		}

		public SqlDouble QuantitaOffertaMWh
		{
			get {return _quantitaOffertaMWh;}
			set
			{
				_quantitaOffertaMWh = value;
				_quantitaOffertaMWhSet = true;
			}
		}

		public SqlDouble PrezzoOfferta
		{
			get {return _prezzoOfferta;}
			set
			{
				_prezzoOfferta = value;
				_prezzoOffertaSet = true;
			}
		}

		public SqlString MarketParticipantNumber
		{
			get {return _marketParticipantNumber;}
			set
			{
				_marketParticipantNumber = value;
				_marketParticipantNumberSet = true;
			}
		}

		public SqlBoolean DaPredefinita
		{
			get {return _daPredefinita;}
			set
			{
				_daPredefinita = value;
				_daPredefinitaSet = true;
			}
		}
		#endregion
		
		#region Execute Methods
		/// <summary>
		/// This method calls the Offerte_Store stored procedure.
		/// </summary>
		public virtual void Execute(SqlConnection cn)
		{
			SqlCommand cmd = cn.CreateCommand();
			
			try
			{
				cmd.CommandText = "[dbo].[Offerte_Store]";
				cmd.CommandType = CommandType.StoredProcedure;
				
				#region Populate Parameters
				SqlParameter prmReturnValue = cmd.Parameters.Add("@RETURN_VALUE", SqlDbType.Int);
				prmReturnValue.Direction = ParameterDirection.ReturnValue;
				
				SqlParameter prmFlowDate = cmd.Parameters.Add("@FlowDate", SqlDbType.SmallDateTime);
				prmFlowDate.Direction = ParameterDirection.Input;
				if (_flowDateSet == true || this.FlowDate.IsNull == false)
				{
					prmFlowDate.Value = this.FlowDate;
				}
				
				SqlParameter prmOra = cmd.Parameters.Add("@Ora", SqlDbType.TinyInt);
				prmOra.Direction = ParameterDirection.Input;
				if (_oraSet == true || this.Ora.IsNull == false)
				{
					prmOra.Value = this.Ora;
				}
				
				SqlParameter prmCodiceMercato = cmd.Parameters.Add("@CodiceMercato", SqlDbType.VarChar);
				prmCodiceMercato.Direction = ParameterDirection.Input;
				prmCodiceMercato.Size = 4;
				if (_codiceMercatoSet == true || this.CodiceMercato.IsNull == false)
				{
					prmCodiceMercato.Value = this.CodiceMercato;
				}
				
				SqlParameter prmCodiceOperatore = cmd.Parameters.Add("@CodiceOperatore", SqlDbType.VarChar);
				prmCodiceOperatore.Direction = ParameterDirection.Input;
				prmCodiceOperatore.Size = 16;
				if (_codiceOperatoreSet == true || this.CodiceOperatore.IsNull == false)
				{
					prmCodiceOperatore.Value = this.CodiceOperatore;
				}
				
				SqlParameter prmCodiceUnita = cmd.Parameters.Add("@CodiceUnita", SqlDbType.VarChar);
				prmCodiceUnita.Direction = ParameterDirection.Input;
				prmCodiceUnita.Size = 16;
				if (_codiceUnitaSet == true || this.CodiceUnita.IsNull == false)
				{
					prmCodiceUnita.Value = this.CodiceUnita;
				}
				
				SqlParameter prmCodiceGME = cmd.Parameters.Add("@CodiceGME", SqlDbType.VarChar);
				prmCodiceGME.Direction = ParameterDirection.Input;
				prmCodiceGME.Size = 32;
				if (_codiceGMESet == true || this.CodiceGME.IsNull == false)
				{
					prmCodiceGME.Value = this.CodiceGME;
				}
				
				SqlParameter prmQuantitaOffertaMWh = cmd.Parameters.Add("@QuantitaOffertaMWh", SqlDbType.Float);
				prmQuantitaOffertaMWh.Direction = ParameterDirection.Input;
				prmQuantitaOffertaMWh.Precision = 15;
				prmQuantitaOffertaMWh.Scale = 0;
				if (_quantitaOffertaMWhSet == true || this.QuantitaOffertaMWh.IsNull == false)
				{
					prmQuantitaOffertaMWh.Value = this.QuantitaOffertaMWh;
				}
				
				SqlParameter prmPrezzoOfferta = cmd.Parameters.Add("@PrezzoOfferta", SqlDbType.Float);
				prmPrezzoOfferta.Direction = ParameterDirection.Input;
				prmPrezzoOfferta.Precision = 15;
				prmPrezzoOfferta.Scale = 0;
				if (_prezzoOffertaSet == true || this.PrezzoOfferta.IsNull == false)
				{
					prmPrezzoOfferta.Value = this.PrezzoOfferta;
				}
				
				SqlParameter prmMarketParticipantNumber = cmd.Parameters.Add("@MarketParticipantNumber", SqlDbType.VarChar);
				prmMarketParticipantNumber.Direction = ParameterDirection.Input;
				prmMarketParticipantNumber.Size = 30;
				if (_marketParticipantNumberSet == true || this.MarketParticipantNumber.IsNull == false)
				{
					prmMarketParticipantNumber.Value = this.MarketParticipantNumber;
				}
				
				SqlParameter prmDaPredefinita = cmd.Parameters.Add("@DaPredefinita", SqlDbType.Bit);
				prmDaPredefinita.Direction = ParameterDirection.Input;
				if (_daPredefinitaSet == true || this.DaPredefinita.IsNull == false)
				{
					prmDaPredefinita.Value = this.DaPredefinita;
				}
				#endregion
				
				#region Execute Command
				_recordsAffected = cmd.ExecuteNonQuery();
				#endregion
				
				#region Get Output Parameters
				if (prmReturnValue.Value != null && prmReturnValue.Value != DBNull.Value)
				{
					_returnValue = (int)prmReturnValue.Value;
				}
				
				#endregion
			}
			finally
			{
				cmd.Dispose();
			}
		}
		
		/// <summary>
		/// This method calls the Offerte_Store stored procedure.
		/// </summary>
		/// <param name="cn">La connessione da usare</param>
		/// <param name="flowDate"></param>
		/// <param name="ora"></param>
		/// <param name="codiceMercato"></param>
		/// <param name="codiceOperatore"></param>
		/// <param name="codiceUnita"></param>
		/// <param name="codiceGME"></param>
		/// <param name="quantitaOffertaMWh"></param>
		/// <param name="prezzoOfferta"></param>
		/// <param name="marketParticipantNumber"></param>
		/// <param name="daPredefinita"></param>
		public static void Execute(
			#region Parameters
			SqlConnection cn,
			SqlDateTime flowDate,
			SqlByte ora,
			SqlString codiceMercato,
			SqlString codiceOperatore,
			SqlString codiceUnita,
			SqlString codiceGME,
			SqlDouble quantitaOffertaMWh,
			SqlDouble prezzoOfferta,
			SqlString marketParticipantNumber,
			SqlBoolean daPredefinita
			#endregion
			)
		{
			Offerte_Store offerte_Store = new Offerte_Store();
			
			#region Assign Property Values
			offerte_Store.FlowDate = flowDate;
			offerte_Store.Ora = ora;
			offerte_Store.CodiceMercato = codiceMercato;
			offerte_Store.CodiceOperatore = codiceOperatore;
			offerte_Store.CodiceUnita = codiceUnita;
			offerte_Store.CodiceGME = codiceGME;
			offerte_Store.QuantitaOffertaMWh = quantitaOffertaMWh;
			offerte_Store.PrezzoOfferta = prezzoOfferta;
			offerte_Store.MarketParticipantNumber = marketParticipantNumber;
			offerte_Store.DaPredefinita = daPredefinita;
			#endregion
			
			offerte_Store.Execute(cn);
			
			#region Get Property Values
			
			#endregion
		}
		#endregion
	}
	#endregion
}
