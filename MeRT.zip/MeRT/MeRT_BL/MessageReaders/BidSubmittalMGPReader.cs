using System;
using System.Data;
using System.Data.SqlTypes;
using System.Data.SqlClient;
using System.Xml;
using System.Xml.Serialization;

using MeRT_BL.Messaging.BidSubmittalMGPTypes;
using Messaging;
using PIPEDoc;

namespace MeRT_BL.Messaging
{
	public class BidSubmittalMGPFacade : TransactionFacade
	{
		public BidSubmittalMGPFacade(PIPTransaction tr)	: base(tr, PIPTransactionAttributes.All) {}

		public override string FA_MarketParticipantNumber
		{
			get
			{
				if (_element == null)
					return string.Empty;
				return _element.MarketParticipantNumber;
			}
		}

		public override string FA_TransactionType
		{
			get { return "FA"; }
		}

		public override void Read(XmlReader xr)
		{
			_element = (BidSubmittalMGP) _serializer.Deserialize(xr);
		}

		public override void Write(XmlWriter xw)
		{
			if (_element == null)
				return;

			WriteStartPIP(xw);
			_serializer.Serialize(xw, _element);
			WriteEndPIP(xw);
		}
		private static bool YesNoTypeToBoolean(yesNoType type)
		{
			if (yesNoType.Yes == type)
				return true;

			return false;
		}
		public override void Execute(object executeState)
		{
			if (this.Valid == false)
				return;
			SqlConnection cn = executeState as SqlConnection;
			if (cn == null)// TODO
				return;

			try
			{
				double offerta = SimpleType.LocaleDecimalToDouble(_element.BidQuantity.Value);
				if (purposeTradeType.Sell == _element.Purpose)
					offerta = offerta - offerta - offerta;

				Offerte_Store.Execute(cn
					, SimpleType.DateTypeToDateTime(_element.Date)
					, SimpleType.HourIntervalTypeToByte(_element.Hour)
					, _element.Market.ToString()
					, "IDGRTN" //TODO TradingPartner
					, _element.UnitReferenceNumber
					, Guid.NewGuid().ToString("N")//TODO
					, offerta
					, SimpleType.LocaleDecimalToDouble(_element.EnergyPrice)
					, _element.MarketParticipantNumber //TODO null
					, YesNoTypeToBoolean(_element.PredefinedOffer)
					);
			}
			catch (Exception e)
			{
				this.SetError(MessagingError.E0.ToString(), e.Message);
			}
		}


		private static XmlSerializer _serializer =
			new XmlSerializer(typeof(BidSubmittalMGP));
		private BidSubmittalMGP _element = null;
	}
}
