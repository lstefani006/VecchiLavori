using System;
using System.Data;
using System.Data.SqlTypes;
using System.Data.SqlClient;
using System.Xml;
using System.Xml.Serialization;

using MeRT_BL.Messaging.EstimatedDemandInformationTypes;
using Messaging;
using PIPEDoc;

namespace MeRT_BL.Messaging
{
	public class EstimatedDemandInformationFacade : TransactionFacade
	{
		public EstimatedDemandInformationFacade(PIPTransaction tr)
			: base(tr, PIPTransactionAttributes.ReferenceNumber){}

		public override string FA_MarketParticipantNumber
		{
			get { return PIPTransaction.ReferenceNumber; }
		}

		public override string FA_TransactionType
		{
			get { return "FA"; }
		}

		public override void Read(XmlReader xr)
		{
			_element = (EstimatedDemandInformation) _serializer.Deserialize(xr);
		}

		public override void Write(XmlWriter xw)
		{
			if (_element == null)
				return;

			base.WriteStartPIP(xw);
			_serializer.Serialize(xw, _element);
			base.WriteEndPIP(xw);
		}
		public override void Execute(object executeState)
		{
			if (this.Valid == false)
				return;
			SqlConnection cn = executeState as SqlConnection;
			if (cn == null)// TODO
				return;

			try
			{
				DateTime flowDate = SimpleType.DateTypeToDateTime(_element.Date);
				foreach (EstimatedDemandInformationZoneDetail zona in _element.ZoneDetail)
				{
					string codiceZona = zona.Zone.ToString();
					foreach (EstimatedDemand demand in zona.EstimatedDemand)
					{
						IP_Fabbisogno_Store.Execute(cn
							, flowDate
							, SimpleType.HourIntervalTypeToByte(demand.Hour)
							, codiceZona
							, SimpleType.LocaleDecimalToDouble(demand.Value)
						);
					}
				}
			}
			catch (Exception e)
			{
				this.SetError(MessagingError.E0.ToString(), e.Message);
			}
		}

		private static XmlSerializer _serializer =
			new XmlSerializer(typeof(EstimatedDemandInformation));
		private EstimatedDemandInformation _element;
	}
	#region IP_Fabbisogno_Store Wrapper
	/// <summary>
	/// This class is a wrapper for the IP_Fabbisogno_Store stored procedure.
	/// </summary>
	internal class IP_Fabbisogno_Store
	{
		#region Member Variables
		protected int _recordsAffected = -1;
		protected int _returnValue = 0;
		protected SqlDateTime _flowDate = SqlDateTime.Null;
		protected bool _flowDateSet = false;
		protected SqlByte _ora = SqlByte.Null;
		protected bool _oraSet = false;
		protected SqlString _codiceZona = SqlString.Null;
		protected bool _codiceZonaSet = false;
		protected SqlDouble _quantitaMWh = SqlDouble.Null;
		protected bool _quantitaMWhSet = false;
		#endregion
		
		#region Constructors
		public IP_Fabbisogno_Store()
		{
		}
		#endregion
		
		#region Public Properties
		/// <summary>
		/// Gets the return value from the IP_Fabbisogno_Store stored procedure.
		/// </summary>
		public int ReturnValue
		{
			get {return _returnValue;}
		}
		
		/// <summary>
		/// Gets the number of rows changed, inserted, or deleted by execution of the IP_Fabbisogno_Store stored procedure.
		/// </summary>
		public int RecordsAffected
		{
			get {return _recordsAffected;}
		}
		
		public SqlDateTime FlowDate
		{
			get {return _flowDate;}
			set
			{
				_flowDate = value;
				_flowDateSet = true;
			}
		}

		public SqlByte Ora
		{
			get {return _ora;}
			set
			{
				_ora = value;
				_oraSet = true;
			}
		}

		public SqlString CodiceZona
		{
			get {return _codiceZona;}
			set
			{
				_codiceZona = value;
				_codiceZonaSet = true;
			}
		}

		public SqlDouble QuantitaMWh
		{
			get {return _quantitaMWh;}
			set
			{
				_quantitaMWh = value;
				_quantitaMWhSet = true;
			}
		}
		#endregion
		
		#region Execute Methods
		/// <summary>
		/// This method calls the IP_Fabbisogno_Store stored procedure.
		/// </summary>
		public virtual void Execute(SqlConnection cn)
		{
			SqlCommand cmd = cn.CreateCommand();
			
			try
			{
				cmd.CommandText = "[dbo].[IP_Fabbisogno_Store]";
				cmd.CommandType = CommandType.StoredProcedure;
				
				#region Populate Parameters
				SqlParameter prmReturnValue = cmd.Parameters.Add("@RETURN_VALUE", SqlDbType.Int);
				prmReturnValue.Direction = ParameterDirection.ReturnValue;
				
				SqlParameter prmFlowDate = cmd.Parameters.Add("@FlowDate", SqlDbType.SmallDateTime);
				prmFlowDate.Direction = ParameterDirection.Input;
				if (_flowDateSet == true || this.FlowDate.IsNull == false)
				{
					prmFlowDate.Value = this.FlowDate;
				}
				
				SqlParameter prmOra = cmd.Parameters.Add("@Ora", SqlDbType.TinyInt);
				prmOra.Direction = ParameterDirection.Input;
				if (_oraSet == true || this.Ora.IsNull == false)
				{
					prmOra.Value = this.Ora;
				}
				
				SqlParameter prmCodiceZona = cmd.Parameters.Add("@CodiceZona", SqlDbType.VarChar);
				prmCodiceZona.Direction = ParameterDirection.Input;
				prmCodiceZona.Size = 4;
				if (_codiceZonaSet == true || this.CodiceZona.IsNull == false)
				{
					prmCodiceZona.Value = this.CodiceZona;
				}
				
				SqlParameter prmQuantitaMWh = cmd.Parameters.Add("@QuantitaMWh", SqlDbType.Float);
				prmQuantitaMWh.Direction = ParameterDirection.Input;
				prmQuantitaMWh.Precision = 15;
				prmQuantitaMWh.Scale = 0;
				if (_quantitaMWhSet == true || this.QuantitaMWh.IsNull == false)
				{
					prmQuantitaMWh.Value = this.QuantitaMWh;
				}
				#endregion
				
				#region Execute Command
				_recordsAffected = cmd.ExecuteNonQuery();
				#endregion
				
				#region Get Output Parameters
				if (prmReturnValue.Value != null && prmReturnValue.Value != DBNull.Value)
				{
					_returnValue = (int)prmReturnValue.Value;
				}
				
				#endregion
			}
			finally
			{
				cmd.Dispose();
			}
		}
		
		/// <summary>
		/// This method calls the IP_Fabbisogno_Store stored procedure.
		/// </summary>
		/// <param name="cn">La connessione da usare</param>
		/// <param name="flowDate"></param>
		/// <param name="ora"></param>
		/// <param name="codiceZona"></param>
		/// <param name="quantitaMWh"></param>
		public static void Execute(
			#region Parameters
			SqlConnection cn,
			SqlDateTime flowDate,
			SqlByte ora,
			SqlString codiceZona,
			SqlDouble quantitaMWh
			#endregion
			)
		{
			IP_Fabbisogno_Store iP_Fabbisogno_Store = new IP_Fabbisogno_Store();
			
			#region Assign Property Values
			iP_Fabbisogno_Store.FlowDate = flowDate;
			iP_Fabbisogno_Store.Ora = ora;
			iP_Fabbisogno_Store.CodiceZona = codiceZona;
			iP_Fabbisogno_Store.QuantitaMWh = quantitaMWh;
			#endregion
			
			iP_Fabbisogno_Store.Execute(cn);
			
			#region Get Property Values
			
			#endregion
		}
		#endregion
	}
	#endregion
}
