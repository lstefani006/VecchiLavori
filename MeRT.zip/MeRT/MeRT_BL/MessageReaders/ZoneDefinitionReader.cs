using System;
using System.Data;
using System.Data.SqlTypes;
using System.Data.SqlClient;
using System.Xml;
using System.Xml.Serialization;

using MeRT_BL.Messaging.ZoneDefinitionTypes;
using Messaging;
using PIPEDoc;

namespace MeRT_BL.Messaging
{
	public class ZoneDefinitionFacade : TransactionFacade
	{
		public ZoneDefinitionFacade(PIPTransaction tr)
			: base(tr, PIPTransactionAttributes.ReferenceNumber){}

		public override string FA_MarketParticipantNumber
		{
			get
			{
				return PIPTransaction.ReferenceNumber;
			}
		}

		public override string FA_TransactionType
		{
			get { return "FA"; }
		}

		public override void Read(XmlReader xr)
		{
			_element = (ZoneDefinition) _serializer.Deserialize(xr);
		}

		public override void Write(XmlWriter xw)
		{
			if (_element == null)
				return;

			WriteStartPIP(xw);
			_serializer.Serialize(xw, _element);
			WriteEndPIP(xw);
		}
		public override void Execute(object executeState)
		{
			if (this.Valid == false)
				return;
			SqlConnection cn = executeState as SqlConnection;
			if (cn == null)// TODO
				return;

			try
			{
				Zone_Store.Execute(cn
					, _element.ZoneCD.ToString()
					, _element.TypeCD.ToString()
					, _element.Value);
			}
			catch (Exception e)
			{
				this.SetError(MessagingError.E0.ToString(), e.Message);
			}
		}

		private static XmlSerializer _serializer =
			new XmlSerializer(typeof(ZoneDefinition));
		private ZoneDefinition _element = null;
	}

	#region Zone_Store Wrapper
	/// <summary>
	/// This class is a wrapper for the Zone_Store stored procedure.
	/// </summary>
	internal class Zone_Store
	{
		#region Member Variables
		protected int _recordsAffected = -1;
		protected int _returnValue = 0;
		protected SqlString _codiceZona = SqlString.Null;
		protected bool _codiceZonaSet = false;
		protected SqlString _tipoZona = SqlString.Null;
		protected bool _tipoZonaSet = false;
		protected SqlString _descrizione = SqlString.Null;
		protected bool _descrizioneSet = false;
		#endregion
		
		#region Constructors
		public Zone_Store()
		{
		}
		#endregion
		
		#region Public Properties
		/// <summary>
		/// Gets the return value from the Zone_Store stored procedure.
		/// </summary>
		public int ReturnValue
		{
			get {return _returnValue;}
		}
		
		/// <summary>
		/// Gets the number of rows changed, inserted, or deleted by execution of the Zone_Store stored procedure.
		/// </summary>
		public int RecordsAffected
		{
			get {return _recordsAffected;}
		}
		
		public SqlString CodiceZona
		{
			get {return _codiceZona;}
			set
			{
				_codiceZona = value;
				_codiceZonaSet = true;
			}
		}

		public SqlString TipoZona
		{
			get {return _tipoZona;}
			set
			{
				_tipoZona = value;
				_tipoZonaSet = true;
			}
		}

		public SqlString Descrizione
		{
			get {return _descrizione;}
			set
			{
				_descrizione = value;
				_descrizioneSet = true;
			}
		}
		#endregion
		
		#region Execute Methods
		/// <summary>
		/// This method calls the Zone_Store stored procedure.
		/// </summary>
		public virtual void Execute(SqlConnection cn)
		{
			SqlCommand cmd = cn.CreateCommand();
			
			try
			{
				cmd.CommandText = "[dbo].[Zone_Store]";
				cmd.CommandType = CommandType.StoredProcedure;
				
				#region Populate Parameters
				SqlParameter prmReturnValue = cmd.Parameters.Add("@RETURN_VALUE", SqlDbType.Int);
				prmReturnValue.Direction = ParameterDirection.ReturnValue;
				
				SqlParameter prmCodiceZona = cmd.Parameters.Add("@CodiceZona", SqlDbType.VarChar);
				prmCodiceZona.Direction = ParameterDirection.Input;
				prmCodiceZona.Size = 4;
				if (_codiceZonaSet == true || this.CodiceZona.IsNull == false)
				{
					prmCodiceZona.Value = this.CodiceZona;
				}
				
				SqlParameter prmTipoZona = cmd.Parameters.Add("@TipoZona", SqlDbType.VarChar);
				prmTipoZona.Direction = ParameterDirection.Input;
				prmTipoZona.Size = 4;
				if (_tipoZonaSet == true || this.TipoZona.IsNull == false)
				{
					prmTipoZona.Value = this.TipoZona;
				}
				
				SqlParameter prmDescrizione = cmd.Parameters.Add("@Descrizione", SqlDbType.NVarChar);
				prmDescrizione.Direction = ParameterDirection.Input;
				prmDescrizione.Size = 60;
				if (_descrizioneSet == true || this.Descrizione.IsNull == false)
				{
					prmDescrizione.Value = this.Descrizione;
				}
				#endregion
				
				#region Execute Command
				_recordsAffected = cmd.ExecuteNonQuery();
				#endregion
				
				#region Get Output Parameters
				if (prmReturnValue.Value != null && prmReturnValue.Value != DBNull.Value)
				{
					_returnValue = (int)prmReturnValue.Value;
				}
				
				#endregion
			}
			finally
			{
				cmd.Dispose();
			}
		}
		
		/// <summary>
		/// This method calls the Zone_Store stored procedure.
		/// </summary>
		/// <param name="cn">La connessione da usare</param>
		/// <param name="codiceZona"></param>
		/// <param name="tipoZona"></param>
		/// <param name="descrizione"></param>
		public static void Execute(
			#region Parameters
			SqlConnection cn,
			SqlString codiceZona,
			SqlString tipoZona,
			SqlString descrizione
			#endregion
			)
		{
			Zone_Store zone_Store = new Zone_Store();
			
			#region Assign Property Values
			zone_Store.CodiceZona = codiceZona;
			zone_Store.TipoZona = tipoZona;
			zone_Store.Descrizione = descrizione;
			#endregion
			
			zone_Store.Execute(cn);
			
			#region Get Property Values
			
			#endregion
		}
		#endregion
	}
	#endregion
}
