using System;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Threading;
using System.Xml;
using System.Xml.Serialization;
using GME;
using GME.BL;
using GME.Utility;
using GME.Web;
using GME.Zip;
using MeRT_Algo;
using MeRT_IBL;

namespace MeRT_BL
{
	/// <summary>
	/// Summary description for AlgoRis.
	/// </summary>
	[RemotableServer]
	public class AlgoRis : BLBase, IAlgoRis
	{
		#region Costruttori

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private Container components = null;

		private SqlConnection cn;

		public AlgoRis(IContainer container)
		{
			container.Add(this);
			InitializeComponent();

			cn = new SqlConnection();
			cn.ConnectionString = BLBase.SqlConnectionstring;

		}

		public AlgoRis()
		{
			InitializeComponent();

			cn = new SqlConnection();
			cn.ConnectionString = BLBase.SqlConnectionstring;

		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose(bool disposing)
		{
			if (disposing)
			{
				if (components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}

		#region Component Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
		}

		#endregion

		#endregion

		/*
		 * 
		StatoEsecuzioneOra
		
		RUN --> ERR
		    --> HBMR --> ERR
			         --> PROV --> COMP
			
		RUN    sta girando l'ora per quel mercato/data flusso.
		ERR    in errore per qualche motivo
		HBMR   l'algortimo ha il risultato. MP lo deve contemplare
		PROV   MP accetta il risultato
		COMP   il risultato PROV diventa definitivo.		 
		
		*/


		private static Thread _thPoll = null;

		public virtual void PollAndConsumeAlgoRis()
		{
			if (_thPoll != null)
			{
				_thPoll.Abort();
				_thPoll = null;
			}

			ThreadStart ts = new ThreadStart(PollAndConsumeAlgoThread);
			_thPoll = new Thread(ts);
			_thPoll.IsBackground = true;
			_thPoll.Start();
		}

		protected virtual void PollAndConsumeAlgoThread()
		{
			for (;; )
			{
				int nSec = AppSettings.ToInt32("PollAndConsumeAlgo_Period", 10);
				if (nSec <= 0)
				{
					Thread.Sleep(10 * 1000);
				}
				else
				{
					Thread.Sleep(nSec*1000);
					AlgoRis p = new AlgoRis();
					p.CheckEsecuzioneCompletata();
				}
			}
		}


		public class AlgoRis_ListaEsecuzioni
		{
			public DateTime FlowDate;
			public byte Ora;
			public string CodiceMercato;
			public int ProgressivoEsecuzione;
			public string IdElaborazione;

			public StatoEsecuzioneOra StatoEsecuzioneOra;
			public DateTime DataOraInizioEsecuzioneOra;
			public DateTime DataOraFineEsecuzioneOra;
		}

		protected virtual bool CheckEsecuzioneCompletata()
		{
			try
			{
				// devo sapere quali elaborazioni sono in RUN
				AlgoRis_ListaEsecuzioni[] ese;

				cn.Open();

				// cerco le esecuzioni in RUN/HBMR
				if (true)
				{
					SqlCommand cmd = cn.CreateCommand();
					cmd.CommandText = "AlgoRis_ListaEsecuzioni_RUN_HBMR";
					cmd.CommandType = CommandType.StoredProcedure;
					cmd.CommandTimeout = AppSettings.ToInt32("AlgoRis_ListaEsecuzioni_RUN_HBMR_Timeout", 30);

					using (SqlDataReader rd = cmd.ExecuteReader())
					{
						ClassReader crd = new ClassReader(typeof (AlgoRis_ListaEsecuzioni), rd);
						ese = (AlgoRis_ListaEsecuzioni[]) crd.Read();
					}
				}
				cn.Close();

				// qui ho la lista delle elaborazioni in corso

				bool risultatoElaborato = false;

				Algo ws = new Algo();
				WSClient.Setup(ws, "MeRT_Algo");

				foreach (AlgoRis_ListaEsecuzioni es in ese)
				{
					if (es.StatoEsecuzioneOra == StatoEsecuzioneOra.RUN)
					{
						bool b = ws.ElaborazioneCompletata(es.IdElaborazione);
						if (b)
						{
							DatiElaborazione ri = ws.RisultatiElaborazione(es.IdElaborazione);

							byte[] bmsZip = CreaBlobRisultatiAlgo(ri, es);

							// porta avanti anche lo stato
							// da RUN a HBMR/ERR
							// (lo stato lo decide dal ri.statoElaborazione )
							cn.Open();
							StoreBlobRisAlgo(cn, es, bmsZip, ri.statoElaborazione);
							cn.Close();

							risultatoElaborato = true;
						}
					}
					else if (es.StatoEsecuzioneOra == StatoEsecuzioneOra.HBMR)
					{
						int minuti = AppSettings.ToInt32("AlgoRis_HBMR_MinTimeout", 30);

						if (minuti > 0 && es.DataOraFineEsecuzioneOra.AddMinutes(minuti) >= DateTime.Now)
						{
							// qui vado da HBMR a PROV automaticamente dopo 30 minuti
							cn.Open();
							RendiProvRisultatoInternal(cn, es.FlowDate, es.Ora, es.CodiceMercato, es.ProgressivoEsecuzione);
							cn.Close();
						}
					}
				}

				return risultatoElaborato;
			}
			catch (Exception e)
			{
				smError(e);
				throw;
			}
			finally
			{
				cn.Dispose();
			}
		}


		private static void StoreBlobRisAlgo(SqlConnection cn, AlgoRis_ListaEsecuzioni es, byte[] bmsZip, StatoElaborazione statoElaborazione)
		{
			SqlCommand cmd = cn.CreateCommand();
			cmd.CommandText = "AlgoRis_StoreBlobRisAlgo";
			cmd.CommandType = CommandType.StoredProcedure;
			cmd.CommandTimeout = AppSettings.ToInt32("AlgoRis_StoreBlobRisAlgo_Timeout", 30);
			cmd.Parameters.Add(new SqlParameter("@RETURN_VALUE", SqlDbType.Int, 4, ParameterDirection.ReturnValue, false, 0, 0, "", DataRowVersion.Current, null));
			cmd.Parameters.Add(new SqlParameter("@flowDate", SqlDbType.DateTime, 8));
			cmd.Parameters.Add(new SqlParameter("@flowHour", SqlDbType.TinyInt, 1));
			cmd.Parameters.Add(new SqlParameter("@codiceMercato", SqlDbType.VarChar, 4));
			cmd.Parameters.Add(new SqlParameter("@progressivoEsecuzione", SqlDbType.Int, 4));
			cmd.Parameters.Add(new SqlParameter("@blobRis", SqlDbType.VarBinary, 2147483647));
			cmd.Parameters.Add(new SqlParameter("@statoEsecuzioneOra", SqlDbType.VarChar, 4));

			cmd.Parameters["@flowDate"].Value = es.FlowDate;
			cmd.Parameters["@flowHour"].Value = es.Ora;
			cmd.Parameters["@codiceMercato"].Value = es.CodiceMercato;
			cmd.Parameters["@progressivoEsecuzione"].Value = es.ProgressivoEsecuzione;
			cmd.Parameters["@blobRis"].Value = bmsZip;

			switch (statoElaborazione)
			{
			case StatoElaborazione.Fallita:
				cmd.Parameters["@statoEsecuzioneOra"].Value = "ERR";
				break;
			case StatoElaborazione.Ottima:
			case StatoElaborazione.SubOttima:
				cmd.Parameters["@statoEsecuzioneOra"].Value = "HBMR";
				break;
			}


			cmd.ExecuteNonQuery();

			int r = (int) cmd.Parameters["@RETURN_VALUE"].Value;
			if (r != 0)
			{
				string m = string.Format("AlgoRis_StoreBlobRisAlgo ritorna {0}", r);
				Log.smError(m);
				throw new Exception(m);
			}
		}

		private static byte[] CreaBlobRisultatiAlgo(DatiElaborazione ri, AlgoRis_ListaEsecuzioni es)
		{
			MemoryStream ms = new MemoryStream();
			XmlTextWriter xw = new XmlTextWriter(ms, Encoding.UTF8);
			XmlSerializer x = new XmlSerializer(typeof (DatiElaborazione));
			xw.Formatting = Formatting.Indented;
			xw.IndentChar = '\t';
			xw.Indentation = 1;
			x.Serialize(xw, ri);
			xw.Close();

			byte[] bms = ms.ToArray();
			string nomeFile = string.Format("Ris_{0:yy}{0:MM}{0:dd}_{1}_{2}_{3}.xml", es.FlowDate, es.Ora, es.CodiceMercato, es.ProgressivoEsecuzione);
			return ZipFile.ZipSingleFile(nomeFile, bms);
		}


		public virtual void RendiProvRisultato(DateTime flowDate, byte flowHour, string codiceMercato, int progressivoEsecuzione)
		{
			try
			{
				cn.Open();

				RendiProvRisultatoInternal(cn, flowDate, flowHour, codiceMercato, progressivoEsecuzione);

				cn.Close();

			}
			catch (Exception ex)
			{
				smError(ex);
				throw;
			}
			finally
			{
				cn.Dispose();
			}
		}


		private static void RendiProvRisultatoInternal(SqlConnection cn, DateTime flowDate, byte flowHour, string codiceMercato, int progressivoEsecuzione)
		{
			bool conferma;
			SqlTransaction tr;
			DatiElaborazione ri = ReadBlobRisAlgo(cn, flowDate, flowHour, codiceMercato, progressivoEsecuzione);

			tr = cn.BeginTransaction();
			try
			{
				// qui memorizzo nel DB DatiElaborazione ri.
				// Notare che ri.statoElaborazione puo` indicare fallimento
				// in questo caso i dati NON si memorizzano.


				// cambio lo stato da HBMR a OK
				// puo` ritornare false se i risultati dall'algortimo non sono ok
				conferma = MemorizzaRisultatiEsecuzioneOra(cn, tr, ri, flowDate, flowHour, progressivoEsecuzione, codiceMercato);
				if (conferma)
				{
					MemorizzaRisultatoZonale(cn, tr, ri, flowDate, flowHour, codiceMercato, progressivoEsecuzione);
					MemorizzaRisultatoFlussoInterzonali(cn, tr, ri, flowDate, flowHour, codiceMercato, progressivoEsecuzione);
					MemorizzaOfferte(cn, tr, ri);
				}

				tr.Commit();
				tr = null;
			}
			catch (Exception e)
			{
				Log.smError(e);
				if (tr != null)
					tr.Rollback();
				throw;
			}
			// questo lo faccio DOPO la commit... NON e` un errore
			// (almeno spero)
			if (conferma)
				MemorizzaCalcolaAggregati(cn, flowDate, flowHour, codiceMercato, progressivoEsecuzione);
		}

		public void RendiCompRisultato(DateTime flowDate, byte flowHour, string codiceMercato, int progressivoEsecuzione)
		{
			try
			{
				cn.Open();

				SqlCommand cmd = cn.CreateCommand();

				cmd.CommandText = "dbo.[AlgoRis_RendiElaborazioneCOMP]";
				cmd.CommandType = CommandType.StoredProcedure;
				cmd.Parameters.Add(new SqlParameter("@flowDate", SqlDbType.DateTime, 8));
				cmd.Parameters.Add(new SqlParameter("@flowHour", SqlDbType.TinyInt, 1));
				cmd.Parameters.Add(new SqlParameter("@codiceMercato", SqlDbType.VarChar, 4));
				cmd.Parameters.Add(new SqlParameter("@progressivoEsecuzione", SqlDbType.Int, 4));

				cmd.Parameters["@flowDate"].Value = flowDate;
				cmd.Parameters["@flowHour"].Value = flowHour;
				cmd.Parameters["@codiceMercato"].Value = codiceMercato;
				cmd.Parameters["@progressivoEsecuzione"].Value = progressivoEsecuzione;

				cmd.ExecuteNonQuery();

				cn.Close();
			}
			catch (Exception ex)
			{
				smError(ex);
				throw;
			}
			finally
			{
				cn.Dispose();
			}
		}


		public void RendiErrRisultato(DateTime flowDate, byte flowHour, string codiceMercato, int progressivoEsecuzione)
		{
			try
			{
				cn.Open();

				SqlCommand cmd = cn.CreateCommand();

				cmd.CommandText = "dbo.[AlgoRis_RendiElaborazioneERR]";
				cmd.CommandType = CommandType.StoredProcedure;
				cmd.Parameters.Add(new SqlParameter("@flowDate", SqlDbType.DateTime, 8));
				cmd.Parameters.Add(new SqlParameter("@flowHour", SqlDbType.TinyInt, 1));
				cmd.Parameters.Add(new SqlParameter("@codiceMercato", SqlDbType.VarChar, 4));
				cmd.Parameters.Add(new SqlParameter("@progressivoEsecuzione", SqlDbType.Int, 4));

				cmd.Parameters["@flowDate"].Value = flowDate;
				cmd.Parameters["@flowHour"].Value = flowHour;
				cmd.Parameters["@codiceMercato"].Value = codiceMercato;
				cmd.Parameters["@progressivoEsecuzione"].Value = progressivoEsecuzione;

				cmd.ExecuteNonQuery();

				cn.Close();
			}
			catch (Exception ex)
			{
				smError(ex);
				throw;
			}
			finally
			{
				cn.Dispose();
			}
		}




		private static DatiElaborazione ReadBlobRisAlgo(SqlConnection cn, DateTime flowDate, byte flowHour, string codiceMercato, int progressivoEsecuzione)
		{
			byte[] zipRis;
			SqlCommand cmd = cn.CreateCommand();
			cmd.CommandText = "dbo.[AlgoRis_ReadBlobRisAlgo]";
			cmd.CommandTimeout = AppSettings.ToInt32("AlgoRis_ReadBlobRisAlgo_Timeout", 30);
			cmd.CommandType = CommandType.StoredProcedure;
			cmd.Parameters.Add(new SqlParameter("@RETURN_VALUE", SqlDbType.Int, 4, ParameterDirection.ReturnValue, false, ((Byte) (0)), ((Byte) (0)), "", DataRowVersion.Current, null));
			cmd.Parameters.Add(new SqlParameter("@flowDate", SqlDbType.DateTime, 8));
			cmd.Parameters.Add(new SqlParameter("@flowHour", SqlDbType.TinyInt, 1));
			cmd.Parameters.Add(new SqlParameter("@codiceMercato", SqlDbType.VarChar, 4));
			cmd.Parameters.Add(new SqlParameter("@progressivoEsecuzione", SqlDbType.Int, 4));

			cmd.Parameters["@flowDate"].Value = flowDate;
			cmd.Parameters["@flowHour"].Value = flowHour;
			cmd.Parameters["@codiceMercato"].Value = codiceMercato;
			cmd.Parameters["@progressivoEsecuzione"].Value = progressivoEsecuzione;

			zipRis = (byte[]) cmd.ExecuteScalar();

			// unzippo il risultato
			string fileName;
			byte[] ris = ZipFile.UnzipSingleFile(zipRis, out fileName);
			XmlSerializer xs = new XmlSerializer(typeof (DatiElaborazione));
			return (DatiElaborazione) xs.Deserialize(new MemoryStream(ris));
		}

		public virtual byte[] ReadBlobRisultatoAlgoritmo(DateTime flowDate, byte flowHour, string codiceMercato, int progressivoEsecuzione)
		{
			try
			{
				cn.Open();

				SqlCommand cmd = cn.CreateCommand();
				cmd.CommandText = "dbo.[AlgoRis_ReadBlobRisAlgo]";
				cmd.CommandTimeout = AppSettings.ToInt32("AlgoRis_ReadBlobRisAlgo_Timeout", 30);
				cmd.CommandType = CommandType.StoredProcedure;
				cmd.Parameters.Add(new SqlParameter("@RETURN_VALUE", SqlDbType.Int, 4, ParameterDirection.ReturnValue, false, ((Byte) (0)), ((Byte) (0)), "", DataRowVersion.Current, null));
				cmd.Parameters.Add(new SqlParameter("@flowDate", SqlDbType.DateTime, 8));
				cmd.Parameters.Add(new SqlParameter("@flowHour", SqlDbType.TinyInt, 1));
				cmd.Parameters.Add(new SqlParameter("@codiceMercato", SqlDbType.VarChar, 4));
				cmd.Parameters.Add(new SqlParameter("@progressivoEsecuzione", SqlDbType.Int, 4));

				cmd.Parameters["@flowDate"].Value = flowDate;
				cmd.Parameters["@flowHour"].Value = flowHour;
				cmd.Parameters["@codiceMercato"].Value = codiceMercato;
				cmd.Parameters["@progressivoEsecuzione"].Value = progressivoEsecuzione;

				object zipRis = cmd.ExecuteScalar();
				if (zipRis == null)
					return null;
				if (zipRis == DBNull.Value)
					return null;

				return (byte[]) zipRis;
			}
			catch (Exception ex)
			{
				smError(ex);
				throw;
			}
			finally
			{
				cn.Dispose();
			}
		}

		public void AbortEsecuzione(DateTime flowDate, byte flowHour, string codiceMercato, int progressivoEsecuzione)
		{
			try
			{
				cn.Open();

				SqlCommand cmd = cn.CreateCommand();
				cmd.CommandText = "dbo.[AlgoRis_AbortEsecuzione]";
				cmd.CommandTimeout = AppSettings.ToInt32("AlgoRis_AbortEsecuzione_Timeout", 30);
				cmd.CommandType = CommandType.StoredProcedure;
				cmd.Parameters.Add(new SqlParameter("@flowDate", SqlDbType.DateTime, 8));
				cmd.Parameters.Add(new SqlParameter("@flowHour", SqlDbType.TinyInt, 1));
				cmd.Parameters.Add(new SqlParameter("@codiceMercato", SqlDbType.VarChar, 4));
				cmd.Parameters.Add(new SqlParameter("@progressivoEsecuzione", SqlDbType.Int, 4));

				cmd.Parameters["@flowDate"].Value = flowDate;
				cmd.Parameters["@flowHour"].Value = flowHour;
				cmd.Parameters["@codiceMercato"].Value = codiceMercato;
				cmd.Parameters["@progressivoEsecuzione"].Value = progressivoEsecuzione;

				cmd.ExecuteNonQuery();

				cn.Close();
			}
			catch (Exception ex)
			{
				smError(ex);
				throw;
			}
			finally
			{
				cn.Dispose();
			}
		}

		public virtual DataSet ReadListaEsecuzioni(DateTime flowDate, int flowHour, string codiceMercato, string statoEsecuzioneOra, int progressivoEsecuzione)
		{
			try
			{
				SqlCommand cmd = cn.CreateCommand();
				cmd.CommandText = "dbo.[AlgoRis_ReadListaEsecuzioni]";
				cmd.CommandTimeout = AppSettings.ToInt32("AlgoRis_ReadListaEsecuzioni_Timeout", 30);
				cmd.CommandType = CommandType.StoredProcedure;

				cmd.Parameters.Add(new SqlParameter("@flowDate", SqlDbType.SmallDateTime, 8));
				cmd.Parameters.Add(new SqlParameter("@flowHour", SqlDbType.TinyInt, 1));
				cmd.Parameters.Add(new SqlParameter("@codiceMercato", SqlDbType.VarChar, 4));
				cmd.Parameters.Add(new SqlParameter("@progressivoEsecuzione", SqlDbType.Int, 4));
				cmd.Parameters.Add(new SqlParameter("@statoEsecuzioneOra", SqlDbType.VarChar, 4));

				if (flowDate != DateTime.MinValue)
					cmd.Parameters["@flowDate"].Value = flowDate;

				if (flowHour >= 0)
					cmd.Parameters["@flowHour"].Value = (byte) flowHour;

				if (codiceMercato != null)
					cmd.Parameters["@codiceMercato"].Value = codiceMercato;

				if (progressivoEsecuzione >= 0)
					cmd.Parameters["@progressivoEsecuzione"].Value = progressivoEsecuzione;

				if (statoEsecuzioneOra != null)
				{
					// codice per forzare che la stringa rappresenti proprio un StatoEsecuzioneOra
					statoEsecuzioneOra = Enum.Parse(typeof (StatoEsecuzioneOra), statoEsecuzioneOra, true).ToString();
					cmd.Parameters["@statoEsecuzioneOra"].Value = statoEsecuzioneOra;
				}

				SqlDataAdapter da = new SqlDataAdapter(cmd);

				DataSet ds = new DataSet();
				DataTable dt = ds.Tables.Add("ListaEsecuzioni");

				DataColumn c1;
				c1 = dt.Columns.Add("FlowDate", typeof(DateTime));
				c1.AllowDBNull = false;
				c1.Unique = false;

				DataColumn c2;
				c2 = dt.Columns.Add("Ora", typeof(byte));
				c2.AllowDBNull = false;
				c2.Unique = false;

				DataColumn c3;
				c3 = dt.Columns.Add("CodiceMercato", typeof(string));
				c3.MaxLength = 4;
				c3.AllowDBNull = false;
				c3.Unique = false;

				DataColumn c4;
				c4 = dt.Columns.Add("ProgressivoEsecuzione", typeof(int));
				c4.AllowDBNull = false;
				c4.Unique = false;

				dt.PrimaryKey = new DataColumn[] { c1, c2, c3, c4 };


				da.Fill(dt);

				return ds;
			}
			catch (Exception ex)
			{
				smError(ex);
				throw;
			}
		}

		#region elaborazione risultati

		private static bool MemorizzaRisultatiEsecuzioneOra(SqlConnection cn, SqlTransaction tr, DatiElaborazione ri, DateTime flowDate, byte flowHour, int progressivoEsecuzione, string codiceMercato)
		{
			SqlCommand cmd = cn.CreateCommand();
			cmd.Transaction = tr;

			cmd.CommandText = "dbo.[AlgoRis_RendiElaborazionePROV]";
			cmd.CommandTimeout = AppSettings.ToInt32("AlgoRis_RendiElaborazionePROV_Timeout", 30);
			cmd.CommandType = CommandType.StoredProcedure;
			cmd.Parameters.Add(new SqlParameter("@RETURN_VALUE", SqlDbType.Int, 4, ParameterDirection.ReturnValue, false, ((Byte) (0)), ((Byte) (0)), "", DataRowVersion.Current, null));
			cmd.Parameters.Add(new SqlParameter("@flowDate", SqlDbType.DateTime, 8));
			cmd.Parameters.Add(new SqlParameter("@flowHour", SqlDbType.TinyInt, 1));
			cmd.Parameters.Add(new SqlParameter("@codiceMercato", SqlDbType.VarChar, 4));
			cmd.Parameters.Add(new SqlParameter("@progressivoEsecuzione", SqlDbType.Int, 4));
			cmd.Parameters.Add(new SqlParameter("@statoEsecuzioneOra", SqlDbType.VarChar, 4));
			cmd.Parameters.Add(new SqlParameter("@prezzoUnico", SqlDbType.Float, 8));
			cmd.Parameters.Add(new SqlParameter("@prezzoUnconstrained", SqlDbType.Float, 8));
			cmd.Parameters.Add(new SqlParameter("@quantitaUnconstrained", SqlDbType.Float, 8));

			cmd.Parameters["@flowDate"].Value = flowDate;
			cmd.Parameters["@flowHour"].Value = flowHour;
			cmd.Parameters["@codiceMercato"].Value = codiceMercato;
			cmd.Parameters["@progressivoEsecuzione"].Value = progressivoEsecuzione;

			// qui lo stato dell'elaborazione dovrebbe essere sempre Ottima/SubOttima
			// Per precauzione comunque si gestisce anche il fallimento
			bool ret = false;
			switch (ri.statoElaborazione)
			{
			case StatoElaborazione.Fallita:
				cmd.Parameters["@statoEsecuzioneOra"].Value = "ERR";
				ret = false;
				break;
			case StatoElaborazione.Ottima:
				cmd.Parameters["@statoEsecuzioneOra"].Value = "PROV";
				ret = true;
				break;
			case StatoElaborazione.SubOttima:
				cmd.Parameters["@statoEsecuzioneOra"].Value = "PROV";
				ret = true;
				break;
			}

			if (ri.prezzoUnicoSpecified)
				cmd.Parameters["@prezzoUnico"].Value = ri.prezzoUnico;

			if (ri.prezzoUnconstrainedSpecified)
				cmd.Parameters["@prezzoUnconstrained"].Value = ri.prezzoUnconstrained;

			if (ri.quantitaUnconstrainedSpecified)
				cmd.Parameters["@quantitaUnconstrained"].Value = ri.quantitaUnconstrained;

			cmd.ExecuteNonQuery();
			return ret;

		}

		private static void MemorizzaOfferte(SqlConnection cn, SqlTransaction tr, DatiElaborazione ri)
		{
			SqlCommand cmd = cn.CreateCommand();
			cmd.Transaction = tr;

			cmd.CommandText = "AlgoRis_Memorizza_Offerta";
			cmd.CommandType = CommandType.StoredProcedure;
			cmd.CommandTimeout = AppSettings.ToInt32("AlgoRis_Memorizza_Offerta_Timeout", 30);

			cmd.Parameters.Add("@idOfferta", SqlDbType.VarChar, 32);
			cmd.Parameters.Add("@prezzoAssegnato", SqlDbType.Float);
			cmd.Parameters.Add("@quantitaAssegnata", SqlDbType.Float);
			cmd.Parameters.Add("@offertaVendita", SqlDbType.TinyInt);
			cmd.Parameters.Add(new SqlParameter("@RETURN", SqlDbType.Int, 4, ParameterDirection.ReturnValue, false, 0, 0, "", DataRowVersion.Current, null));

			cmd.Prepare();

			for (int i = 0; i < ri.OffertaVendita.Length; ++i)
			{
				OffertaVendita z = ri.OffertaVendita[i];

				cmd.Parameters["@idOfferta"].Value = z.idOfferta;
				cmd.Parameters["@prezzoAssegnato"].Value = z.prezzoAssegnato;
				cmd.Parameters["@quantitaAssegnata"].Value = z.quantitaAssegnataMWh;
				cmd.Parameters["@offertaVendita"].Value = 1;


				cmd.ExecuteNonQuery();

				int r = (int) cmd.Parameters["@RETURN"].Value;
				Debug.Assert(r == 0);
			}

			for (int i = 0; i < ri.OffertaAcquisto.Length; ++i)
			{
				OffertaAcquisto z = ri.OffertaAcquisto[i];

				cmd.Parameters["@idOfferta"].Value = z.idOfferta;
				cmd.Parameters["@prezzoAssegnato"].Value = z.prezzoAssegnato;
				cmd.Parameters["@quantitaAssegnata"].Value = z.quantitaAssegnataMWh;
				cmd.Parameters["@offertaVendita"].Value = 0;

				cmd.ExecuteNonQuery();

				int r = (int) cmd.Parameters["@RETURN"].Value;
				Debug.Assert(r == 0);
			}
		}

		private static void MemorizzaRisultatoFlussoInterzonali(SqlConnection cn, SqlTransaction tr, DatiElaborazione ri, DateTime dataFlusso, byte ora, string codiceMercato, int progressivoEsecuzione)
		{
			SqlCommand cmd = cn.CreateCommand();
			cmd.Transaction = tr;

			cmd.CommandText = "AlgoRis_Memorizza_RisultatoInterZonale";
			cmd.CommandType = CommandType.StoredProcedure;
			cmd.CommandTimeout = AppSettings.ToInt32("AlgoRis_Memorizza_RisultatoInterZonale_Timeout", 30);

			cmd.Parameters.Add("@flowDate", SqlDbType.SmallDateTime);
			cmd.Parameters.Add("@flowHour", SqlDbType.TinyInt);
			cmd.Parameters.Add("@codiceMercato", SqlDbType.VarChar, 4);
			cmd.Parameters.Add("@progressivoEsecuzione", SqlDbType.Int);
			cmd.Parameters.Add("@daZona", SqlDbType.VarChar, 4);
			cmd.Parameters.Add("@aZona", SqlDbType.VarChar, 4);
			cmd.Parameters.Add("@flussoReale", SqlDbType.Float);
			cmd.Parameters.Add(new SqlParameter("@RETURN", SqlDbType.Int, 4, ParameterDirection.ReturnValue, false, 0, 0, "dummy", DataRowVersion.Current, null));

			cmd.Prepare();

			for (int i = 0; i < ri.VincoloInterzonale.Length; ++i)
			{
				VincoloInterzonale z = ri.VincoloInterzonale[i];

				cmd.Parameters["@flowDate"].Value = dataFlusso;
				cmd.Parameters["@flowHour"].Value = ora;
				cmd.Parameters["@codiceMercato"].Value = codiceMercato;
				cmd.Parameters["@progressivoEsecuzione"].Value = progressivoEsecuzione;
				cmd.Parameters["@daZona"].Value = z.daZona;
				cmd.Parameters["@aZona"].Value = z.aZona;
				cmd.Parameters["@flussoReale"].Value = z.flusso;

				cmd.ExecuteNonQuery();

				int r = (int) cmd.Parameters["@RETURN"].Value;
				Debug.Assert(r == 0);
			}
		}

		private static void MemorizzaRisultatoZonale(SqlConnection cn, SqlTransaction tr, DatiElaborazione ri,
		                                             DateTime dataFlusso, byte ora, string codiceMercato, int progressivoEsecuzione)
		{
			SqlCommand cmd = cn.CreateCommand();
			cmd.Transaction = tr;

			cmd.CommandText = "AlgoRis_Memorizza_RisultatoZonale";
			cmd.CommandType = CommandType.StoredProcedure;
			cmd.CommandTimeout = AppSettings.ToInt32("AlgoRis_Memorizza_RisultatoZonale_Timeout", 30);

			cmd.Parameters.Add(new SqlParameter("@RETURN_VALUE", SqlDbType.Int, 4, ParameterDirection.ReturnValue, false, 0, 0, "", DataRowVersion.Current, null));
			cmd.Parameters.Add("@flowDate", SqlDbType.SmallDateTime);
			cmd.Parameters.Add("@flowHour", SqlDbType.TinyInt);
			cmd.Parameters.Add("@codiceMercato", SqlDbType.VarChar, 4);
			cmd.Parameters.Add("@progressivoEsecuzione", SqlDbType.Int);
			cmd.Parameters.Add("@codiceZona", SqlDbType.VarChar, 4);
			cmd.Parameters.Add("@prezzoZonale", SqlDbType.Float);

			cmd.Prepare();

			for (int i = 0; i < ri.Zona.Length; ++i)
			{
				Zona z = ri.Zona[i];

				cmd.Parameters["@flowDate"].Value = dataFlusso;
				cmd.Parameters["@flowHour"].Value = ora;
				cmd.Parameters["@codiceMercato"].Value = codiceMercato;
				cmd.Parameters["@progressivoEsecuzione"].Value = progressivoEsecuzione;
				cmd.Parameters["@codiceZona"].Value = z.codiceZona;
				cmd.Parameters["@prezzoZonale"].Value = z.prezzoZonale;

				cmd.ExecuteNonQuery();

				int r = (int) cmd.Parameters["@RETURN_VALUE"].Value;
				Debug.Assert(r == 0);
			}
		}


		private static void MemorizzaCalcolaAggregati(SqlConnection cn, DateTime dataFlusso, byte ora, string codiceMercato, int progressivoEsecuzione)
		{
			SqlCommand cmd = cn.CreateCommand();
			cmd.CommandText = "AlgoRis_Memorizza_CalcolaAggregati";
			cmd.CommandType = CommandType.StoredProcedure;
			cmd.CommandTimeout = AppSettings.ToInt32("AlgoRis_Memorizza_CalcolaAggregati_Timeout", 30);
			cmd.Parameters.Add(new SqlParameter("@RETURN_VALUE", SqlDbType.Int, 4, ParameterDirection.ReturnValue, false, 0, 0, "", DataRowVersion.Current, null));
			cmd.Parameters.Add("@flowDate", SqlDbType.SmallDateTime);
			cmd.Parameters.Add("@flowHour", SqlDbType.TinyInt);
			cmd.Parameters.Add("@codiceMercato", SqlDbType.VarChar, 4);
			cmd.Parameters.Add("@progressivoEsecuzione", SqlDbType.Int);

			cmd.Parameters["@flowDate"].Value = dataFlusso;
			cmd.Parameters["@flowHour"].Value = ora;
			cmd.Parameters["@codiceMercato"].Value = codiceMercato;
			cmd.Parameters["@progressivoEsecuzione"].Value = progressivoEsecuzione;

			cmd.ExecuteNonQuery();

			int r = (int) cmd.Parameters["@RETURN_VALUE"].Value;
			Debug.Assert(r == 0);
		}

		#endregion
	}
}