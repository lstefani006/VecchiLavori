using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using Crownwood.Magic.Common;
using Crownwood.Magic.Docking;
using Crownwood.Magic.Menus;
using GME.Remoting;
using MeRT_IBL;
using TabControl = Crownwood.Magic.Controls.TabControl;
using TabPage = Crownwood.Magic.Controls.TabPage;
//using VisualAppearance = Crownwood.Magic.Controls.TabControl.VisualAppearance;

namespace MeRT_ControlEngine
{
	/// <summary>
	/// Summary description for EngineMainForm.
	/// </summary>
	public class EngineMainForm : Form
	{
		protected VisualStyle _style;
		protected TabControl _filler;
		protected DockingManager _manager;
		protected StatusBar _statusBar;
		protected StatusBarPanel _statusBarPanel;
		protected MenuControl _topMenu;
		protected bool _allowContextMenu = true;
		protected bool _customContextMenu = false;
		protected int _ignoreClose = 0;

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private Container components = null;


		public EngineMainForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();


			_style = VisualStyle.IDE;
			BorderStyle bs = (_style == VisualStyle.Plain) ? BorderStyle.None : BorderStyle.FixedSingle;

			RichTextBox rtb1 = new RichTextBox();
			RichTextBox rtb2 = new RichTextBox();
			RichTextBox rtb3 = new RichTextBox();

			rtb1.BorderStyle = bs;
			rtb2.BorderStyle = bs;
			rtb3.BorderStyle = bs;

			_filler = new TabControl();
			_filler.TabPages.Add(new TabPage("Comandi ", rtb1));
			_filler.TabPages.Add(new TabPage("Controllo ", rtb2));
			_filler.TabPages.Add(new TabPage("Gestione ", rtb3));
			_filler.TabPages.Add(new TabPage("Controllo esecuzioni ", new ControlloEsecuzione()));
			_filler.TabPages.Add(new TabPage("Upload ", new UploadMessage()));

			_filler.Appearance = TabControl.VisualAppearance.MultiDocument;
			_filler.Dock = DockStyle.Fill;
			_filler.Style = _style;
			_filler.IDEPixelBorder = true;
			Controls.Add(_filler);

			// Reduce the amount of flicker that occurs when windows are redocked within
			// the container. As this prevents unsightly backcolors being drawn in the
			// WM_ERASEBACKGROUND that seems to occur.
			SetStyle(ControlStyles.DoubleBuffer, true);
			SetStyle(ControlStyles.AllPaintingInWmPaint, true);

			// Create the object that manages the docking state
			_manager = new DockingManager(this, _style);

			// Notifications
			_manager.ContextMenu += new DockingManager.ContextMenuHandler(OnContextMenu);
			_manager.ContentHiding += new DockingManager.ContentHidingHandler(OnContentHiding);
			_manager.TabControlCreated += new DockingManager.TabControlCreatedHandler(OnTabControlCreated);

			// Ensure that the RichTextBox is always the innermost control
			_manager.InnerControl = _filler;


			// Create and setup the StatusBar object
			_statusBar = new StatusBar();
			_statusBar.Dock = DockStyle.Bottom;
			_statusBar.ShowPanels = true;

			// Create and setup a single panel for the StatusBar
			_statusBarPanel = new StatusBarPanel();
			_statusBarPanel.AutoSize = StatusBarPanelAutoSize.Spring;
			_statusBar.Panels.Add(_statusBarPanel);
			Controls.Add(_statusBar);
			// Ensure that docking occurs after the menu control and status bar controls
			_manager.OuterControl = _statusBar;

			_topMenu = CreateMenus();


			// Setup custom config handling
//			_manager.SaveCustomConfig += new DockingManager.SaveCustomConfigHandler(OnSaveConfig);
//			_manager.LoadCustomConfig += new DockingManager.LoadCustomConfigHandler(OnLoadConfig);


			Content c = _manager.Contents.Add(new DummyForm(), "Controllo DummyForm");
			_manager.AddContentWithState(c, State.DockLeft);

			try
			{
				IEcho e = (IEcho) RemotingHelper.GetObject(typeof (IEcho));
				//e.DoEcho(false);
				rtb1.Text = e.DoEcho(false);
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		protected void OnContextMenu(PopupMenu pm, CancelEventArgs cea)
		{
			// Show the PopupMenu be cancelled and not shown?
			if (!_allowContextMenu)
				cea.Cancel = true;
			else
			{
				if (_customContextMenu)
				{
					// Remove the Show All and Hide All commands
					pm.MenuCommands.Remove(pm.MenuCommands["Show All"]);
					pm.MenuCommands.Remove(pm.MenuCommands["Hide All"]);

					// Add a custom item at the start
					pm.MenuCommands.Insert(0, (new MenuCommand("Custom 1")));
					pm.MenuCommands.Insert(1, (new MenuCommand("-")));

					// Add a couple of custom commands at the end
					pm.MenuCommands.Add(new MenuCommand("Custom 2"));
					pm.MenuCommands.Add(new MenuCommand("Custom 3"));
				}
			}
		}

		protected void OnContentHiding(Content c, CancelEventArgs cea)
		{
			switch (_ignoreClose)
			{
			case 0:
				// Allow all, do nothing
				break;
			case 1:
				// Ignore all, cancel
				cea.Cancel = true;
				break;
			case 2:
				// Ignore Panels
				cea.Cancel = c.Control is Panel;
				break;
			case 3:
				// Ignore Forms
				cea.Cancel = c.Control is Form;
				break;
			case 4:
				// Ignore RichTextBox
				cea.Cancel = c.Control is RichTextBox;
				break;
			}
		}

		protected void OnTabControlCreated(TabControl tabControl)
		{
//			tabControl.PositionTop = !_tabsBottom;
			//tabControl.Appearance = _tabAppearance;
		}

		protected MenuControl CreateMenus()
		{
			MenuControl topMenu = new MenuControl();
			topMenu.Style = _style;
			topMenu.MultiLine = false;

			MenuCommand topManager = new MenuCommand("Manager");
			MenuCommand topConfig = new MenuCommand("Config");
			topMenu.MenuCommands.AddRange(new MenuCommand[] {topManager, topConfig});

			MenuCommand managerC1 = new MenuCommand("Create Form", new EventHandler(OnCreateC1));
			topManager.MenuCommands.Add(managerC1);

			MenuCommand managerC2 = new MenuCommand("Create Panel", new EventHandler(OnCreateC2));
			topManager.MenuCommands.Add(managerC2);
			MenuCommand managerC3 = new MenuCommand("Create RichTextBox", new EventHandler(OnCreateC3));
			topManager.MenuCommands.Add(managerC3);


			topMenu.Dock = DockStyle.Top;

			topMenu.Selected += new CommandHandler(OnSelected);
			topMenu.Deselected += new CommandHandler(OnDeselected);

			Controls.Add(topMenu);

			return topMenu;
		}

		private void OnCreateC1(object sender, EventArgs e)
		{
			Content c = _manager.Contents.Add(new RichTextBox(), "Ciao");
			_manager.AddContentWithState(c, State.DockLeft);
		}

		private void OnCreateC2(object sender, EventArgs e)
		{
			//throw new NotImplementedException();
			MessageBox.Show("Not Implemented Yet!");
		}

		private void OnCreateC3(object sender, EventArgs e)
		{
			//throw new NotImplementedException();
			MessageBox.Show("Not Implemented Yet!");
		}


		private void OnDeselected(MenuCommand item)
		{
			SetStatusBarText("");
		}

		private void OnSelected(MenuCommand item)
		{
			SetStatusBarText("Selection over " + item.Description);
		}

		public void SetStatusBarText(string text)
		{
			_statusBarPanel.Text = text;
		}


		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose(bool disposing)
		{
			if (disposing)
			{
				if (components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			// 
			// EngineMainForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(816, 389);
			this.Name = "EngineMainForm";
			this.Text = "EngineMainForm";

		}

		#endregion
	}


	public class DummyForm : Form
	{
		private Button _dummy1 = new Button();
		private Button _dummy2 = new Button();
		private GroupBox _dummyBox = new GroupBox();
		private RadioButton _dummy3 = new RadioButton();
		private RadioButton _dummy4 = new RadioButton();

		public DummyForm()
		{
			_dummy1.Text = "Do Echo!";
			_dummy1.Size = new Size(90, 25);
			_dummy1.Location = new Point(10, 10);
			_dummy1.Click += new EventHandler(_dummy1_Click);

			_dummy2.Text = "Button 2";
			_dummy2.Size = new Size(90, 25);
			_dummy2.Location = new Point(110, 10);

			_dummyBox.Text = "Form GroupBox";
			_dummyBox.Size = new Size(125, 67);
			_dummyBox.Location = new Point(10, 45);

			_dummy3.Text = "RadioButton 3";
			_dummy3.Size = new Size(110, 22);
			_dummy3.Location = new Point(10, 20);

			_dummy4.Text = "RadioButton 4";
			_dummy4.Size = new Size(110, 22);
			_dummy4.Location = new Point(10, 42);
			_dummy4.Checked = true;

			_dummyBox.Controls.AddRange(new Control[] {_dummy3, _dummy4});

			Controls.AddRange(new Control[] {_dummy1, _dummy2, _dummyBox});

			this.Disposed += new EventHandler(OnFormDisposed);

			// Define then control to be selected when activated for first time
			this.ActiveControl = _dummy4;
		}

		protected void OnFormDisposed(object sender, EventArgs e)
		{
			Console.WriteLine("OnFormDisposed");
		}

		private void _dummy1_Click(object sender, EventArgs e)
		{
			try
			{
				IEcho ec = (IEcho) RemotingHelper.GetObject(typeof (IEcho));
				//rtb2.Text = ec.DoEcho(false);
				MessageBox.Show(ec.DoEcho(false));
			}
			catch (Exception ex)
			{
				//rtb3.Text = ex.Message;
				MessageBox.Show(ex.Message);
			}

		}
	}

}