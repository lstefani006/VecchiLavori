using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.IO;
using System.Windows.Forms;

using GME.Remoting;
using MeRT_IBL;

namespace MeRT_ControlEngine
{
	/// <summary>
	/// Summary description for UploadMessage.
	/// </summary>
	public class UploadMessage : System.Windows.Forms.Form
	{
		private System.Windows.Forms.TextBox textBox1;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Button button2;
		private System.Windows.Forms.ListBox listBox1;
		private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
		private System.IO.DirectoryInfo _di = null;
		private System.Windows.Forms.TextBox textBox2;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public UploadMessage()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.button1 = new System.Windows.Forms.Button();
			this.button2 = new System.Windows.Forms.Button();
			this.listBox1 = new System.Windows.Forms.ListBox();
			this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
			this.textBox2 = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// textBox1
			// 
			this.textBox1.Location = new System.Drawing.Point(48, 336);
			this.textBox1.Name = "textBox1";
			this.textBox1.ReadOnly = true;
			this.textBox1.Size = new System.Drawing.Size(440, 20);
			this.textBox1.TabIndex = 0;
			this.textBox1.Text = "textBox1";
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(504, 304);
			this.button1.Name = "button1";
			this.button1.TabIndex = 1;
			this.button1.Text = "Search";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// button2
			// 
			this.button2.Location = new System.Drawing.Point(504, 336);
			this.button2.Name = "button2";
			this.button2.TabIndex = 2;
			this.button2.Text = "Upload";
			this.button2.Click += new System.EventHandler(this.button2_Click);
			// 
			// listBox1
			// 
			this.listBox1.Location = new System.Drawing.Point(8, 8);
			this.listBox1.Name = "listBox1";
			this.listBox1.Size = new System.Drawing.Size(568, 277);
			this.listBox1.TabIndex = 3;
			this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
			// 
			// folderBrowserDialog1
			// 
			this.folderBrowserDialog1.ShowNewFolderButton = false;
			// 
			// textBox2
			// 
			this.textBox2.Location = new System.Drawing.Point(48, 304);
			this.textBox2.Name = "textBox2";
			this.textBox2.ReadOnly = true;
			this.textBox2.Size = new System.Drawing.Size(440, 20);
			this.textBox2.TabIndex = 4;
			this.textBox2.Text = "textBox2";
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(8, 304);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(40, 23);
			this.label1.TabIndex = 5;
			this.label1.Text = "Folder";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(8, 336);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(40, 23);
			this.label2.TabIndex = 6;
			this.label2.Text = "File";
			// 
			// UploadMessage
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(592, 373);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.textBox2);
			this.Controls.Add(this.listBox1);
			this.Controls.Add(this.button2);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.textBox1);
			this.Name = "UploadMessage";
			this.Text = "UploadMessage";
			this.Load += new System.EventHandler(this.UploadMessage_Load);
			this.ResumeLayout(false);

		}
		#endregion

		private void button1_Click(object sender, System.EventArgs e)
		{
			folderBrowserDialog1.SelectedPath = _di.FullName;
			DialogResult result = folderBrowserDialog1.ShowDialog();
			if(result == DialogResult.OK)
			{
				if (_di.FullName != folderBrowserDialog1.SelectedPath)
				{
					_di = new System.IO.DirectoryInfo(folderBrowserDialog1.SelectedPath);
					LoadFiles();
				}
			}

		}

		private void button2_Click(object sender, System.EventArgs e)
		{
			FileInfo fi = this.listBox1.SelectedItem as FileInfo;
			if (fi == null)
				return;
			string codiceOperatore = "IDGME";
			string codiceUtente = "1";
			string nomeFile = fi.Name;
			string encoding = "ISO-8859-1";

			byte[] fileXml = new System.Text.UTF8Encoding().GetBytes(File.OpenText(fi.FullName).ReadToEnd());

			ITransactionReader reader = (ITransactionReader) RemotingHelper.GetObject(typeof(ITransactionReader));

			reader.ReadMessage(codiceOperatore, codiceUtente, nomeFile, encoding, fileXml);
			MessageBox.Show("Read " + nomeFile);
		}

		private void listBox1_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			this.textBox1.Text = ((FileInfo)this.listBox1.SelectedItem).FullName;
		}

		private void UploadMessage_Load(object sender, System.EventArgs e)
		{
			_di = new System.IO.DirectoryInfo(System.IO.Directory.GetCurrentDirectory());
			folderBrowserDialog1.SelectedPath = _di.FullName;
			LoadFiles();
		}
		private void LoadFiles()
		{
			this.textBox2.Text = _di.FullName;
			this.textBox1.Text = string.Empty;
			this.listBox1.Items.Clear();
			FileInfo[] files = _di.GetFiles("*.xml");
			if (files.Length > 0)
			{
				this.textBox1.Text = files[0].FullName;
				this.listBox1.Items.AddRange(files);
				this.listBox1.SelectedIndex = 0;
			}
		}
	}
}
