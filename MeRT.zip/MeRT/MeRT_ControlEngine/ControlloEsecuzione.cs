using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using GME.Remoting;
using MeRT_IBL;

namespace MeRT_ControlEngine
{
	/// <summary>
	/// Summary description for ControlloEsecuzione.
	/// </summary>
	public class ControlloEsecuzione : Form
	{
		private DataGrid dgEsecuzioni;
		private Timer timer1;
		private System.Windows.Forms.ContextMenu cmnEsesuzioni;
		private System.Windows.Forms.MenuItem cmnEsesuzioni_RendiPROV;
		private System.Windows.Forms.MenuItem cmnEsesuzioni_RendiCOMP;
		private System.Windows.Forms.MenuItem cmnEsesuzioni_StudiaRisultati;
		private System.Windows.Forms.MenuItem cmnEsesuzioni_Abort;
		private System.Windows.Forms.MenuItem cmnEsesuzioni_RendiERR;
		private IContainer components;

		public ControlloEsecuzione()
		{
			InitializeComponent();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose(bool disposing)
		{
			if (disposing)
			{
				if (components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.dgEsecuzioni = new System.Windows.Forms.DataGrid();
			this.timer1 = new System.Windows.Forms.Timer(this.components);
			this.cmnEsesuzioni = new System.Windows.Forms.ContextMenu();
			this.cmnEsesuzioni_StudiaRisultati = new System.Windows.Forms.MenuItem();
			this.cmnEsesuzioni_RendiPROV = new System.Windows.Forms.MenuItem();
			this.cmnEsesuzioni_RendiCOMP = new System.Windows.Forms.MenuItem();
			this.cmnEsesuzioni_Abort = new System.Windows.Forms.MenuItem();
			this.cmnEsesuzioni_RendiERR = new System.Windows.Forms.MenuItem();
			((System.ComponentModel.ISupportInitialize)(this.dgEsecuzioni)).BeginInit();
			this.SuspendLayout();
			// 
			// dgEsecuzioni
			// 
			this.dgEsecuzioni.AllowNavigation = false;
			this.dgEsecuzioni.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.dgEsecuzioni.CaptionText = "Lista Esecuzioni";
			this.dgEsecuzioni.DataMember = "";
			this.dgEsecuzioni.HeaderForeColor = System.Drawing.SystemColors.ControlText;
			this.dgEsecuzioni.Location = new System.Drawing.Point(0, 0);
			this.dgEsecuzioni.Name = "dgEsecuzioni";
			this.dgEsecuzioni.Size = new System.Drawing.Size(592, 208);
			this.dgEsecuzioni.TabIndex = 0;
			this.dgEsecuzioni.MouseDown += new System.Windows.Forms.MouseEventHandler(this.dgEsecuzioni_MouseDown);
			this.dgEsecuzioni.MouseUp += new System.Windows.Forms.MouseEventHandler(this.dgEsecuzioni_MouseUp);
			// 
			// timer1
			// 
			this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
			// 
			// cmnEsesuzioni
			// 
			this.cmnEsesuzioni.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																						  this.cmnEsesuzioni_StudiaRisultati,
																						  this.cmnEsesuzioni_RendiPROV,
																						  this.cmnEsesuzioni_RendiCOMP,
																						  this.cmnEsesuzioni_RendiERR,
																						  this.cmnEsesuzioni_Abort});
			// 
			// cmnEsesuzioni_StudiaRisultati
			// 
			this.cmnEsesuzioni_StudiaRisultati.Index = 0;
			this.cmnEsesuzioni_StudiaRisultati.Text = "Studia risultati";
			this.cmnEsesuzioni_StudiaRisultati.Click += new System.EventHandler(this.cmnEsesuzioni_StudiaRisultati_Click);
			// 
			// cmnEsesuzioni_RendiPROV
			// 
			this.cmnEsesuzioni_RendiPROV.Index = 1;
			this.cmnEsesuzioni_RendiPROV.Text = "Rendi PROV";
			this.cmnEsesuzioni_RendiPROV.Click += new System.EventHandler(this.cmnEsesuzioni_RendiPROV_Click);
			// 
			// cmnEsesuzioni_RendiCOMP
			// 
			this.cmnEsesuzioni_RendiCOMP.Index = 2;
			this.cmnEsesuzioni_RendiCOMP.Text = "Rendi COMP";
			this.cmnEsesuzioni_RendiCOMP.Click += new System.EventHandler(this.cmnEsesuzioni_RendiCOMP_Click);
			// 
			// cmnEsesuzioni_Abort
			// 
			this.cmnEsesuzioni_Abort.Index = 4;
			this.cmnEsesuzioni_Abort.Text = "Abortisci esecuzione";
			this.cmnEsesuzioni_Abort.Click += new System.EventHandler(this.cmnEsesuzioni_Abort_Click);
			// 
			// cmnEsesuzioni_RendiERR
			// 
			this.cmnEsesuzioni_RendiERR.Index = 3;
			this.cmnEsesuzioni_RendiERR.Text = "Rendi ERR";
			this.cmnEsesuzioni_RendiERR.Click += new System.EventHandler(this.cmnEsesuzioni_RendiERR_Click);
			// 
			// ControlloEsecuzione
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(592, 273);
			this.Controls.Add(this.dgEsecuzioni);
			this.Name = "ControlloEsecuzione";
			this.Text = "ControlloEsecuzione";
			this.Load += new System.EventHandler(this.ControlloEsecuzione_Load);
			((System.ComponentModel.ISupportInitialize)(this.dgEsecuzioni)).EndInit();
			this.ResumeLayout(false);

		}

		#endregion

		private DataSet _ds;
		private CurrencyManager _cmEsecuzioni;

		//private delegate DataSet IAlgoRis_ReadListaEsecuzioniDelegate(DateTime flowDate, int flowHour, string codiceMercato, string statoEsecuzioneOra, int progressivoEsecuzione);

		private void ControlloEsecuzione_Load(object sender, EventArgs e)
		{
			//	this._AggiornaDataSetSink = new AggiornaDataSetDelegate(this.AggiornaDataSet);

			dgEsecuzioni.CaptionText = "Esecuzioni";
			dgEsecuzioni.AllowNavigation = false;
			dgEsecuzioni.ReadOnly = true;


			try
			{
				IAlgoRis a = (IAlgoRis) RemotingHelper.GetObject(typeof (IAlgoRis));

				// TODO LEO mettere calendario e filtrare la query con solo le esecuzioni che interessano
				DataSet ds = a.ReadListaEsecuzioni(DateTime.MinValue, -1, null, null, -1);
				AggiornaDataSet(ds);

				timer1.Interval = 5000;
				timer1.Enabled = true;
				//timer1.Start();
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

//		private delegate void AggiornaDataSetDelegate(DataSet ds);
//		private AggiornaDataSetDelegate _AggiornaDataSetSink;
//		private void ASyncResultListaEsecuzioni(IAsyncResult rs)
//		{
//			IAlgoRis_ReadListaEsecuzioniDelegate del;
//			del = (IAlgoRis_ReadListaEsecuzioniDelegate) rs.AsyncState;
//			DataSet ds = del.EndInvoke(rs);
//			this.Invoke(this._AggiornaDataSetSink, new object[] {ds});
//		}


		private void AggiornaDataSet(DataSet ds)
		{
			_ds = ds;

			DataView dvEsecuzioni = new DataView(_ds.Tables[0]);
			dvEsecuzioni.AllowDelete = false;
			dvEsecuzioni.AllowNew = false;
			dvEsecuzioni.AllowEdit = false;

			dgEsecuzioni.DataSource = null;
			dgEsecuzioni.DataSource = dvEsecuzioni;

			dvEsecuzioni.Sort = "FlowDate";
			Debug.Assert(this.BindingContext.Contains(dvEsecuzioni));
			_cmEsecuzioni = (CurrencyManager) this.BindingContext[dvEsecuzioni];
			_cmEsecuzioni.CurrentChanged += new EventHandler(_cmEsecuzioni_CurrentChanged);
			dvEsecuzioni.ListChanged += new ListChangedEventHandler(dvEsecuzioni_ListChanged);

			RowFilter_Esecuzioni();
			SetDataGridMappingEsecuzioni(ds.Tables[0].TableName);
		}

		private void RowFilter_Esecuzioni()
		{
			if (_cmEsecuzioni == null)
				return;

			DataView dv = _cmEsecuzioni.List as DataView;

			string s = string.Empty;

//			switch (cbMovimentiFilter.SelectedIndex)
//			{
//				case 0:
//					s = string.Empty;
//					break;
//				case 1:
//					s = "SocietaSrc_RagioneSociale LIKE '" + txtMovimentiFilter.Text + "%'";
//					break;
//				case 2:
//					s = "SocietaSrc_CodiceConto LIKE '" + txtMovimentiFilter.Text + "%'";
//					break;
//				case 3:
//					s = "SocietaDst_RagioneSociale LIKE '" + txtMovimentiFilter.Text + "%'";
//					break;
//				case 4:
//					s = "SocietaDst_CodiceConto LIKE '" + txtMovimentiFilter.Text + "%'";
//					break;
//				default:
//					Debug.Assert(false);
//					s = string.Empty;
//					break;
//			}
//
//			if (chkboxVisualizzaAnchePerfezionati.Checked == false)
//			{
//				if (s.Length > 0)
//					s += " And TSPerfezionato Is Null";
//				else
//					s = "TSPerfezionato Is Null";
//			}

			dv.RowFilter = s;
		}


		private void SetDataGridMappingEsecuzioni(string tableName)
		{
			if (dgEsecuzioni.TableStyles.Contains(tableName))
				return;

			DataGridTableStyle dgStyle = new DataGridTableStyle();
			dgStyle.MappingName = tableName; // nome della tabella a cui si riferisce questa DataGridTableStyle
			dgStyle.AllowSorting = true;

			DataGridTextBoxColumn dgc;

			dgc = new DataGridTextBoxColorColumn();
			dgc.HeaderText = "Stato";
			dgc.MappingName = "StatoEsecuzioneOra";
			dgc.Width = 50;
			dgStyle.GridColumnStyles.Add(dgc);

			dgc = new DataGridTextBoxColumn();
			dgc.HeaderText = "Data di flusso";
			dgc.MappingName = "FlowDate";
			dgc.Width = 100;
			dgStyle.GridColumnStyles.Add(dgc);

			dgc = new DataGridTextBoxColumn();
			dgc.HeaderText = "Ora";
			dgc.MappingName = "Ora";
			dgc.Width = 40;
			dgStyle.GridColumnStyles.Add(dgc);


			dgc = new DataGridTextBoxColumn();
			dgc.HeaderText = "Mercato";
			dgc.MappingName = "CodiceMercato";
			dgc.Width = 70;
			dgStyle.GridColumnStyles.Add(dgc);

			dgc = new DataGridTextBoxColumn();
			dgc.HeaderText = "Progressivo esecuzione";
			dgc.MappingName = "ProgressivoEsecuzione";
			dgc.Width = 130;
			dgStyle.GridColumnStyles.Add(dgc);


			dgc = new DataGridTextBoxColumn();
			dgc.HeaderText = "Inizio esecuzione";
			dgc.MappingName = "DataOraInizioEsecuzioneOra";
			dgc.Width = 100;
			dgc.Format = "g";
			dgStyle.GridColumnStyles.Add(dgc);

			dgc = new DataGridTextBoxColumn();
			dgc.HeaderText = "Fine esecuzione";
			dgc.MappingName = "DataOraFineEsecuzioneOra";
			dgc.Width = 100;
			dgc.Format = "g";
			dgc.NullText = "";
			dgStyle.GridColumnStyles.Add(dgc);

			dgc = new DataGridTextBoxColumn();
			dgc.HeaderText = "IdElaborazione";
			dgc.MappingName = "IdElaborazione";
			dgc.Width = 200;
			dgStyle.GridColumnStyles.Add(dgc);

			dgEsecuzioni.TableStyles.Add(dgStyle);
		}

		private void _cmEsecuzioni_CurrentChanged(object sender, EventArgs e)
		{
			// questo viene chiamato sia quando 
			// a) si cambia la > a sin. della dg
			// b) quando si fa sort.
			// c) quando si fa il RowFilter.

			DataRow dr = dgEsecuzione_GetDataRowCorrente();

			// MessageBox.Show(dr["FlowDate"].ToString());


		}

		private void dvEsecuzioni_ListChanged(object sender, ListChangedEventArgs e)
		{
			// la lista del DataView (la lista poi tramite Row punta ai DataRow)
			// e' cambiata a fronte di un sort, rowfilter

			DataRow dr = dgEsecuzione_GetDataRowCorrente();
		}


		private DataRow dgEsecuzione_GetDataRowCorrente()
		{
			if (_cmEsecuzioni.Count == 0)
				return null;

			DataView dv = (DataView) _cmEsecuzioni.List;
			DataRow dr = dv[_cmEsecuzioni.Position].Row;
			return dr;
		}


		private void dgEsecuzioni_MouseUp(object sender, MouseEventArgs e)
		{
			DataGrid.HitTestInfo hti = this.dgEsecuzioni.HitTest(e.X, e.Y);
			try
			{
				if (hti.Type == DataGrid.HitTestType.Cell)
				{
//					if (dgEsecuzioni.TableStyles["Esecuzioni"].GridColumnStyles[hti.Column] is DataGridBoolColumn)
//					{
//						this.dgEsecuzioni[hti.Row, hti.Column] = ! (bool) this.dgEsecuzioni[hti.Row, hti.Column];
//					}
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.ToString());
			}
		}

		private void timer1_Tick(object sender, EventArgs e)
		{
			timer1.Stop();
			try
			{
				IAlgoRis a = (IAlgoRis) RemotingHelper.GetObject(typeof (IAlgoRis));
				DataSet ds = a.ReadListaEsecuzioni(DateTime.MinValue, -1, null, null, -1);

				MergeDataSet(ds.Tables[0], _ds.Tables[0]);
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}

			timer1.Start();
		}

		/// <summary>
		/// Meravigliosa funzione che aggiorna il dtDst con i dati provenienti dal un dtSrc.
		/// Serve per evitare che il data grid sfarfalli.
		/// </summary>
		/// <param name="dtSrc"></param>
		/// <param name="dtDst"></param>
		private static void MergeDataSet(DataTable dtSrc, DataTable dtDst)
		{
			ArrayList ar = new ArrayList();

			foreach (DataRow drSrc in dtSrc.Rows)
			{
				bool trovato = false;

				foreach (DataRow drDst in dtDst.Rows)
				{
					trovato = IsSamePrimaryKey(drSrc, drDst);
					if (trovato)
					{
						CopyData(drSrc, drDst);
						break;
					}
				}

				if (trovato == false)
				{
					// drSrc non esiste in dtDst --> lo aggiungo
					DataRow drDst = dtDst.NewRow();
					CopyData(drSrc, drDst);
					dtDst.Rows.Add(drDst);
				}
			}


			bool cancellato;
			do
			{
				cancellato = false;
				foreach (DataRow drDst in dtDst.Rows)
				{
					bool trovato = false;
					foreach (DataRow drSrc in dtSrc.Rows)
					{
						trovato = IsSamePrimaryKey(drSrc, drDst);
						if (trovato)
							break;

					}
					if (trovato == false)
					{
						// un record in drDst non esiste in drSrc --> lo cancello
						dtDst.Rows.Remove(drDst);
						cancellato = true;
						break;
					}
				}
			} while (cancellato);
		}

		private static bool IsPrimaryKeyColumn(DataColumn col)
		{
			foreach (DataColumn pk in col.Table.PrimaryKey)
			{
				if (pk == col) return true;
			}
			return false;
		}

		private static bool IsSamePrimaryKey(DataRow a, DataRow b)
		{
			DataColumn[] pkA = a.Table.PrimaryKey;
			DataColumn[] pkB = b.Table.PrimaryKey;

			for (int i = 0; i < pkA.Length; ++ i)
			{
				object ao = a[pkA[i]];
				object bo = b[pkB[i]];

				if (ao.Equals(bo) == false)
					return false;
			}

			return true;
		}


		private static void CopyData(DataRow src, DataRow dst)
		{
			DataTable dtSrc = dst.Table;

			for (int i = 0; i < dtSrc.Columns.Count; ++i)
			{
				if (IsPrimaryKeyColumn(dtSrc.Columns[i]) == false)
				{
					object oSrc = src[i];
					object oDst = dst[i];

					if (oSrc.Equals(oDst) == false)
					{
						if (src.IsNull(i))
							dst[i] = DBNull.Value;
						else
							dst[i] = src[i];
					}
				}
			}

		}

		private void dgEsecuzioni_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			DataGrid.HitTestInfo ht = dgEsecuzioni.HitTest(e.X, e.Y); 

			// questo serve per togliere selezioni multiple
			// e impostare la riga corrente 
			if (ht.Type == DataGrid.HitTestType.Cell || ht.Type == DataGrid.HitTestType.RowHeader)
			{
				for (int i = 0; i < _cmEsecuzioni.Count; ++i)
					if (dgEsecuzioni.IsSelected(i))
						dgEsecuzioni.UnSelect(i);

				dgEsecuzioni.CurrentCell = new DataGridCell(ht.Row, ht.Column);
				dgEsecuzioni.CurrentRowIndex = ht.Row;
			}

			// menu` contestuale
			if (e.Button == MouseButtons.Right && 
				(ht.Type == DataGrid.HitTestType.Cell || ht.Type == DataGrid.HitTestType.RowHeader))
			{

				DataRow dr = dgEsecuzione_GetDataRowCorrente();
				if (dr != null)
				{
					string statoEsecuzione = (string)dr["StatoEsecuzioneOra"];

					cmnEsesuzioni_RendiPROV.Enabled = statoEsecuzione == "HBMR";
					cmnEsesuzioni_RendiCOMP.Enabled = statoEsecuzione == "PROV";
					cmnEsesuzioni_RendiERR.Enabled = statoEsecuzione == "HBMR";
					cmnEsesuzioni_Abort.Enabled = statoEsecuzione == "RUN";
					cmnEsesuzioni_StudiaRisultati.Enabled = statoEsecuzione != "RUN";

					dgEsecuzioni.ContextMenu = cmnEsesuzioni;
				}
				else
					dgEsecuzioni.ContextMenu = null;
			}
			else
				dgEsecuzioni.ContextMenu = null;
	
		}

		private void cmnEsesuzioni_StudiaRisultati_Click(object sender, System.EventArgs e)
		{
			DataRow dr = dgEsecuzione_GetDataRowCorrente();
			DateTime flowDate = (DateTime) dr["FlowDate"];
			byte ora = (byte) dr["Ora"];
			string codiceMercato = (string) dr["CodiceMercato"];
			int progressivoEsecuzione = (int)dr["ProgressivoEsecuzione"];

			Cursor.Current = Cursors.WaitCursor;
			
			IAlgoRis a = (IAlgoRis) RemotingHelper.GetObject(typeof (IAlgoRis));
			byte [] bz = a.ReadBlobRisultatoAlgoritmo(flowDate, ora, codiceMercato, progressivoEsecuzione);
			if (bz == null)
			{
				MessageBox.Show("Risultato non disponibile", "Risultato elaborazione");
				return;
			}

			string fileName;
			byte [] b = GME.Zip.ZipFile.UnzipSingleFile(bz, out fileName);

			string xml = Encoding.UTF8.GetString(b);

			MessageBox.Show(xml);
		}

		private void cmnEsesuzioni_RendiPROV_Click(object sender, System.EventArgs e)
		{
			DataRow dr = dgEsecuzione_GetDataRowCorrente();
			DateTime flowDate = (DateTime) dr["FlowDate"];
			byte ora = (byte) dr["Ora"];
			string codiceMercato = (string) dr["CodiceMercato"];
			int progressivoEsecuzione = (int)dr["ProgressivoEsecuzione"];

			Cursor.Current = Cursors.WaitCursor;
			
			IAlgoRis a = (IAlgoRis) RemotingHelper.GetObject(typeof (IAlgoRis));
			a.RendiProvRisultato(flowDate, ora, codiceMercato, progressivoEsecuzione);
		}

		private void cmnEsesuzioni_RendiCOMP_Click(object sender, System.EventArgs e)
		{
		
			DataRow dr = dgEsecuzione_GetDataRowCorrente();
			DateTime flowDate = (DateTime) dr["FlowDate"];
			byte ora = (byte) dr["Ora"];
			string codiceMercato = (string) dr["CodiceMercato"];
			int progressivoEsecuzione = (int)dr["ProgressivoEsecuzione"];

			Cursor.Current = Cursors.WaitCursor;
			
			IAlgoRis a = (IAlgoRis) RemotingHelper.GetObject(typeof (IAlgoRis));
			a.RendiCompRisultato(flowDate, ora, codiceMercato, progressivoEsecuzione);
		}

		private void cmnEsesuzioni_Abort_Click(object sender, System.EventArgs e)
		{
			DataRow dr = dgEsecuzione_GetDataRowCorrente();
			DateTime flowDate = (DateTime) dr["FlowDate"];
			byte ora = (byte) dr["Ora"];
			string codiceMercato = (string) dr["CodiceMercato"];
			int progressivoEsecuzione = (int)dr["ProgressivoEsecuzione"];

			Cursor.Current = Cursors.WaitCursor;
			
			IAlgoRis a = (IAlgoRis) RemotingHelper.GetObject(typeof (IAlgoRis));
			a.AbortEsecuzione(flowDate, ora, codiceMercato, progressivoEsecuzione) ;
		}

		private void cmnEsesuzioni_RendiERR_Click(object sender, System.EventArgs e)
		{
			DataRow dr = dgEsecuzione_GetDataRowCorrente();
			DateTime flowDate = (DateTime) dr["FlowDate"];
			byte ora = (byte) dr["Ora"];
			string codiceMercato = (string) dr["CodiceMercato"];
			int progressivoEsecuzione = (int)dr["ProgressivoEsecuzione"];

			Cursor.Current = Cursors.WaitCursor;
			
			IAlgoRis a = (IAlgoRis) RemotingHelper.GetObject(typeof (IAlgoRis));
			a.RendiErrRisultato(flowDate, ora, codiceMercato, progressivoEsecuzione);
		}
	}


	class DataGridTextBoxColorColumn : DataGridTextBoxColumn 
	{
		protected override void Paint(Graphics g, Rectangle bounds, CurrencyManager cm, 
			int rowNum, Brush backBrush, Brush foreBrush, bool alignToRight) 
		{ 
			try
			{
				// this.TextBox.Font.Bold = true;
				DataView dv = (DataView)cm.List;
				DataRow dr = dv[rowNum].Row;

				string id = (string)dr[this.MappingName];
				switch (id.ToUpper())
				{
					case "RUN":
						foreBrush = _rosso;
						break;

					case "HBMR":
						foreBrush = _marrone;
						break;

					case "ERR":
						foreBrush = _grigio;
						break;

					case "PROV":
						foreBrush = _blu;
						break;

					case "COMP":
						foreBrush = _verde;
						break;
				}
			}
			catch (Exception Ex)
			{
				string s = Ex.Message;
			}

			base.Paint(g, bounds, cm, rowNum, backBrush, foreBrush, alignToRight);
		}
		static Brush _rosso = new SolidBrush(Color.Red);
		static Brush _grigio  = new SolidBrush(Color.DarkGray);
		static Brush _marrone  = new SolidBrush(Color.Brown);
		static Brush _blu  = new SolidBrush(Color.CadetBlue);
		static Brush _verde  = new SolidBrush(Color.DarkGreen);
	}
}