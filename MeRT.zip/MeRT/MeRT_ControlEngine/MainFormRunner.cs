using System;
using System.Runtime.Remoting;
using System.Windows.Forms;
using GME.Remoting;
using MeRT_IBL;

namespace MeRT_ControlEngine
{
	public class MainFormRunner
	{
		public MainFormRunner()
		{
		}

		public void Run(string configFileXml)
		{
			try 
			{

				Application.EnableVisualStyles();

				GME.Utility.AppSettings.LoadAlternateConfigFile(configFileXml);

				RemotingConfiguration.Configure(configFileXml);

				string f = GME.Utility.AppSettings.ToString("RemOpChannel_DefaultServer");
				RemConfig.ClientConfig(f);

				Application.Run(new EngineMainForm());

			} 
			catch (Exception e)
			{
				MessageBox.Show(e.StackTrace);
			}
		}


	}

}