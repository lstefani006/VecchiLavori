using System;
using System.ComponentModel;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Web.Services;
using System.Web.Services.Description;
using System.Web.Services.Protocols;
using System.Xml;
using System.Xml.Serialization;

namespace MeRT_Algo
{

	[WebService(Namespace="http://mercatoelettrico.org/MeRT_Algo/Algo")]
	[System.Web.Services.WebServiceBindingAttribute(Name="AlgoSoap", Namespace="http://mercatoelettrico.org/MeRT_Algo/Algo")]
	public class Algo : AlgoStub 
	{
        
		/// <remarks/>
		[System.Web.Services.WebMethodAttribute()]
		[System.Web.Services.Protocols.SoapDocumentMethodAttribute("http://mercatoelettrico.org/MeRT_Algo/Algo/Elabora", RequestNamespace="http://mercatoelettrico.org/MeRT_Algo/Algo", ResponseNamespace="http://mercatoelettrico.org/MeRT_Algo/Algo", Use=System.Web.Services.Description.SoapBindingUse.Literal, ParameterStyle=System.Web.Services.Protocols.SoapParameterStyle.Wrapped)]
		public override void Elabora(DatiElaborazione datiElaborazione)
		{
			RandomRT rt = new RandomRT();
			RandomRT.ElaboraDelegate del = new RandomRT.ElaboraDelegate(rt.Elabora);
			IAsyncResult rs = del.BeginInvoke(datiElaborazione, null, null);
			Application.Add(datiElaborazione.idElaborazione, rs);
		}
        
		/// <remarks/>
		[System.Web.Services.WebMethodAttribute()]
		[System.Web.Services.Protocols.SoapDocumentMethodAttribute("http://mercatoelettrico.org/MeRT_Algo/Algo/ElaborazioneCompletata", RequestNamespace="http://mercatoelettrico.org/MeRT_Algo/Algo", ResponseNamespace="http://mercatoelettrico.org/MeRT_Algo/Algo", Use=System.Web.Services.Description.SoapBindingUse.Literal, ParameterStyle=System.Web.Services.Protocols.SoapParameterStyle.Wrapped)]
		public override bool ElaborazioneCompletata(string idElaborazione)
		{
			IAsyncResult rs = (IAsyncResult) Application.Get(idElaborazione);
			if (rs == null) throw new ArgumentException("IdElaborazione", "Non esiste una elaborazione con questo identificatore");
			return rs.IsCompleted;
		}
        
		/// <remarks/>
		[System.Web.Services.WebMethodAttribute()]
		[System.Web.Services.Protocols.SoapDocumentMethodAttribute("http://mercatoelettrico.org/MeRT_Algo/Algo/RisultatiElaborazione", RequestNamespace="http://mercatoelettrico.org/MeRT_Algo/Algo", ResponseNamespace="http://mercatoelettrico.org/MeRT_Algo/Algo", Use=System.Web.Services.Description.SoapBindingUse.Literal, ParameterStyle=System.Web.Services.Protocols.SoapParameterStyle.Wrapped)]
		public override DatiElaborazione RisultatiElaborazione(string idElaborazione)
		{
			IAsyncResult rs = (IAsyncResult) Application.Get(idElaborazione);
			if (rs == null) throw new ArgumentException("IdElaborazione", "Non esiste una elaborazione con questo identificatore");
			Application.Remove(idElaborazione);

			if (!rs.IsCompleted) throw new Exception("Elaborazione non completata");

			RandomRT.ElaboraDelegate del = (RandomRT.ElaboraDelegate) ((AsyncResult) rs).AsyncDelegate;

			DatiElaborazione r = del.EndInvoke(rs);
#if DEBUG
			if (true)
			{
				XmlSerializer x = new XmlSerializer(typeof (DatiElaborazione));
				XmlTextWriter xw = new XmlTextWriter(@"c:\ri.xml", Encoding.UTF8);
				xw.Formatting = Formatting.Indented;
				xw.IndentChar = '\t';
				xw.Indentation = 1;
				x.Serialize(xw, r);
				xw.Close();
			}
#endif

			return r;
		}
	}


	/*
	/// <remarks/>
	[WebService(
		Namespace="http://mercatoelettrico.org/MeRT_Algo/Algo",
		Description="Algoritmo di risoluzione del mercato elettrico")]
	[WebServiceBinding(Name="AlgoSoap", Namespace="http://mercatoelettrico.org/MeRT_Algo/Algo")]
	public class Algo : WebService
	{
		/// <remarks/>
		[WebMethod()]
		[SoapDocumentMethod("http://mercatoelettrico.org/MeRT_Algo/Algo/Elabora", RequestNamespace="http://mercatoelettrico.org/MeRT_Algo/Algo", ResponseNamespace="http://mercatoelettrico.org/MeRT_Algo/Algo", Use=SoapBindingUse.Literal, ParameterStyle=SoapParameterStyle.Wrapped)]
		public void Elabora([XmlElement(Namespace="urn:XML-AlgoData")] DatiElaborazione datiElaborazione)
		{
			RandomRT rt = new RandomRT();
			RandomRT.ElaboraDelegate del = new RandomRT.ElaboraDelegate(rt.Elabora);
			IAsyncResult rs = del.BeginInvoke(datiElaborazione, null, null);
			Application.Add(datiElaborazione.idElaborazione, rs);
		}

		/// <remarks/>
		[WebMethod()]
		[SoapDocumentMethod("http://mercatoelettrico.org/MeRT_Algo/Algo/ElaborazioneCompletata", RequestNamespace="http://mercatoelettrico.org/MeRT_Algo/Algo", ResponseNamespace="http://mercatoelettrico.org/MeRT_Algo/Algo", Use=SoapBindingUse.Literal, ParameterStyle=SoapParameterStyle.Wrapped)]
		public bool ElaborazioneCompletata(string IdElaborazione)
		{
			IAsyncResult rs = (IAsyncResult) Application.Get(IdElaborazione);
			if (rs == null) throw new ArgumentException("IdElaborazione", "Non esiste una elaborazione con questo identificatore");
			return rs.IsCompleted;
		}

		/// <remarks/>
		[WebMethod()]
		[SoapDocumentMethod("http://mercatoelettrico.org/MeRT_Algo/Algo/RisultatiElaborazione", RequestNamespace="http://mercatoelettrico.org/MeRT_Algo/Algo", ResponseNamespace="http://mercatoelettrico.org/MeRT_Algo/Algo", Use=SoapBindingUse.Literal, ParameterStyle=SoapParameterStyle.Wrapped)]
		[return : XmlElement("RisultatoElaborazione", Namespace="urn:XML-AlgoData")]
		public RisultatoElaborazione RisultatiElaborazione(string IdElaborazione)
		{
			IAsyncResult rs = (IAsyncResult) Application.Get(IdElaborazione);
			if (rs == null) throw new ArgumentException("IdElaborazione", "Non esiste una elaborazione con questo identificatore");
			Application.Remove(IdElaborazione);

			if (!rs.IsCompleted) throw new Exception("Elaborazione non completata");

			RandomRT.ElaboraDelegate del = (RandomRT.ElaboraDelegate) ((AsyncResult) rs).AsyncDelegate;

			RisultatoElaborazione r = del.EndInvoke(rs);

			if (true)
			{
				XmlSerializer x = new XmlSerializer(typeof (RisultatoElaborazione));
				XmlTextWriter xw = new XmlTextWriter(@"c:\ri.xml", Encoding.UTF8);
				xw.Formatting = Formatting.Indented;
				xw.IndentChar = '\t';
				xw.Indentation = 1;
				x.Serialize(xw, r);
				xw.Close();
			}

			return r;
		}
	}
	*/
}