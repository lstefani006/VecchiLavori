using System;
using System.Threading;

namespace MeRT_Algo
{
	/// <summary>
	/// Summary description for RandomRT.
	/// </summary>
	public class RandomRT
	{
		public RandomRT()
		{
		}

		public delegate DatiElaborazione ElaboraDelegate(DatiElaborazione de);

		public DatiElaborazione Elabora(DatiElaborazione de)
		{
			Thread.Sleep(1000 * 2);

			Random rnd = new Random(0);

			DatiElaborazione r = new DatiElaborazione();
			r.idElaborazione = de.idElaborazione;
			r.Version = de.Version;
			r.statoElaborazione = StatoElaborazione.Ottima;

			r.prezzoUnico = 50;
			r.prezzoUnconstrained = 51;
			r.quantitaUnconstrained = 100;

			int nz = de.Zona.Length;
			r.Zona = new  Zona[nz];
			for (int i = 0; i < nz; ++i)
			{
				r.Zona[i] = new Zona();
				r.Zona[i].codiceZona = de.Zona[i].codiceZona;
				r.Zona[i].prezzoZonale = 50 + (rnd.Next() - 0.5) * 20;
			}



			nz = de.Zona.Length;
			r.VincoloInterzonale = new VincoloInterzonale[nz];
			for (int i = 0; i < nz; ++i)
			{
				r.VincoloInterzonale[i] = new VincoloInterzonale();

				r.VincoloInterzonale[i].daZona = de.Zona[(i+0) % nz].codiceZona;
				r.VincoloInterzonale[i].aZona = de.Zona[(i+1) % nz].codiceZona;
				r.VincoloInterzonale[i].flusso = 100 + (rnd.Next() - 0.5) * 20;
				r.VincoloInterzonale[i].renditaDiCongestione = 70 + (rnd.Next() - 0.5) * 20;
			}

			int no = de.OffertaVendita.Length;
			r.OffertaVendita = new OffertaVendita[no];
			for (int i = 0; i < nz; ++i)
			{
				r.OffertaVendita[i] = new OffertaVendita();
				r.OffertaVendita[i].idOfferta = de.OffertaVendita[i].idOfferta;
				r.OffertaVendita[i].prezzoAssegnato = de.OffertaVendita[i].prezzo;
				r.OffertaVendita[i].quantitaAssegnataMWh = de.OffertaVendita[i].quantitaMWh;
			}


			no = de.OffertaAcquisto.Length;
			r.OffertaAcquisto = new OffertaAcquisto[no];
			for (int i = 0; i < no; ++i)
			{
				r.OffertaAcquisto[i] = new OffertaAcquisto();

				r.OffertaAcquisto[i].idOfferta = de.OffertaAcquisto[i].idOfferta;
				r.OffertaAcquisto[i].prezzoAssegnato = de.OffertaAcquisto[i].prezzo;
				r.OffertaAcquisto[i].quantitaAssegnataMWh = de.OffertaAcquisto[i].quantitaMWh;
			}


			/*
			r.RisultatoElaborazioneNote = new RisultatoElaborazioneNote[2];
			r.RisultatoElaborazioneNote[0] = new RisultatoElaborazioneNote();
			r.RisultatoElaborazioneNote[0].Value = "Durata elaborazione 12'";
			r.RisultatoElaborazioneNote[1] = new RisultatoElaborazioneNote();
			r.RisultatoElaborazioneNote[1].idOfferta = de.OffertaAcquisto[0].idOfferta;
			r.RisultatoElaborazioneNote[1].Value = "Durata elaborazione 12'";
			*/

			return r;
		}
	}
}
