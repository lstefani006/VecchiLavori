using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;


namespace MeRT_ControlWS
{
	/// <summary>
	/// Summary description for Deploy.
	/// </summary>
	[WebService(Namespace="http://mercatoelettrico.org/MeRT_ControlWS/Deploy")]
	public class Deploy : GME.WSBase 
	{
		public Deploy()
		{
			InitializeComponent();
		}

		#region Component Designer generated code
		
		//Required by the Web Services Designer 
		private IContainer components = null;
				
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if(disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);		
		}
		
		#endregion

		[WebMethod(EnableSession=true)]
		[SoapHeader("authHeader")]
		public void Ping()
		{
			base.CheckAuth();

			try
			{
			}
			catch (Exception ex)
			{
				smError(ex);
			}
		}


		[WebMethod(EnableSession=true)]
		[SoapHeader("authHeader")]
		public byte [] DownloadFile(string fn, DateTime tsLastWriteTime, out DateTime tsServerTime)
		{
			base.CheckAuth();

			try
			{
				string p = Server.MapPath("./MeRT_ControlEngine");

				string pathFn = p + "/" + fn;

				tsServerTime = DateTime.MinValue;

				if (File.Exists(pathFn))
				{
					// se il file nella directory MeRT_ControlEngine
					// e` piu` vecchio del file che hanno nel computer remoto
					// non ritorno niente.
					tsServerTime = File.GetLastWriteTime(pathFn);
					if (tsServerTime == tsLastWriteTime)
						return null;
				}

				using (FileStream f = File.OpenRead(pathFn))
				{
					byte [] r = new byte[f.Length];
					f.Read(r, 0, (int)f.Length);
					return r;
				}
			}
			catch (Exception ex)
			{
				smError(ex);
				throw;
			}
		}
	}
}
