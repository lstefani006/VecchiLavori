using System;
using System.Web.Services.Protocols;
using System.Web;
using System.Configuration;
using System.Collections.Specialized;
using System.Security.Cryptography.X509Certificates;

namespace Host.Web.ServerSecurity
{
	/// <summary>
	/// Summary description for WSServerCheckCertificate.
	/// </summary>
	public class WSServerCheckCertificate
	{
		//
		// Funzione chiamabile direttamente da Web Service per il controllo del certificato
		// se il certificato non e' abilitato effettua il throw di una eccezione
		//
		public static void CheckClientCertificate(System.Web.HttpRequest request)
		{
			X509Certificate xCert = new X509Certificate(request.ClientCertificate.Certificate);
			if (CheckClientCertificate(xCert) == false)
			{
				throw new AuthenticationException("Certificato Issuer = [" + xCert.GetIssuerName() + "] Serial Number = [" + xCert.GetSerialNumberString() + "] Non Abilitato");
			}
		}

		#region Implementation
		private static bool CheckClientCertificate(X509Certificate xCert)
		{
			//
			// ottieni il numero di certificati abilitati 
			//
			string sAllowedCertificate = ConfigurationSettings.AppSettings["CertificateAllowed_Count"];
			int countAllowedCertificate = 0;
			try
			{
				countAllowedCertificate = int.Parse(sAllowedCertificate);
			}
			catch
			{
			}
			//
			// controlla se il certificato in input sta nella lista dei certificati abilitati
			//
			for (int i = 0; i < countAllowedCertificate; i++)
			{
				string CertIssuer = ConfigurationSettings.AppSettings["CertificateAllowed_Issuer_" + i.ToString()];
				string CertSN = ConfigurationSettings.AppSettings["CertificateAllowed_SN_" + i.ToString()];
				if ((CertIssuer == xCert.GetIssuerName()) && (CertSN == xCert.GetSerialNumberString()))
				{
					return true;
				}
			}
			return false;
		}
		#endregion
	}
}
