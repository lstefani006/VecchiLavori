namespace Host.Utility
{
	class AppSettings
	{
		public static int ToInt32(string s, int defaultValue)
		{
			string v = System.Configuration.ConfigurationSettings.AppSettings[s];
			if (v == null)
				return defaultValue;
			try
			{
				return int.Parse(s);
			}
			catch
			{
			}
			return defaultValue;
		}

		public static string ToString(string s, string defaultValue)
		{
			string v = System.Configuration.ConfigurationSettings.AppSettings[s];
			if (v != null)
				return v;
			return defaultValue;
		}
		public static bool ToBoolean(string s)
		{
			return ToBoolean(s, true);
		}
		public static  bool ToBoolean(string s, bool defaultValue)
		{
			string v = System.Configuration.ConfigurationSettings.AppSettings[s];
			if (v != null)
			{
				v = v.ToLower();
				switch (v)
				{
					case "1":
					case "si":
					case "s":
					case "yes":
					case "y":
					case "true":
					case "t":
					case "vero":
					case "v":
						return true;

					case "0":
					case "no":
					case "n":
					case "false":
					case "f":
					case "falso":
						return false;

					default:
						return defaultValue;
				}
			}
			return defaultValue;
		}
	}
}
