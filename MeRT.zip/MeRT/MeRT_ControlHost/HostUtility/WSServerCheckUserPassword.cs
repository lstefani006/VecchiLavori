using System;
using System.Web.Services.Protocols;
using System.Web;
using System.Configuration;
using System.Collections.Specialized;

namespace Host.Web.ServerSecurity
{

	/// <summary>
	/// Summary description for WSServerCheckUserPassword.
	/// </summary>
	internal class WSServerCheckUserPassword
	{
		public static void CheckUserPassword(WSAuthHeader soapHeader)
		{
			if (soapHeader == null)
				throw new AuthenticationException("Autenticazione non fornita: utente non Abilitato");

			if (CheckUserPassword(soapHeader.Username, soapHeader.Password) == false)
				throw new AuthenticationException("UserName = [" + soapHeader.Username + "] Password = [" + soapHeader.Password + "] Non Abilitato");
		}

		#region Implementation
		private static bool CheckUserPassword(string user, string password)
		{
			//
			// ottieni il numero di utenti abilitati all'accesso
			//
			string sUsersAllowed = ConfigurationSettings.AppSettings["UserAllowed_Count"];
			int countUsersAllowed = 0;
			try
			{
				countUsersAllowed = int.Parse(sUsersAllowed);
			}
			catch
			{
			}
			//
			// controlla se l'utente e' compreso nella lista degli utenti abilitati
			//
			for (int i = 0; i < countUsersAllowed; i++)
			{
				string usI = ConfigurationSettings.AppSettings["UserName_" + i.ToString()];
				string passI = ConfigurationSettings.AppSettings["Password_" + i.ToString()];
				if ((user == usI) && (password == passI))
					return true;
			}
			return false;
		}
		#endregion
	}
}
