using System;
using System.Configuration;
using System.Diagnostics;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Net;
using System.Reflection;
using System.Threading;
using System.Windows.Forms;
using System.Xml;
using Host.Web.ClientSecurity;
using MeRT_ControlHost.ControlWS;

namespace MeRT_ControlHost
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class MainForm : Form
	{
		private static readonly string _appName = "MeRT_ControlEngine";
		private volatile static Assembly _ass = null;


		[STAThread]
		private static void Main()
		{
			SetupProxy();

			Application.Run(new MainForm());

			if (_ass != null)
				RunDowloadedAssemly();
		}

		private static void RunDowloadedAssemly()
		{
			Debug.Assert(_ass != null);
			string cf = AppDomain.CurrentDomain.SetupInformation.ConfigurationFile;
			string dc = Path.GetDirectoryName(cf) + "/Deploy";
			string configFile = dc + @"\" + _appName + ".xml";

			try
			{
				Type ty = _ass.GetType(_appName + ".MainFormRunner");
				ConstructorInfo ci = ty.GetConstructor(new Type[] {});
				object obj = ci.Invoke(new object[] {});
				ty.InvokeMember("Run", BindingFlags.Public | BindingFlags.InvokeMethod | BindingFlags.Instance, null, obj, new object[] {configFile});
			}
			catch (Exception ex2)
			{
				MessageBox.Show(ex2.Message);
			}
		}

		private static void SetupProxy()
		{
			string Proxy_User = ConfigurationSettings.AppSettings["Proxy_User"];
			string Proxy_Pwd = ConfigurationSettings.AppSettings["Proxy_Pwd"];
			string Proxy_Domain = ConfigurationSettings.AppSettings["Proxy_Domain"];

			if (Proxy_User != null && Proxy_Pwd != null &&
				Proxy_User.Length > 0 && Proxy_Pwd.Length > 0)
			{
				NetworkCredential nc = new NetworkCredential(Proxy_User, Proxy_Pwd);
				if (Proxy_Domain != null && Proxy_Domain.Length > 0)
					nc.Domain = Proxy_Domain;
				GlobalProxySelection.Select.Credentials = nc;
			}
			else
				GlobalProxySelection.Select.Credentials = CredentialCache.DefaultCredentials;
		}

		public MainForm()
		{
			InitializeComponent();
		}

		private Button btnCancella;
		private Label lblProgress;
		private ProgressBar pbDownloadPrg;
		private Label lblTitle;
		private Thread _th = null;
		private IContainer components;

		#region Windows Form Designer generated code

		protected override void Dispose(bool disposing)
		{
			if (disposing)
			{
				if (components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}


		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.btnCancella = new System.Windows.Forms.Button();
			this.lblProgress = new System.Windows.Forms.Label();
			this.lblTitle = new System.Windows.Forms.Label();
			this.pbDownloadPrg = new System.Windows.Forms.ProgressBar();
			this.SuspendLayout();
			// 
			// btnCancella
			// 
			this.btnCancella.Anchor = ((System.Windows.Forms.AnchorStyles) ((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.btnCancella.Location = new System.Drawing.Point(320, 112);
			this.btnCancella.Name = "btnCancella";
			this.btnCancella.TabIndex = 0;
			this.btnCancella.Text = "Cancella";
			this.btnCancella.Click += new System.EventHandler(this.btnCancella_Click);
			// 
			// lblProgress
			// 
			this.lblProgress.Anchor = ((System.Windows.Forms.AnchorStyles) ((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.lblProgress.Location = new System.Drawing.Point(8, 112);
			this.lblProgress.Name = "lblProgress";
			this.lblProgress.Size = new System.Drawing.Size(296, 23);
			this.lblProgress.TabIndex = 1;
			// 
			// lblTitle
			// 
			this.lblTitle.Anchor = ((System.Windows.Forms.AnchorStyles) (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
				| System.Windows.Forms.AnchorStyles.Right)));
			this.lblTitle.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte) (0)));
			this.lblTitle.Location = new System.Drawing.Point(8, 40);
			this.lblTitle.Name = "lblTitle";
			this.lblTitle.Size = new System.Drawing.Size(384, 23);
			this.lblTitle.TabIndex = 2;
			this.lblTitle.Text = "MeRTControl";
			this.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pbDownloadPrg
			// 
			this.pbDownloadPrg.Location = new System.Drawing.Point(8, 88);
			this.pbDownloadPrg.Maximum = 8;
			this.pbDownloadPrg.Minimum = 1;
			this.pbDownloadPrg.Name = "pbDownloadPrg";
			this.pbDownloadPrg.Size = new System.Drawing.Size(296, 16);
			this.pbDownloadPrg.TabIndex = 3;
			this.pbDownloadPrg.Value = 1;
			// 
			// MainForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(400, 141);
			this.Controls.Add(this.pbDownloadPrg);
			this.Controls.Add(this.lblTitle);
			this.Controls.Add(this.lblProgress);
			this.Controls.Add(this.btnCancella);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
			this.Name = "MainForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Downloading....";
			this.Load += new System.EventHandler(this.MainForm_Load);
			this.ResumeLayout(false);

		}

		#endregion

		#region Gestione della progress bar

		private delegate void ProgressDelegate(string strMsg);

		private ProgressDelegate m_ProgressDelegate;

		private void Progress(string strMsg)
		{
			try
			{
				if (this.InvokeRequired)
				{
					this.Invoke(m_ProgressDelegate, new object[] {strMsg});
					return;
				}

				lblProgress.Text = strMsg;
				pbDownloadPrg.Value++;
				lblProgress.Invalidate();
				lblProgress.Update();
			}
			catch
			{
			}
		}

		#endregion

		private void MainForm_Load(object sender, EventArgs e)
		{
			m_ProgressDelegate = new ProgressDelegate(this.Progress);
			m_GotAssemblyDelegate = new GotAssemblyDelegate(this.GotAssembly);

			_th = new Thread(new ThreadStart(QueryAssembly));
			_th.IsBackground = true;
			_th.Start();
		}

		private void btnCancella_Click(object sender, EventArgs e)
		{
			if (_th.IsAlive)
			{
				_th.Abort();

				MessageBox.Show(
					"Operazione abortita dall'operatore.\n" +
						"Il programma non puo' operare senza il completamento della fase di download",
					"Errore",
					MessageBoxButtons.OK, MessageBoxIcon.Stop);

				this.Close();
			}
			else
			{
				this.Close();
			}
		}

		// funzione chiamata nel thread di download
		private void QueryAssembly()
		{
			string dc;
			if (true)
			{
				string cf = AppDomain.CurrentDomain.SetupInformation.ConfigurationFile;
				dc = Path.GetDirectoryName(cf) + "/Deploy";
				if (Directory.Exists(dc) == false)
					Directory.CreateDirectory(dc);
			}

			try
			{
				Deploy ws = new Deploy();
				ws.WSAuthHeaderValue = new WSAuthHeader();
				WSClient.Setup(ws, ref ws.WSAuthHeaderValue.Username, ref ws.WSAuthHeaderValue.Password, "MeRT_ControlWS_Deploy", ConfigurationSettings.AppSettings);

				// per prima cosa faccio il download del file di configurazione dell'engine.
				string fileNameXml = dc + @"\" + _appName + ".xml";
				if (true)
				{
					this.Progress(_appName + ".xml");
					DateTime tsFileServerTime;
					byte[] data = ws.DownloadFile("MeRT_ControlEngine.xml", DateTime.MinValue, out tsFileServerTime);

					using (FileStream www = File.Create(fileNameXml))
					{
						www.Write(data, 0, data.Length);
						www.Close();
					}

					// converto le stringhe "localhost" con la stringha che si trova in "RemoteHost"
					string remoteHost = ConfigurationSettings.AppSettings["RemoteHost"];
					UpdageRemoteAddress(fileNameXml, remoteHost);
				}

				// determino la lista dei file da downloadare
				ArrayList filesToDownload = new ArrayList();
				if (true)
				{
					XmlDocument xd = new XmlDocument();
					xd.Load(fileNameXml);
					XmlNodeList nl = xd.DocumentElement.SelectNodes("./appSettings/add");

					foreach (XmlNode nn in nl)
					{
						string key = nn.Attributes.GetNamedItem("key").Value;
						if (key.StartsWith("Engine.Deploy_"))
						{
							string v = nn.Attributes.GetNamedItem("value").Value;
							filesToDownload.Add(v);
						}
					}
				}

				foreach (string fileToDownload in filesToDownload)
				{
					this.Progress(fileToDownload);

					DateTime tsLastWriteTime = DateTime.MinValue;
					if (File.Exists(dc + @"\" + fileToDownload))
						tsLastWriteTime = File.GetLastWriteTime(dc + @"\" + fileToDownload);

					DateTime tsFileServerTime;
					byte[] data = ws.DownloadFile(fileToDownload, tsLastWriteTime, out tsFileServerTime);

					if (data == null)
					{
						this.Progress(fileToDownload + ": yet updated");
#if ! DEBUG
						Thread.Sleep(300); // per dare il tempo all'utente di contemplare le scritte
#endif
						continue;
					}

					using (FileStream fs = File.Create(dc + @"\" + fileToDownload))
					{
						fs.Write(data, 0, data.Length);
						fs.Close();
					}
					File.SetLastWriteTime(dc + @"\" + fileToDownload, tsFileServerTime);

					this.Progress(fileToDownload + ": updated");
#if ! DEBUG
					Thread.Sleep(300); // per dare il tempo all'utente di contemplare le scritte
#endif
				}


				this.Progress("Loading assembly");

				_ass = Assembly.LoadFrom(dc + @"\" + _appName + ".dll");

				this.Progress("Deploy successfully");

				// se sono qui il download e' finito
#if ! DEBUG
				Thread.Sleep(1000); // do un po' di respiro al loop dei messaggi.
#endif
				this.GotAssembly(null) ;
			}
			catch (Exception ex)
			{
				// ho finito il download ma e' andato male
				// ==> spedisco l'eccezione rilevata al thread della finestra principale
				this.GotAssembly(ex);
			}
		}

		private static void UpdageRemoteAddress(string fileName, string remoteHost)
		{
			string contenutoFile = null;
			using (StreamReader www = File.OpenText(fileName))
			{
				contenutoFile = www.ReadToEnd();
				contenutoFile = contenutoFile.Replace("localhost", remoteHost);
			}

			using (StreamWriter www = File.CreateText(fileName))
			{
				www.Write(contenutoFile);
			}
		}

		internal delegate void GotAssemblyDelegate(Exception ex);

		private GotAssemblyDelegate m_GotAssemblyDelegate;

		private void GotAssembly(Exception ex)
		{
			if (this.InvokeRequired)
			{
				this.Invoke(m_GotAssemblyDelegate, new object[] {ex});
				return;
			}

			if (ex == null)
			{
				// download terminato con successo.

				if (_ass != null)
					this.Close();

				return;
			}

			Debug.Assert(ex != null);

			// ricerco nell'exception chain se e' stato interrotto il thread
			// con un Abort. Se si, evidentemente e' stato premuto cancel
			// e dunque non si deve presentare il messaggio di errore.
			bool bAbort = false;
			for (Exception ei = ex; ei != null; ei = ei.InnerException)
			{
				if (ei is ThreadAbortException)
				{
					bAbort = true;
					break;
				}
			}

			if (bAbort == false)
			{
				string msg = "Errore di collegamento al sito remoto.\n";
				msg += "Verificare la connessione ad Internet.\n\n";
				msg += ex.Message;

				MessageBox.Show(
					msg,
					"Errore fatale",
					MessageBoxButtons.OK, MessageBoxIcon.Stop);
			}

		}
	}

	public class DummyForm : Form
	{
		private Button _dummy1 = new Button();
		private Button _dummy2 = new Button();
		private GroupBox _dummyBox = new GroupBox();
		private RadioButton _dummy3 = new RadioButton();
		private RadioButton _dummy4 = new RadioButton();

		public DummyForm()
		{
			_dummy1.Text = "Button 1";
			_dummy1.Size = new Size(90,25);
			_dummy1.Location = new Point(10,10);

			_dummy2.Text = "Button 2";
			_dummy2.Size = new Size(90,25);
			_dummy2.Location = new Point(110,10);

			_dummyBox.Text = "Form GroupBox";
			_dummyBox.Size = new Size(125, 67);
			_dummyBox.Location = new Point(10, 45);

			_dummy3.Text = "RadioButton 3";
			_dummy3.Size = new Size(110,22);
			_dummy3.Location = new Point(10, 20);

			_dummy4.Text = "RadioButton 4";
			_dummy4.Size = new Size(110,22);
			_dummy4.Location = new Point(10, 42);
			_dummy4.Checked = true;

			_dummyBox.Controls.AddRange(new Control[]{_dummy3, _dummy4});

			Controls.AddRange(new Control[]{_dummy1, _dummy2, _dummyBox});

			this.Disposed += new EventHandler(OnFormDisposed);

			// Define then control to be selected when activated for first time
			this.ActiveControl = _dummy4;
		}

		protected void OnFormDisposed(object sender, EventArgs e)
		{   
			Console.WriteLine("OnFormDisposed");
		}
	}



}