using System;
using System.Collections.Specialized;
using System.Web.UI.WebControls;
using GME;

namespace MeRT_ViewWA
{
	/// <summary>
	/// Summary description for _default.
	/// </summary>
	public class Default : WebBase
	{
		protected TextBox txtRuoli;
		protected TextBox TextBox1;
	
		private void Page_Load(object sender, EventArgs e)
		{
			// Put user code to initialize the page here

			this.TextBox1.Text = User.Identity.Name;
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.ChangedRoles += new ChangedRolesDelegate(this.Default_ChangedRoles);
			this.Load += new EventHandler(this.Page_Load);

		}
		#endregion

		private void Default_ChangedRoles(StringCollection roles)
		{
			txtRuoli.Text = "Ruoli cambiati";
		}
	}
}
