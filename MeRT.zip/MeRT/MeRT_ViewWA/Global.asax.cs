using System;
using System.Runtime.Remoting;
using System.Text;

namespace MeRT_ViewWA 
{
	/// <summary>
	/// Summary description for Global.
	/// </summary>
	public class Global : System.Web.HttpApplication
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		public Global()
		{
			components = components;
			InitializeComponent();
		}	
		
		protected void Application_Start(Object sender, EventArgs e)
		{
			string blConfig = AppDomain.CurrentDomain.SetupInformation.ApplicationBase + "BL.config";
			RemotingConfiguration.Configure(blConfig);

			GME.Web.WSClient.SetCertificatePolicy(null);
		}
 
		protected void Session_Start(Object sender, EventArgs e)
		{

		}

		protected void Application_BeginRequest(Object sender, EventArgs e)
		{

		}

		protected void Application_EndRequest(Object sender, EventArgs e)
		{

		}

		protected void Application_AuthenticateRequest(Object sender, EventArgs e)
		{
		}

		protected void Application_Error(Object sender, EventArgs e)
		{
			try
			{
				Exception ex = Server.GetLastError();
				GME.Log.smError(ex, msg(null));
			}
			catch
			{
			}

		}

		private string msg(string str)
		{
			StringBuilder s = new StringBuilder();

			if (Session["IdUtente"] != null)
				 s.AppendFormat("Utente={0} ", (string)Session["IdUtente"]);
			if (Session["IdOperatore"] != null )
				 s.AppendFormat("Operatore={0} ", (string)Session["IdOperatore"]);
			if (str != null)
				s.Append(str);
			return s.ToString();
		}

		protected void Session_End(Object sender, EventArgs e)
		{

		}

		protected void Application_End(Object sender, EventArgs e)
		{

		}
			
		#region Web Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			// 
			// Global
			// 
			this.AcquireRequestState += new System.EventHandler(this.Global_AcquireRequestState);

		}
		#endregion

		private void Global_AcquireRequestState(object sender, System.EventArgs e)
		{
			GME.Web.WebFormAuth.AcquireRequestState(sender, e);
		}
	}
}

